

function renderBreadcrumb(path) {
    
    path = path || _path;
    if (!path) {
        reloadWithPath();
    }
    var $pathContainer = $("#path");
    var breadcrumbsHeight = 50;
    var breadcrumbsContainterWith = $pathContainer.width();
    
    $pathContainer.empty();
    if (path === "/") {
        $pathContainer.append('<li class="active breadcrumb-root">' +
            '<img class="breadcrumb-icon breadcrumb-icon-root" src="/images/app-icon.png"/>'
            + _device + '</li>');
    } else {
        $pathContainer.append('<li class="breadcrumb-root" data-path="/"><a>' +
            '<img class="breadcrumb-icon breadcrumb-icon-root" src="/images/app-icon.png"/>'
            + _device + '</a></li>');
        var components = path.split("/").slice(1, -1);

        for (var i = 0; i < components.length - 1; ++i) {
            var subpath = "/" + components.slice(0, i + 1).join("/") + "/";
            $pathContainer.append('<li class = "crop-breadcrumb-item" data-path="' + subpath + '">' +
                '<a><img class="breadcrumb-icon breadcrumb-icon-child" src="/images/navigation-folder.png"/>' + components[i] + '</a>' +
                '</li>');
        }

        $pathContainer.append('<li class="active crop-breadcrumb-item">' +
            '<img class="breadcrumb-icon breadcrumb-icon-child" src="/images/navigation-folder.png"/>'
            + components[components.length - 1] + '</li>');
    
        //reset max width of breadcrumb items to default 
        var cropBreadcrumbItemInitialMaxWidth = 160.0;
        var cropBreadcrumbItems = document.getElementsByClassName('crop-breadcrumb-item');
        var cropBreadcrumbItemsLength = cropBreadcrumbItems.length;
        for (var i = 0; i < cropBreadcrumbItemsLength; i++) {
            var cropBreadcrumbItem = cropBreadcrumbItems[i]; 
            cropBreadcrumbItem.style.maxWidth = "" + cropBreadcrumbItemInitialMaxWidth + "px";
        }

        //if items does not fit show options button with popover
        if ($pathContainer.height() > breadcrumbsHeight) {
            $pathContainer.find(".breadcrumb-root").remove();
            $pathContainer.find(".crop-breadcrumb-item:not(.active)").remove();

            var activeBreadcrumbItem = $pathContainer.find(".crop-breadcrumb-item.active");
            activeBreadcrumbItem.before('<li class="breadcrumb-expanding">' +
                    '<ol class="hidden-items"></ol>' +
                    '<div class="button-cell-options"></div>');

            var expandContainer = $pathContainer.find(".breadcrumb-expanding .hidden-items");
            var showHiddenItems = $pathContainer.find(".breadcrumb-expanding .button-cell-options");
            expandContainer.append('<li class="crop-breadcrumb-item" data-path="/">' +
                                   '<a class="breadcrumb-popover-item">' +
                                   '<img class="breadcrumb-icon breadcrumb-icon-root" src="/images/app-icon.png"/>' +
                                   '<span class="doc-name">' + _device + '</span>' +
                                   '</a></li>');
            for (var j = 0; j < components.length - 1; ++j) {
                subpath = "/" + components.slice(0, j + 1).join("/") + "/";
                expandContainer.append('<li class = "crop-breadcrumb-item" data-path="' + subpath + '">' +
                    '<a class="breadcrumb-popover-item">' +
                    '<img class="breadcrumb-icon breadcrumb-icon-child" src="/images/navigation-folder.png"/>' +
                    '<span class="doc-name">' + components[j] + '</span>' +
                    '</a></li>');
            }
            
            showHiddenItems.on("click", function () {
                expandContainer.toggleClass("visible");
                if (expandContainer.hasClass("visible")) {
                    $("body").on("click", handleBreadcrumbOutsideClick);
                }
                return false;
            });
            
            //resize active breadcrumb item
            var breadcrumbOptionsItemWidth = showHiddenItems["0"].clientWidth;
            var activeBreadcrumbItemMaxWidth = (breadcrumbsContainterWith-breadcrumbOptionsItemWidth);
            activeBreadcrumbItem["0"].style.maxWidth = "" + activeBreadcrumbItemMaxWidth + "px";
        }
        else{
            
            //calculate  maxWidth for breadcrumb items 
            var breadcrumbRootItem = $pathContainer.find(".breadcrumb-root");
            var breadcrumbRootItemWidth = breadcrumbRootItem["0"].clientWidth;
            var cropBreadcrumbItemsMaxWidth = (breadcrumbsContainterWith-breadcrumbRootItemWidth);
            var cropBreadcrumbItemProportionalMaxWidth = Math.floor(cropBreadcrumbItemsMaxWidth/cropBreadcrumbItemsLength);
            var cropBreadcrumbItemsRealWidth = 0;
            var cropBreadcrumbItemCurrentPreferredMaxWidth = cropBreadcrumbItemProportionalMaxWidth;
            var cropBreadcrumbItemResultPreferredMaxWidth = cropBreadcrumbItemCurrentPreferredMaxWidth;
            
            for (var j = 0; j < 100; j++) {
                var cropBreadcrumbItemDeltaWidth = 0;
                if($pathContainer.height() > breadcrumbsHeight){
                    break;
                }
                if(cropBreadcrumbItemsRealWidth>0){
                    cropBreadcrumbItemsRealWidth = Math.ceil(cropBreadcrumbItemsRealWidth);
                    if(cropBreadcrumbItemsRealWidth>=cropBreadcrumbItemsMaxWidth){
                        break;
                    }
                    cropBreadcrumbItemDeltaWidth = Math.floor((cropBreadcrumbItemsMaxWidth-cropBreadcrumbItemsRealWidth)/cropBreadcrumbItemsLength);
                    if(cropBreadcrumbItemDeltaWidth < 1.0){
                        break;
                    }
                    cropBreadcrumbItemsRealWidth = 0;
                    cropBreadcrumbItemResultPreferredMaxWidth = cropBreadcrumbItemCurrentPreferredMaxWidth;
                    cropBreadcrumbItemCurrentPreferredMaxWidth+=cropBreadcrumbItemDeltaWidth;
                }
                for (var i = 0; i < cropBreadcrumbItemsLength; i++) {
                    var cropBreadcrumbItem = cropBreadcrumbItems[i]; 
                    if(cropBreadcrumbItemDeltaWidth>0){
                        var fixedMaxWidth = cropBreadcrumbItem.clientWidth + cropBreadcrumbItemDeltaWidth;
                        cropBreadcrumbItem.style.maxWidth = "" + fixedMaxWidth + "px";
                    }
                    else{
                        cropBreadcrumbItem.style.maxWidth = "" + cropBreadcrumbItemProportionalMaxWidth + "px";
                    }
                    cropBreadcrumbItemsRealWidth += cropBreadcrumbItem.clientWidth;
                }
            }
            
            //assign max width for breadcrumb items
            for (var i = 0; i < cropBreadcrumbItemsLength; i++) {
                var cropBreadcrumbItem = cropBreadcrumbItems[i]; 
                cropBreadcrumbItem.style.maxWidth = "" + cropBreadcrumbItemResultPreferredMaxWidth + "px";
            }
                
        }

        $pathContainer.find("li").click(function (event) {
            var path = $(this).data("path");
            if (path) {
                window.location.hash = "#" + encodeURIComponent(path);
                event.preventDefault();
            }
        });
    }
}

var handleBreadcrumbOutsideClick = function (event) {
    var hiddenItems = $(".hidden-items");
    var body = $("body");
    hiddenItems.removeClass("visible");
    body.off("click", handleBreadcrumbOutsideClick);
};


var _resizeTimeout;
$(window).on("resize", function () {
    clearTimeout(_resizeTimeout);
    _resizeTimeout = setTimeout(function () {
        renderBreadcrumb(_path);
    }, 10);
});

