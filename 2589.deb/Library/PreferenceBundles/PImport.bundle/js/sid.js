

function getSID() {
    var localStorage = window.localStorage;
    var data = localStorage.getItem('sid');
    if(data===null){
        data='';
    }
    return data;
}

function setSID(sid) {
    var localStorage = window.localStorage;
    if(sid!==null && sid.length>0){
        localStorage.setItem('sid', sid);
    }
    else{
        localStorage.removeItem('sid');
    }
}

function updateSID(){
    var query = window.location.search.substring(1);
    var sid = (StringUtils.parseQuery(query)).sid;
    if(sid !== undefined && sid!==null && sid.length>0){
        sid = sid.replace("/", "");
        log.log("sid: " + sid);
        setSID(sid);
    } 
}
