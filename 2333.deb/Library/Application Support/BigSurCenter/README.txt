Hello fellow themer!

Feel free to change these images to the ones you'd like, but keep in mind to make a backup of the original ones first in case you want to change back.

To theme brightness and audio images, name the images to:
  * audio_off.png
  * audio_low.png
  * audio_mid.png
  * audio_high.png

  * brightness_low.png
  * brightness_high.png

You need to do all audio images for it's different states for it to work, and the same for brightness.
