/* 
get-svg-colors-browser v2.0.5
Copyright (c) 2021 Georg Fischer
@license MIT
https://github.com/snorpey/get-svg-colors-browser.git */
var _0x4a728d = _0x4c3d;
(function (_0x11e4af, _0x412537) {
    var _0x518c5d = _0x4c3d, _0x42fbce = _0x11e4af();
    while (!![]) {
        try {
            var _0x1647c8 = parseInt(_0x518c5d(0x389)) / 0x1 + parseInt(_0x518c5d(0x4f0)) / 0x2 * (-parseInt(_0x518c5d(0x28a)) / 0x3) + parseInt(_0x518c5d(0x2fe)) / 0x4 * (-parseInt(_0x518c5d(0x15e)) / 0x5) + -parseInt(_0x518c5d(0x605)) / 0x6 * (-parseInt(_0x518c5d(0x51b)) / 0x7) + parseInt(_0x518c5d(0x644)) / 0x8 + parseInt(_0x518c5d(0x4c4)) / 0x9 * (parseInt(_0x518c5d(0x40e)) / 0xa) + parseInt(_0x518c5d(0x695)) / 0xb * (-parseInt(_0x518c5d(0x3cd)) / 0xc);
            if (_0x1647c8 === _0x412537)
                break;
            else
                _0x42fbce['push'](_0x42fbce['shift']());
        } catch (_0x103292) {
            _0x42fbce['push'](_0x42fbce['shift']());
        }
    }
}(_0x2ba5, 0xab712), !function (_0x9113c6, _0x2fa5f4) {
    var _0x5b0e5c = _0x4c3d, _0x3a95fa = {
            'mcsmx': function (_0x2962a4, _0x168dd8) {
                return _0x2962a4 == _0x168dd8;
            },
            'llMWj': _0x5b0e5c(0x640),
            'ndVqo': _0x5b0e5c(0x57c),
            'yaVqr': function (_0x524509) {
                return _0x524509();
            },
            'yzXfq': _0x5b0e5c(0x3b9),
            'arnAM': function (_0x43e486, _0x5a21e5) {
                return _0x43e486(_0x5a21e5);
            },
            'WZZRD': function (_0x37dcb5, _0x5e5cab) {
                return _0x37dcb5 != _0x5e5cab;
            },
            'EQkwo': function (_0x5292af, _0x589a89) {
                return _0x5292af || _0x589a89;
            }
        };
    _0x3a95fa[_0x5b0e5c(0x5e6)](_0x3a95fa[_0x5b0e5c(0x45f)], typeof exports) && _0x3a95fa[_0x5b0e5c(0x14e)] != typeof module ? module[_0x5b0e5c(0x4e5)] = _0x3a95fa['yaVqr'](_0x2fa5f4) : _0x3a95fa[_0x5b0e5c(0x25a)] == typeof define && define['amd'] ? _0x3a95fa[_0x5b0e5c(0x431)](define, _0x2fa5f4) : (_0x9113c6 = _0x3a95fa['WZZRD'](_0x3a95fa['ndVqo'], typeof globalThis) ? globalThis : _0x3a95fa[_0x5b0e5c(0x62f)](_0x9113c6, self))[_0x5b0e5c(0x3fa)] = _0x3a95fa[_0x5b0e5c(0x561)](_0x2fa5f4);
}(this, function () {
    'use strict';
    var _0x51c849 = _0x4c3d, _0x1521b3 = {
            'zWnIp': 'none',
            'aMCZo': function (_0x210af8, _0x11f2b1) {
                return _0x210af8 !== _0x11f2b1;
            },
            'oPMuK': function (_0x187795, _0x27a814) {
                return _0x187795 === _0x27a814;
            },
            'ohYOD': _0x51c849(0x13b),
            'RAVUW': '<svg',
            'pSEhN': function (_0x36722f, _0x3da8bf) {
                return _0x36722f + _0x3da8bf;
            },
            'llBIg': _0x51c849(0x2d4),
            'dHCPz': _0x51c849(0x35a),
            'DOzBN': function (_0x489555, _0x1e3c2e) {
                return _0x489555 instanceof _0x1e3c2e;
            },
            'Iedqs': function (_0xc7e273, _0x59c213) {
                return _0xc7e273 == _0x59c213;
            },
            'jkFpO': _0x51c849(0x2b0),
            'NPcNH': function (_0x1d7d43, _0x3ec770) {
                return _0x1d7d43 === _0x3ec770;
            },
            'SvQyp': _0x51c849(0x17b),
            'nABEC': function (_0x3e7b5d, _0xf83fb0, _0x12eb6a) {
                return _0x3e7b5d(_0xf83fb0, _0x12eb6a);
            },
            'qwnIp': 'stop-color',
            'etDIq': function (_0x2a6f0d, _0x221c76, _0x21a29b) {
                return _0x2a6f0d(_0x221c76, _0x21a29b);
            },
            'ohxAA': function (_0x5a8003, _0x1c193a, _0x37c73c) {
                return _0x5a8003(_0x1c193a, _0x37c73c);
            },
            'quuEk': _0x51c849(0x33a),
            'JAvDm': function (_0x133805, _0x3e06bb, _0x3a8ebb) {
                return _0x133805(_0x3e06bb, _0x3a8ebb);
            },
            'vrfzM': _0x51c849(0x4ce),
            'SzWWw': function (_0x4dffb7, _0x514b5e) {
                return _0x4dffb7(_0x514b5e);
            },
            'ZSSOc': function (_0x51b08b, _0x53d52) {
                return _0x51b08b(_0x53d52);
            },
            'ptSUl': 'http://www.w3.org/2000/svg',
            'nYgPp': 'black',
            'blmrt': _0x51c849(0x638),
            'GBLfP': 'gray',
            'hUXVx': _0x51c849(0x6a2),
            'FScMp': _0x51c849(0x4b4),
            'UkZSt': _0x51c849(0x3ac),
            'LXVoD': _0x51c849(0x511),
            'gmCZx': _0x51c849(0x32f),
            'nsNTt': _0x51c849(0x335),
            'yqWDI': _0x51c849(0x62a),
            'TPzuV': _0x51c849(0x3de),
            'GGaTB': 'teal',
            'iuvbn': _0x51c849(0x1c2),
            'Nsddz': 'aliceblue',
            'HhuGZ': _0x51c849(0x63e),
            'jrxWF': _0x51c849(0x294),
            'OVtcF': _0x51c849(0x170),
            'yOGTh': _0x51c849(0x55a),
            'oMrRb': _0x51c849(0x544),
            'pfYOl': _0x51c849(0x175),
            'tnCxd': _0x51c849(0x2e6),
            'sudnC': 'coral',
            'jauVI': _0x51c849(0x410),
            'Pcaha': 'cornsilk',
            'EwNdC': _0x51c849(0x3c4),
            'BjzpC': _0x51c849(0x163),
            'wMuwJ': _0x51c849(0x298),
            'Qgask': _0x51c849(0x577),
            'qlrnf': _0x51c849(0x509),
            'RDOwW': _0x51c849(0x1af),
            'yYujn': _0x51c849(0x155),
            'zunIf': _0x51c849(0x573),
            'lJWOv': _0x51c849(0x13c),
            'QkCMP': 'darksalmon',
            'vjRaW': _0x51c849(0x1d4),
            'BGbkn': _0x51c849(0x44c),
            'iiWpt': _0x51c849(0x4b8),
            'OSFku': _0x51c849(0x5c2),
            'vRSUY': _0x51c849(0x465),
            'KKLuN': 'darkviolet',
            'JwKTh': _0x51c849(0x1d8),
            'Uzbdn': _0x51c849(0x5f3),
            'IBnfB': _0x51c849(0x485),
            'Dqram': _0x51c849(0x5b7),
            'KpOHk': _0x51c849(0x347),
            'HXmWm': _0x51c849(0x4d7),
            'HQcqE': _0x51c849(0x426),
            'XtGVT': _0x51c849(0x5cb),
            'AQdGd': _0x51c849(0x622),
            'PvRbQ': _0x51c849(0x3f0),
            'HftOF': 'goldenrod',
            'Yxgfo': _0x51c849(0x447),
            'RGzNu': 'grey',
            'VnKmd': _0x51c849(0x60d),
            'JtZND': _0x51c849(0x2d9),
            'VRmQt': _0x51c849(0x64f),
            'dUxRG': _0x51c849(0x17e),
            'rZrdm': _0x51c849(0x3ba),
            'OfoGu': _0x51c849(0x571),
            'uvisj': _0x51c849(0x444),
            'weaDM': _0x51c849(0x1c5),
            'zCWMV': 'lightgoldenrodyellow',
            'znsyA': _0x51c849(0x470),
            'olUjW': _0x51c849(0x13a),
            'qENFl': _0x51c849(0x185),
            'QdLlv': _0x51c849(0x68f),
            'yfYrJ': _0x51c849(0x3af),
            'lWrUZ': _0x51c849(0x583),
            'WBzyn': _0x51c849(0x4c1),
            'oWXaH': _0x51c849(0x171),
            'IVYkQ': _0x51c849(0x663),
            'dkWVG': _0x51c849(0x51e),
            'LPfLg': _0x51c849(0x1e3),
            'ESQSa': _0x51c849(0x20e),
            'kOkrg': 'mediumblue',
            'QpKyN': _0x51c849(0x5cd),
            'BnMYz': _0x51c849(0x13e),
            'IXyyP': 'mediumslateblue',
            'Izgeo': 'mediumspringgreen',
            'OFQPE': 'mediumturquoise',
            'mBgcb': 'mediumvioletred',
            'hmMil': _0x51c849(0x320),
            'vQcSR': _0x51c849(0x618),
            'LOxix': _0x51c849(0x250),
            'UCxNz': 'navajowhite',
            'qzHSo': _0x51c849(0x1f4),
            'UUHgF': _0x51c849(0x643),
            'mfbBI': _0x51c849(0x32a),
            'aOfaq': 'orchid',
            'ujVUG': _0x51c849(0x1e7),
            'pYdML': _0x51c849(0x206),
            'tEhea': _0x51c849(0x3b1),
            'dvuSF': _0x51c849(0x388),
            'VQiiB': _0x51c849(0x1ae),
            'zoAhd': _0x51c849(0x252),
            'GlCeM': _0x51c849(0x4b3),
            'rutir': _0x51c849(0x32b),
            'QmNlJ': _0x51c849(0x614),
            'FttoV': _0x51c849(0x204),
            'RcWrl': _0x51c849(0x39f),
            'WbguR': _0x51c849(0x5aa),
            'eaByG': 'sienna',
            'ryZpO': _0x51c849(0x197),
            'KcJbX': _0x51c849(0x336),
            'HESIw': _0x51c849(0x341),
            'ZlRNZ': _0x51c849(0x360),
            'RiuuI': _0x51c849(0x23c),
            'hDvPk': _0x51c849(0x4f4),
            'gUTFN': 'tomato',
            'OCGPs': _0x51c849(0x364),
            'muTBn': _0x51c849(0x5b2),
            'uXMwv': _0x51c849(0x576)
        };
    var _0x3393d6 = /<!--([\s\S]*?)-->/g, _0x2f431c = _0x1521b3[_0x51c849(0x28b)], _0x1978e1 = /(#(?:[0-9a-f]{2}){2,4}|(#[0-9a-f]{3})|(rgb|hsl)a?\((-?\d+%?[,\s]+){2,3}\s*[\d\.]+%?\))/i, _0x14d427 = [
            _0x1521b3['nYgPp'],
            _0x1521b3[_0x51c849(0x143)],
            _0x1521b3[_0x51c849(0x5de)],
            _0x1521b3[_0x51c849(0x2d1)],
            'maroon',
            _0x51c849(0x252),
            _0x1521b3[_0x51c849(0x3dd)],
            _0x1521b3[_0x51c849(0x3d0)],
            _0x1521b3[_0x51c849(0x59c)],
            _0x1521b3[_0x51c849(0x566)],
            _0x1521b3[_0x51c849(0x59f)],
            _0x1521b3[_0x51c849(0x46c)],
            'navy',
            _0x1521b3[_0x51c849(0x596)],
            _0x1521b3['GGaTB'],
            _0x1521b3['iuvbn'],
            _0x1521b3['Nsddz'],
            _0x51c849(0x3f6),
            _0x1521b3[_0x51c849(0x27d)],
            _0x1521b3[_0x51c849(0x4d8)],
            _0x51c849(0x14d),
            _0x1521b3['jrxWF'],
            _0x1521b3[_0x51c849(0x4f5)],
            _0x1521b3['nYgPp'],
            'blanchedalmond',
            _0x1521b3['TPzuV'],
            'blueviolet',
            _0x1521b3['yOGTh'],
            _0x1521b3[_0x51c849(0x1d1)],
            'cadetblue',
            _0x1521b3[_0x51c849(0x45b)],
            _0x1521b3['tnCxd'],
            _0x1521b3[_0x51c849(0x54c)],
            _0x1521b3[_0x51c849(0x395)],
            _0x1521b3[_0x51c849(0x507)],
            'crimson',
            _0x1521b3['EwNdC'],
            _0x1521b3[_0x51c849(0x635)],
            _0x1521b3[_0x51c849(0x4e9)],
            _0x1521b3[_0x51c849(0x2af)],
            'darkgray',
            _0x1521b3['qlrnf'],
            _0x1521b3[_0x51c849(0x472)],
            _0x1521b3[_0x51c849(0x261)],
            _0x1521b3[_0x51c849(0x424)],
            _0x51c849(0x4cc),
            _0x1521b3[_0x51c849(0x5dd)],
            _0x51c849(0x18c),
            _0x51c849(0x2e9),
            _0x1521b3[_0x51c849(0x1a7)],
            _0x1521b3[_0x51c849(0x20a)],
            _0x1521b3[_0x51c849(0x639)],
            _0x1521b3['iiWpt'],
            _0x1521b3['OSFku'],
            _0x1521b3[_0x51c849(0x280)],
            _0x1521b3[_0x51c849(0x56c)],
            _0x1521b3[_0x51c849(0x1c9)],
            _0x1521b3[_0x51c849(0x186)],
            _0x1521b3[_0x51c849(0x39c)],
            _0x1521b3[_0x51c849(0x46f)],
            _0x1521b3['KpOHk'],
            _0x1521b3[_0x51c849(0x5a0)],
            _0x51c849(0x1f1),
            _0x1521b3[_0x51c849(0x154)],
            _0x1521b3[_0x51c849(0x3d0)],
            _0x1521b3['XtGVT'],
            _0x1521b3['AQdGd'],
            _0x1521b3[_0x51c849(0x1f9)],
            _0x1521b3['HftOF'],
            _0x1521b3[_0x51c849(0x5de)],
            _0x1521b3[_0x51c849(0x59c)],
            _0x1521b3['Yxgfo'],
            _0x1521b3[_0x51c849(0x361)],
            _0x1521b3['VnKmd'],
            _0x51c849(0x210),
            _0x1521b3['JtZND'],
            _0x51c849(0x463),
            _0x1521b3['VRmQt'],
            _0x1521b3[_0x51c849(0x43d)],
            _0x1521b3[_0x51c849(0x66e)],
            _0x51c849(0x423),
            _0x51c849(0x319),
            _0x51c849(0x696),
            _0x1521b3[_0x51c849(0x441)],
            _0x1521b3[_0x51c849(0x572)],
            _0x1521b3[_0x51c849(0x199)],
            _0x1521b3[_0x51c849(0x1c6)],
            _0x1521b3[_0x51c849(0x3c8)],
            _0x1521b3['olUjW'],
            'lightgrey',
            _0x1521b3[_0x51c849(0x26e)],
            'lightsalmon',
            _0x1521b3[_0x51c849(0x354)],
            'lightskyblue',
            _0x1521b3['yfYrJ'],
            _0x1521b3[_0x51c849(0x218)],
            _0x1521b3['WBzyn'],
            _0x1521b3[_0x51c849(0x24a)],
            _0x51c849(0x32f),
            _0x1521b3['IVYkQ'],
            'linen',
            _0x1521b3[_0x51c849(0x51c)],
            _0x1521b3[_0x51c849(0x400)],
            _0x1521b3[_0x51c849(0x4a8)],
            _0x1521b3['kOkrg'],
            _0x1521b3[_0x51c849(0x182)],
            _0x51c849(0x3e8),
            _0x1521b3['BnMYz'],
            _0x1521b3[_0x51c849(0x408)],
            _0x1521b3[_0x51c849(0x399)],
            _0x1521b3[_0x51c849(0x5a7)],
            _0x1521b3[_0x51c849(0x62d)],
            _0x1521b3[_0x51c849(0x67a)],
            _0x51c849(0x26d),
            _0x1521b3[_0x51c849(0x505)],
            _0x1521b3[_0x51c849(0x47c)],
            _0x1521b3[_0x51c849(0x442)],
            _0x1521b3[_0x51c849(0x22c)],
            _0x1521b3[_0x51c849(0x4c0)],
            _0x51c849(0x335),
            _0x51c849(0x25d),
            _0x51c849(0x406),
            _0x1521b3['mfbBI'],
            _0x1521b3['aOfaq'],
            _0x51c849(0x257),
            _0x51c849(0x1c1),
            _0x51c849(0x4ab),
            _0x51c849(0x247),
            _0x1521b3[_0x51c849(0x66f)],
            _0x51c849(0x275),
            _0x1521b3[_0x51c849(0x412)],
            _0x1521b3[_0x51c849(0x2b5)],
            _0x1521b3[_0x51c849(0x555)],
            _0x1521b3[_0x51c849(0x508)],
            _0x1521b3[_0x51c849(0x3dd)],
            _0x1521b3[_0x51c849(0x5b9)],
            _0x1521b3[_0x51c849(0x493)],
            _0x1521b3[_0x51c849(0x515)],
            _0x1521b3['QmNlJ'],
            _0x51c849(0x259),
            _0x1521b3[_0x51c849(0x35d)],
            _0x1521b3[_0x51c849(0x317)],
            _0x1521b3[_0x51c849(0x152)],
            _0x1521b3['eaByG'],
            _0x1521b3['blmrt'],
            _0x1521b3[_0x51c849(0x568)],
            _0x51c849(0x168),
            _0x1521b3[_0x51c849(0x2f5)],
            _0x1521b3[_0x51c849(0x27b)],
            _0x1521b3[_0x51c849(0x2b9)],
            _0x51c849(0x365),
            _0x1521b3['RiuuI'],
            _0x51c849(0x5d7),
            'teal',
            _0x1521b3[_0x51c849(0x5d9)],
            _0x1521b3[_0x51c849(0x47d)],
            _0x1521b3['OCGPs'],
            _0x1521b3[_0x51c849(0x4ba)],
            _0x51c849(0x651),
            _0x1521b3[_0x51c849(0x2d1)],
            _0x51c849(0x4a4),
            _0x51c849(0x62a),
            _0x1521b3[_0x51c849(0x634)]
        ];
    function _0x32694a(_0x1008a5, _0x500b59, _0x50c429) {
        var _0x3da503 = _0x51c849;
        return _0x50c429[_0x3da503(0x6a1)](_0x1008a5) === _0x500b59;
    }
    function _0x2e927f(_0x13f5f2) {
        var _0x258350 = _0x51c849;
        for (var _0x1d7269 = -0x1, _0x27ce54 = _0x13f5f2 ? _0x13f5f2[_0x258350(0x1d9)] : 0x0, _0x95c1c3 = 0x0, _0x413f9f = []; ++_0x1d7269 < _0x27ce54;) {
            var _0x5a7389 = _0x13f5f2[_0x1d7269];
            _0x5a7389 && (_0x413f9f[_0x95c1c3++] = _0x5a7389);
        }
        return _0x413f9f;
    }
    function _0xb11049(_0x1fe4c5) {
        var _0x5e3c0f = _0x51c849;
        return _0x1fe4c5[_0x5e3c0f(0x50b)]();
    }
    function _0x5878e9(_0x46eecb) {
        var _0x449bb0 = _0x51c849;
        return !!_0x46eecb && (_0x1521b3['zWnIp'] !== _0x46eecb && (_0x1521b3[_0x449bb0(0x184)](-0x1, _0x14d427['indexOf'](_0x46eecb[_0x449bb0(0x50b)]())) || _0x46eecb[_0x449bb0(0x58b)](_0x1978e1)));
    }
    function _0x53d448(_0x394da7) {
        var _0x2fed40 = _0x51c849, _0x19d38c = new DOMParser();
        return _0x1521b3[_0x2fed40(0x5c4)](-0x1, _0x394da7[_0x2fed40(0x6a1)](_0x1521b3[_0x2fed40(0x42a)])) && -0x1 !== _0x394da7[_0x2fed40(0x6a1)](_0x1521b3[_0x2fed40(0x4f6)]) && _0x394da7[_0x2fed40(0x609)](_0x1521b3['RAVUW'], _0x1521b3[_0x2fed40(0x41a)](_0x1521b3['pSEhN'](_0x1521b3[_0x2fed40(0x4e0)], _0x2f431c), '\x22')), _0x19d38c['parseFromString'](_0x394da7, _0x1521b3[_0x2fed40(0x518)]);
    }
    function _0x1879fe(_0x7b07bf, _0x260cb6) {
        var _0x32a36c = _0x51c849;
        return _0x5d52c6 = _0x260cb6[_0x32a36c(0x262)](_0x7b07bf), Array['prototype'][_0x32a36c(0x3df)][_0x32a36c(0x2e4)](_0x5d52c6);
        var _0x5d52c6;
    }
    function _0x7922ae(_0x24cf07) {
        var _0x5a8501 = _0x51c849;
        return _0x1521b3[_0x5a8501(0x4bc)](_0x24cf07, SVGElement) ? Promise[_0x5a8501(0x3a6)](_0x24cf07) : /^\s*(?:<\?xml[^>]*>\s*)?(?:<!doctype svg[^>]*\s*(?:\[?(?:\s*<![^>]*>\s*)*\]?)*[^>]*>\s*)?<svg[^>]*>[^]*<\/svg>\s*$/i[_0x5a8501(0x1ea)](_0x24cf07[_0x5a8501(0x609)](_0x3393d6, '')) ? Promise[_0x5a8501(0x3a6)](_0x53d448(_0x24cf07)) : _0x1521b3[_0x5a8501(0x458)](_0x1521b3[_0x5a8501(0x3bf)], typeof _0x24cf07) ? fetch(_0x24cf07)[_0x5a8501(0x4b6)](function (_0x2c2d8a) {
            return _0x2c2d8a['text']();
        })[_0x5a8501(0x4b6)](function (_0x465ca5) {
            return _0x53d448(_0x465ca5);
        }) : void 0x0;
    }
    function _0x244252(_0x3c4bb1, _0x2ed186) {
        var _0x502912 = _0x51c849, _0x41982a = {
                'RLmRs': function (_0x239ef1, _0x2b80b9) {
                    var _0x7ad7c1 = _0x4c3d;
                    return _0x1521b3[_0x7ad7c1(0x184)](_0x239ef1, _0x2b80b9);
                }
            };
        return _0x3c4bb1[_0x502912(0x609)](/(\s|\n|\R|\r)/g, '')[_0x502912(0x5e1)](/(\{|\}|\;)/)[_0x502912(0x331)](function (_0x528e4c) {
            return _0x528e4c['trim']();
        })[_0x502912(0x331)](_0xb11049)['filter'](function (_0x96ef7c) {
            var _0x2f21f2 = _0x502912;
            return _0x96ef7c && _0x96ef7c[_0x2f21f2(0x1d9)];
        })[_0x502912(0x15c)](function (_0x5ca2e6) {
            var _0x3e9245 = _0x502912;
            return _0x1521b3['NPcNH'](0x0, _0x5ca2e6[_0x3e9245(0x6a1)](_0x2ed186));
        })[_0x502912(0x331)](function (_0x5684ee) {
            var _0x2d2e77 = _0x502912;
            return _0x5684ee[_0x2d2e77(0x5e1)](':')[_0x2d2e77(0x331)](function (_0x41af26) {
                var _0x33da50 = _0x2d2e77;
                return _0x41af26[_0x33da50(0x467)]();
            })[_0x2d2e77(0x15c)](function (_0x47b2aa) {
                return _0x47b2aa !== _0x2ed186;
            });
        })['reduce'](function (_0x1803fc, _0x2be44c) {
            var _0x326d63 = _0x502912;
            return _0x1803fc[_0x326d63(0x2bc)](_0x2be44c);
        }, [])[_0x502912(0x15c)](function (_0xc47468) {
            var _0xb8d7a7 = _0x502912;
            return _0x41982a[_0xb8d7a7(0x2dd)](-0x1, _0x14d427[_0xb8d7a7(0x6a1)](_0xc47468)) || _0x1978e1[_0xb8d7a7(0x1ea)](_0xc47468);
        });
    }
    return function (_0x1f6e5f, _0x13fb69) {
        var _0x160ed3 = _0x51c849, _0x23e969 = { 'RRhiB': 'stroke' };
        return _0x1521b3[_0x160ed3(0x69b)](_0x7922ae, _0x1f6e5f)['then'](function (_0x5f5234) {
            var _0x2492f9 = _0x160ed3, _0x42e2fb = {
                    'zrRIA': _0x1521b3[_0x2492f9(0x4bd)],
                    'UcHPE': function (_0x5bc90a, _0x1f4297, _0x27eb1a) {
                        return _0x5bc90a(_0x1f4297, _0x27eb1a);
                    },
                    'xqqjj': function (_0xd0f515, _0x22fcda, _0xf238b0) {
                        return _0x1521b3['nABEC'](_0xd0f515, _0x22fcda, _0xf238b0);
                    },
                    'KQxfP': _0x1521b3[_0x2492f9(0x5d0)]
                }, _0x198681 = _0x1521b3[_0x2492f9(0x3fc)](_0x1879fe, _0x2492f9(0x2c3), _0x5f5234)[_0x2492f9(0x331)](function (_0x3687b1) {
                    var _0x3d81cb = _0x2492f9;
                    return _0x3687b1[_0x3d81cb(0x632)](_0x42e2fb[_0x3d81cb(0x60a)]);
                }), _0x59c964 = _0x1521b3[_0x2492f9(0x1b2)](_0x1879fe, _0x2492f9(0x63a), _0x5f5234)[_0x2492f9(0x331)](function (_0x4eee8b) {
                    var _0x4c467c = _0x2492f9;
                    return _0x4eee8b['getAttribute'](_0x23e969[_0x4c467c(0x2e3)]);
                }), _0x14c155 = _0x1521b3[_0x2492f9(0x451)](_0x1879fe, _0x2492f9(0x29a), _0x5f5234)['map'](function (_0x202f0c) {
                    return _0x202f0c['getAttribute']('stop-color');
                });
            return _0x1521b3[_0x2492f9(0x451)](_0x1879fe, _0x1521b3[_0x2492f9(0x3bb)], _0x5f5234)['forEach'](function (_0x122b42) {
                var _0x5ea748 = _0x2492f9;
                _0x198681[_0x5ea748(0x203)](_0x122b42[_0x5ea748(0x4ce)][_0x5ea748(0x17b)]), _0x59c964[_0x5ea748(0x203)](_0x122b42['style'][_0x5ea748(0x2ad)]), _0x14c155[_0x5ea748(0x203)](_0x122b42['style'][_0x5ea748(0x680)]);
            }), _0x1521b3[_0x2492f9(0x1ed)](_0x1879fe, _0x1521b3['vrfzM'], _0x5f5234)[_0x2492f9(0x190)](function (_0x4e7599) {
                var _0xb98dd2 = _0x2492f9, _0x3e62eb = _0x4e7599[_0xb98dd2(0x2ea)];
                _0x42e2fb[_0xb98dd2(0x3ee)](_0x244252, _0x3e62eb, _0x42e2fb[_0xb98dd2(0x60a)])[_0xb98dd2(0x190)](function (_0x49d148) {
                    var _0x3cf270 = _0xb98dd2;
                    return _0x198681[_0x3cf270(0x203)](_0x49d148);
                }), _0x42e2fb[_0xb98dd2(0x3ee)](_0x244252, _0x3e62eb, 'stroke')[_0xb98dd2(0x190)](function (_0x4d1a14) {
                    var _0x1aa088 = _0xb98dd2;
                    return _0x59c964[_0x1aa088(0x203)](_0x4d1a14);
                }), _0x42e2fb[_0xb98dd2(0x178)](_0x244252, _0x3e62eb, _0x42e2fb[_0xb98dd2(0x162)])[_0xb98dd2(0x190)](function (_0x5b39fb) {
                    var _0x11f11d = _0xb98dd2;
                    return _0x14c155[_0x11f11d(0x203)](_0x5b39fb);
                });
            }), _0x13fb69 && _0x13fb69[_0x2492f9(0x222)] ? _0x1521b3[_0x2492f9(0x29d)](_0x2e927f, _0x198681[_0x2492f9(0x2bc)](_0x59c964)['concat'](_0x14c155)['filter'](_0x5878e9)[_0x2492f9(0x331)](_0xb11049)['filter'](_0x32694a)) : {
                'fills': _0x2e927f(_0x198681[_0x2492f9(0x15c)](_0x5878e9)['map'](_0xb11049)[_0x2492f9(0x15c)](_0x32694a)),
                'strokes': _0x1521b3['SzWWw'](_0x2e927f, _0x59c964['filter'](_0x5878e9)[_0x2492f9(0x331)](_0xb11049)['filter'](_0x32694a)),
                'stops': _0x1521b3[_0x2492f9(0x29d)](_0x2e927f, _0x14c155['filter'](_0x5878e9)[_0x2492f9(0x331)](_0xb11049)[_0x2492f9(0x15c)](_0x32694a))
            };
        });
    };
}));
!String[_0x4a728d(0x612)][_0x4a728d(0x594)] && (String['prototype'][_0x4a728d(0x594)] = function (_0x23e5d6, _0x44b424) {
    var _0x135427 = _0x4a728d;
    return this[_0x135427(0x609)](new RegExp(_0x23e5d6, 'g'), _0x44b424);
});
window[_0x4a728d(0x636)] = window[_0x4a728d(0x636)] || window['chrome'];
const NUM_ALLOWED_WEBSITES_FOR_TRIAL = (_0x4a728d(0x3e4)[_0x4a728d(0x1d9)] - 0x12 / 0x2) / 0x2 + 0xa;
String[_0x4a728d(0x612)][_0x4a728d(0x23d)] = function () {
    var _0x7fa9ad = _0x4a728d, _0x435c3e = {
            'KoBNF': function (_0x5ec3b2, _0x588b05) {
                return _0x5ec3b2 + _0x588b05;
            },
            'FxzJG': function (_0x1b6e8c, _0x3a349b) {
                return _0x1b6e8c - _0x3a349b;
            },
            'WABYX': function (_0x197939, _0x143e3b) {
                return _0x197939 & _0x143e3b;
            }
        }, _0x1856e6 = 0x0;
    for (var _0x4d5f06 = 0x0; _0x4d5f06 < this[_0x7fa9ad(0x1d9)]; _0x4d5f06++) {
        var _0x8adaa = this[_0x7fa9ad(0x497)](_0x4d5f06);
        _0x1856e6 = _0x435c3e[_0x7fa9ad(0x2f1)](_0x435c3e[_0x7fa9ad(0x2be)](_0x1856e6 << 0x5, _0x1856e6), _0x8adaa), _0x1856e6 = _0x435c3e[_0x7fa9ad(0x4d9)](_0x1856e6, _0x1856e6);
    }
    return Math[_0x7fa9ad(0x344)](_0x1856e6);
};
function _0x2ba5() {
    var _0x1c78a0 = [
        'DZTsC',
        'round',
        'skhTy',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ncbi-alerts\x20.ncbi-alert__shutdown-outer,\x20.pmc-labs-ad-outer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'vQcSR',
        '.GIF',
        'Pcaha',
        'VQiiB',
        'darkgreen',
        'GjLkx',
        'toLowerCase',
        'body',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.site-navbar\x20.navbar-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.site-navbar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.panel\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.05)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'BfqWG',
        'remove',
        'EKaDb',
        'green',
        'nitefall_start_workaround',
        'img[data-srcset]',
        'clamp',
        'rutir',
        'sFIWY',
        '.product-card__title',
        'dHCPz',
        'cECWc',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#divCentral\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '1903531ZSMfPZ',
        'dkWVG',
        '.wrapper_attributo\x20.elenco_scelte\x20label\x20.wrapper_valore',
        'magenta',
        'uIkzv',
        'kbmWW',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html,\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20cite\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20bom{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::placeholder{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20width:\x2014px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20height:\x2014px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-track\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#303030\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-track-piece\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#3e4346\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-thumb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20height:\x2050px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#6e6e6e\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x202px\x20solid\x20#3e4346\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x2025px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-thumb:hover{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#818080\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-button:decrement,\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-button:increment\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20width:\x200px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20input::-webkit-credentials-auto-fill-button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20input::-webkit-credentials-auto-fill-button:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20*[nitefall_imageType=\x22svg\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20\x20Note\x20that\x20svg\x20imageType\x20will\x20only\x20be\x20set\x20on\x20dark\x20svgs\x20with\x20single\x20color\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20force\x20svg\x20to\x20be\x20light\x20gray\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20https://stackoverflow.com/a/53336754\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20use\x20this\x20codepen\x20to\x20convert\x20svg\x20to\x20desired\x20color\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20https://codepen.io/sosuke/pen/Pjoqqp\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(64%)\x20sepia(0%)\x20saturate(12%)\x20hue-rotate(140deg)\x20brightness(86%)\x20contrast(84%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.codehilite\x20.hll,\x20.highlight\x20.hll\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgba(248,\x20255,\x200,\x200.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'hostname',
        'HKrft',
        'SHOW_ELEMENT',
        'IpxCI',
        'invert',
        'YoIoY',
        'endsWith',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme-bt\x20.dre-item--skin-breaking,\x20.theme-bt\x20.dre-item__header--skin-custom-live,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme-bt\x20.dre-item--skin-breaking\x20.dre-item__header--skin-live,\x20.theme-bt\x20.dre-item--skin-breaking\x20.dre-item__header--skin-updates,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme-bt\x20.dre-item--skin-breaking\x20.dre-item__header--skin-just-now,\x20.theme-bt\x20.dre-item--skin-breaking\x20.dre-item__header--skin-just-now-text\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#c7a505\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'kMNhk',
        '.home-search\x20>\x20input[type=\x22search\x22]',
        'tagName',
        'contains',
        'removeAttribute',
        '.icon-contentFixedh5',
        'nextNode',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header,\x20#header\x20div.frame,\x20#content_section\x20div.frame,\x20#footer_section,\x20#footer_section\x20div.frame,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#content_section,\x20span.upperframe,\x20span.lowerframe,\x20.button_submit,\x20.button_reset,\x20span.upperframe\x20span,\x20span.lowerframe\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'xVEIB',
        'createElement',
        'a[class^=\x22Component-ios-\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.floating_menu,\x20.lst_t17.tablet_aside,\x20.Ndrawer_profile,\x20.Ndrawer_menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Ndrawer_scroll_wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Ndrawer_menu\x20.Nmenu_item,\x20.Ndrawer_profile_menu\x20.Nmenu_item_link\x20.Nmenu_item_text\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.lst_t17\x20.lst_w\x20.paginate\x20.btn_prev\x20i:before,\x20.lst_t17\x20.lst_w\x20.paginate\x20.btn_next\x20i:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#main-content,\x20.ref-bg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'GtDAR',
        'width',
        '.rf-search-tools__title',
        'td\x20a',
        '.img-fluid',
        'add',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20button.more\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[aria-label=\x22Page\x20Logo\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[data-text=\x22true\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sm-dox,\x20.navpath\x20ul,\x20.tabs,\x20.tabs2,\x20.tabs3,\x20.tablist\x20li,\x20div.header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tablist\x20a:hover,\x20.memproto,\x20dl.reflist\x20dt,\x20.memtitle\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'vycSw',
        'removeChild',
        '.up-vote',
        'LcHJN',
        'burlywood',
        'qnEjG',
        '.js--hidden',
        'huHgu',
        'UTKeW',
        'contentWindow',
        'trial-expired-banner',
        '.png',
        'sudnC',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.table-download,\x20.overall\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'vOWpj',
        'CwcMd',
        'LyrAi',
        'VkGMj',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20button[data-toggle=\x22dropdown\x22],\x20.dropdown-menu,\x20input[type=email]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20input[type=text],\x20select,\x20textarea\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dropdown-menu\x20i,\x20.dropdown-menu\x20.selected\x20i.check-mark:after,\x20.framed.phonefinder-slider-highlight\x20label.label:after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dropdown-menu\x20.selected\x20i:after,\x20.dropdown-menu\x20i:after,\x20.framed\x20label.label:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.8)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'background-image',
        '.header-logo',
        'dvuSF',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.invest\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'matchMedia',
        'HuXdo',
        '.side-title',
        'brown',
        'FSytj',
        'fCEhi',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.top-btn-main-wrapper,\x20.category-wrapper,\x20.title-wrapper,\x20.scroll-x-wrapper,\x20.footer-tab-wrapper,\x20.desc-wrapper\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text-wrapper,\x20.list-header-wrapper,\x20.product-view-price-item-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'AJaxo',
        '.terminatorlet',
        'bXdkS',
        'yaVqr',
        'dfWRA',
        '.forget_pass',
        '#interaction_fog',
        'isColorful',
        'gmCZx',
        '.thumb',
        'ryZpO',
        'doc',
        'vWshu',
        'insertRule',
        'KKLuN',
        'wYhsR',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dcg-graph-inner\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'aVJxG',
        'THtxn',
        'lightblue',
        'uvisj',
        'darkmagenta',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#wCategory\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#page-home\x20.section{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[class^=\x22styles_item_\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'yellowgreen',
        'darkgoldenrod',
        'TPjxy',
        '.column-bg-overlay-wrap',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html,\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'puYef',
        'undefined',
        'fouNo',
        'tPpBs',
        'IMwqk',
        '.swiper-pagination',
        'right',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header_fixed\x20.menu_category\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'lightslategrey',
        'color',
        '.static-filters\x20.side-timeline-filter\x20.toggle-button',
        '.pagination\x20.btn__num.on',
        'form[method=\x22POST\x22]\x20svg[width=\x2220px\x22]',
        'VfMTj',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[role=\x22button\x22\x20]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20figure.chapternav-icon\x20,\x20figure[class^=\x22image-compare-icon-\x22],\x20div[class^=\x22iphone-\x22]\x20figure[class^=\x22image-icon-\x22],\x20div[class^=\x22ipad-\x22]\x20figure[class^=\x22image-\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ribbon-blue-to-default\x20.ribbon-content-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20animation:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.as-imagegrid-img-cont\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.promo-copy-wrapper\x20>\x20h2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.apple-one\x20.promo-copy-wrapper\x20>\x20h2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.light-available{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'img[src$=\x22.svg\x22]',
        'match',
        'message',
        'Ejsnr',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.listLinkDate\x20ul\x20li\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bt7\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sword\x20span.input,\x20.comments\x20.form\x20span.textarea\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gsc-search-box-tools\x20.gsc-search-box\x20.gsc-input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.coto_short-stack',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[type=\x22idea\x22]::before,\x20div[type=\x22guide\x22]::before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'ZJGkn',
        '.page-links',
        'PHIsS',
        'replaceAll',
        'Fjcvv',
        'TPzuV',
        '.thb-borders',
        'readyState',
        'body\x20*:not(img)',
        'ZAehr',
        '.icon-mojang-studios',
        'LXVoD',
        'rgbString',
        'AmrUO',
        'nsNTt',
        'HXmWm',
        'ZIwTf',
        'tZWVs',
        'backgroundImage',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-spot-im-shadow-host^=\x22conversation\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.31);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'bxCEa',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.news\x20.li\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'OFQPE',
        'BiiMB',
        'imageBrightness',
        'seashell',
        'isTransparent',
        'GMhyE',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20picture.we-artwork{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'border-',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.footer__inner{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#414141\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'svg.bdl-IconPlusRound',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20._3S3n_:after,\x20._1nF12:before,\x20.i4HRi:after,\x20.tk1IQ:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20form\x20div[role=\x22listbox\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20summary\x20div\x20>\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'violet',
        'Nqahf',
        'vJBis',
        'YdnAN',
        'UyPFE',
        'dimgrey',
        'getComputedStyle',
        'zoAhd',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20form#form_search_location.js-searchbox_redesign.searchbox_redesign.searchbox_redesign--iphone.searchForm.searchbox_fullwidth.placeholder_clear.b-no-tap-highlight{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'vjGEH',
        'yaSKK',
        'ZWlMq',
        'nKPNt',
        'EpzgD',
        'liFoK',
        '.thumb-title\x20>\x20a',
        'darkslategrey',
        'kBccF',
        'oPMuK',
        'cjZZZ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header-banner.mod-warning\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20textarea.mod-list-name:disabled,\x20textarea.mod-card-back-title:disabled{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-webkit-text-fill-color:\x20#6fa3fa\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.list-card\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'kGage',
        '.fhr_mobileIconClose',
        'iQNUP',
        '.cw_tile__contacts-contactSearch',
        'gainsboro',
        '#winnav',
        'mediumorchid',
        '.ctpx-box-content',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.burger-menu\x20.burger,\x20.search-icon\x20>\x20svg,\x20.menu-icon\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'qwnIp',
        'EGZox',
        'a.fl\x20em',
        'wIZFu',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[class^=\x22OutlinedDropdownButton-valueIcon\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.FilterBar-control-1iu.FilterBar-next-zE-::before,\x20.FilterBar-filterWrap-Cys::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.PrimaryNav-link-3IW,\x20.PrimaryNav-logoWrap-564,\x20.PrimaryNav-iconWrap-1F1{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'IQzwo',
        '.RichContent-cover--mobile',
        'tan',
        '.down-vote',
        'hDvPk',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comments__item__children\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-left-color:\x20rgb(70,\x2063,\x2063)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment__space--highlighted::before,\x20.comment__space--new::before,\x20.comment__space--pinned::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment-more--root--11,\x20.ui-button--11{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#282626\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment__children>.comment:not(.comment--level-last):last-child,\x20.comment__space--pinned::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sidebar__footer[data-v-48f6e1e3]:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'xOfcW',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#middle,\x20.sb\x20h3\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bot\x20.genre\x20a,\x20.meta,\x20.bot\x20.show\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#search\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20rgb(82\x2080\x2080)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'lJWOv',
        'GBLfP',
        'zZhms',
        'lXvVN',
        'split',
        'PeWaN',
        '.list--reset',
        'ZeRwg',
        'fGpMt',
        'mcsmx',
        'obhQe',
        '.pdfViewer,\x20embed[type=\x22application/pdf\x22]\x20{\x20filter:\x20invert(90%);}',
        'tr.msg-unread',
        '(prefers-color-scheme:\x20dark)',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.post\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'OjnnY',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vx_modal-dismiss_x-trigger:before,\x20.vx_modal-dismiss_x:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pp-header:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.highlightInstallmentPanel,\x20.highlightTransactionPanel\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vx_globalFooter\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fiDetailArea-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.isSelected_ltr:after,\x20.isSelected_rtl:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-left:\x201.5em\x20solid\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.interstitial-entryLink\x20img{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vx_foreground-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-testid=\x22header_sub\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'QfMFp',
        'mwiUQ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20#block-apexresponsivemenublock\x20#menu-responsive\x20>\x20li\x20.second-level\x20li\x20a:nth-child(1)\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20#block-usertrigger\x20.field\x20div\x20img,\x20header\x20#block-userloggedtrigger\x20.field\x20div\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20#block-cart\x20.cart--cart-block\x20.cart-block--summary\x20.cart-block--summary__icon\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'theme',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.icon-img-nav,\x20a\x20i.icon,\x20ul\x20li.icon,\x20.swiper-button-prev,\x20.swiper-button-next\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.van-tabbar-item__icon,\x20.header-nav-m\x20>\x20.icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.estroe-main-s\x20.icon-contentFixedh5,\x20.gnb__depth1-container,\x20.gnb__menu-wrap.open\x20.gnb__depth1-container:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.estroe-main-s\x20.icon-contentFixed\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb__logo:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'deepskyblue',
        'mEyUw',
        'borderColor',
        'UEWud',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.select-kit-body,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.menu-panel\x20.widget-link:hover,\x20.menu-panel\x20.widget-link:focus,\x20.menu-panel\x20.categories-link:hover,\x20.menu-panel\x20.categories-link:focus\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'figure.thumb_new_image',
        'FuzTx',
        'ebay.app',
        'outerHTML',
        'CbLzY',
        'djMYd',
        '.model-image',
        'span.woocommerce-Price-amount',
        'uhjrR',
        'FNKWU',
        'iiaaq',
        'iCwDd',
        'XpTAI',
        '30ABRsZE',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20main[nitefall_imagetype=\x22svg\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'dJsKj',
        'ZyZpP',
        'replace',
        'zrRIA',
        'NiOkE',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mastbody_l,\x20.mastbody_c,\x20.mastfoot_c,\x20.mastbody_r,\x20.masthead_c,\x20.masthead_r,\x20.masthead_l\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'honeydew',
        'NZJTH',
        '.view-text',
        'sheet',
        'UxNtM',
        'prototype',
        'yKDlC',
        'saddlebrown',
        'uzbPb',
        'PTLqT',
        '.gradient-header',
        'mistyrose',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-widget\x20h3.ui-accordion-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.gal\x20.img',
        '.intercom-lightweight-app-launcher-icon',
        'ijHYr',
        'NOSCRIPT',
        '.title-dark-sea-blue',
        'LUTLE',
        'BQDmK',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.et-promoblock\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ghostwhite',
        'RGeiU',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#tcom-header\x20.main-navigation-bar\x20nav\x20li:first-child\x20svg,\x20.tcom-footer-logo\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vis\x20.vis-stacked-nav\x20.line\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20rgba(39,47,54,0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'removeProperty',
        'a.fl\x20span',
        'mPaLZ',
        'querySelector',
        'nitefall_image_invert_png_style',
        'yellow',
        'veRMu',
        '#avo-facets',
        'mBgcb',
        'gif',
        'EQkwo',
        'nitefall',
        'pnerN',
        'getAttribute',
        '._formSearch',
        'uXMwv',
        'BjzpC',
        'browser',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#content.grid2colb-box,\x20#ossmain\x20.box\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.box\x20.boxtop,\x20.box\x20.boxbottom\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'silver',
        'BGbkn',
        '[stroke]',
        '.galaxy-container',
        '.table-center\x20.box',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#appleid-signin-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Sso__appleIdContainer:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20::placeholder{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.CommentTree__tree.m-listing-below:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'aquamarine',
        '.bb-slider',
        'object',
        'rEgFP',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#onetrust-consent-sdk\x20#onetrust-banner-sdk\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header-nav-lacroix\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[id^=\x22reader.external-link.num\x22]\x20em{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'oldlace',
        '2551832qHONKq',
        'VVHVi',
        'buQTh',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button[data-action^=\x22auth:\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'parent',
        '.right',
        '.image-lazy-loaded',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20[dir=ltr]\x20.card-theme-module\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20[dir=ltr]\x20.app-body-container-auth:before,\x20[dir=ltr]\x20.app-body-container-landing:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'gzztL',
        'img[data-srcs]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.category-header\x20hgroup,\x20#content-body>div>section,\x20#content-body>section,\x20#content-aside\x20.tagline,\x20.cblocks\x20.cblock,\x20#ctree,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#content-main\x20hr.sec.alt-langs:after,\x20#content-main\x20.alt-langs-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ivory',
        'nociN',
        'wheat',
        'getElementById',
        'EuwcO',
        '.render-mode-BIGPIPE\x20code',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.menu-btn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'href',
        'cFsdJ',
        'ojGnQ',
        'PfCLe',
        '.banner__title',
        '.com.vn',
        'unknown',
        'svg',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label^=\x22Today\x22]\x20span[jsslot]\x20>\x20span,\x0a\x20\x20\x20\x20\x20\x20\x20\x20li[role=\x22listitem\x22]\x20span[jsslot],\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-selectedid=\x22browse_calendars\x22]\x20div[role=\x22presentation\x22],\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-selected-date]\x20>\x20div\x20>\x20span{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-selectedid=\x22browse_calendars\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'log',
        'li.notice\x20>\x20a[nitefall_imagetype=\x22gif\x22]',
        '.search-form\x20.search-input\x20.clear-btn.active',
        '.com.ec',
        'limegreen',
        'nYgMH',
        '.star-display',
        '.kix-page-paginated',
        'IbNsC',
        'top',
        'oHkXd',
        'BBSsX',
        'MFtDB',
        'CyvBo',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ant-typography\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'rZrdm',
        'ujVUG',
        'LKliS',
        'FrGNK',
        '2|3|6|5|0|4|1',
        'cLHbV',
        '.dcg-mq-cursor',
        'UyOUy',
        'unsus',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.uni-navigation--desktop\x20.uni-main-menu__submenu-wrapper:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.footer__social',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.button_icon:after,\x20.sprite_icon:after,\x20.button_tab:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'hmMil',
        'ZfXNk',
        'cIycM',
        'ZdzXy',
        '.sailthru-overlay-close',
        'file:///private/var/mobile/Containers/',
        'stopColor',
        'EbuVi',
        'ZxtXR',
        'yXFJG',
        '.MathJax_Preview',
        'uyrGp',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.quick-menu-swiper:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb-btn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'vKvDw',
        'parentNode',
        'aside.js-modal',
        'apple-mail-implicit-dark-support',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.logo-rf\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'hexString',
        'KfnxB',
        'CtAXd',
        'lightseagreen',
        '1|0|4|2|3',
        'src',
        'svg.bdl-CollapsibleSidebar-menuItemIcon',
        'SSyhM',
        'textColor',
        '16447849pIAdVg',
        'lemonchiffon',
        '.accordion-item__header\x20button',
        'error',
        'apple-mail-light-only',
        'nojZa',
        'ZSSOc',
        '\x0a\x20\x20\x20\x20/*\x20====================\x20end\x20of\x20css\x20for\x20',
        'ziqkh',
        'fZfCt',
        'li.clear\x20>\x20a[nitefall_imagetype=\x22gif\x22]',
        '13px',
        'indexOf',
        'white',
        'removing\x20dark\x20css',
        'CEnik',
        'theme-color',
        '.ctpx-box-bg\x20>\x20span',
        'text',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.navbar-default\x20.navbar-toggle\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.homepage-hero',
        'lightgreen',
        'xmlns',
        'darkorange',
        'qZFXP',
        'mediumseagreen',
        'linear-gradient',
        'UwrPw',
        'hSvhQ',
        'IKjgn',
        'blmrt',
        'qVHTA',
        'GxxSt',
        'none\x20!important',
        'YpVEE',
        'vsYjM',
        'div[data-eventid]',
        'Your\x20Nitefall\x20trial\x20has\x20expired.\x20Please\x20purchase\x20premium\x20from\x20Nitefall\x20main\x20app\x20to\x20use\x20on\x20it\x20on\x20an\x20unlimited\x20number\x20of\x20websites.',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.img_logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        '.com.',
        'azure',
        'ndVqo',
        'fCfAe',
        '.mjx-chtml',
        'SPAN',
        'WbguR',
        'includes',
        'HQcqE',
        'darkkhaki',
        'div[aria-label=\x22Loading\x22]',
        'XNegQ',
        'luminance',
        '.specList\x20label[for]',
        'bGtQj',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.question-page\x20.post-update-info,\x20.box,\x20#ground,\x20#header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'filter',
        'data',
        '4767435ZuwJIi',
        'innerHTML',
        '.slick-active',
        'sJTuX',
        'KQxfP',
        'darkblue',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product_button_wrap{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.search_btn\x20.search\x20button,\x20.basket\x20.btn_basket,\x20.top_menu\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20html\x20#aside\x20.categoryList\x20>\x20li\x20>\x20a.cate::after,\x20#center\x20a::after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header\x20.top_logo\x20.xans-layout-logotop\x20img,\x20#layout\x20.top_logo\x20.xans-layout-logotop\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.slide-logo\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.thumbnail\x20>\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20position:\x20initial\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.search_left\x20>\x20ul:first-child\x20li::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.App_cookieConsent:before,\x20div[data-testid=\x22appbar\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'XPBNR',
        'IWhee',
        'slateblue',
        'RmeRI',
        '.v-dialog__content',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ncbi-alerts\x20.ncbi-alert__shutdown-outer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.article-page\x20.article-details>.heading\x20.journal-actions\x20.journal-actions-trigger,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.article-page\x20.article-details>.keywords-section\x20.keyword-actions\x20.keyword-actions-trigger{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.static-filters\x20.side-timeline-filter\x20.inner-wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20transparent\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.static-filters\x20.side-timeline-filter\x20.toggle-button:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.search-form\x20.search-input\x20.clear-btn{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(1)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'oBLnS',
        'vMKYz',
        '\x20======================*/\x0a\x20\x20\x20\x20\x0a',
        'testing-dark-mode',
        'bisque',
        'lightyellow',
        'UNEwW',
        'addEventListener',
        'div[data-testid=\x22primary-nav\x22]',
        'chartreuse',
        'header\x20.Ngnb',
        '\x0a\x20\x20\x20\x20/*\x20====================\x20css\x20for\x20all\x20host\x20======================*/\x0a\x20\x20\x20\x20',
        'xqqjj',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#nyc-main-header\x20.toggle-search,\x20#nyc-main-header\x20.header-top\x20.toggle-mobile-side-nav,\x20#nyc-main-header\x20.header-top\x20.toggle-main-menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.css-40ap13:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20button\x20>\x20svg,\x20li\x20a[href*=\x22github.com\x22]\x20>\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'fill',
        '.com.tr',
        'AsyYS',
        'khaki',
        'Dadpw',
        'img.journal-logo',
        'game-tile',
        'QpKyN',
        'TQDNK',
        'aMCZo',
        'lightpink',
        'Uzbdn',
        'none',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20mark\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#917a11\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'documentElement',
        'img[data-breeze]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.kTWCIu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.AYowm\x20a,\x20.AYowm\x20button,\x20.hRBoHo,\x20.OZghr,\x20.gExOig\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'darkorchid',
        'wObdA',
        'data-eski-please-include-in-mobile-version',
        'com.apple.email.maild',
        'forEach',
        'vykZL',
        'default',
        '.wXUyZd',
        '#icon_search',
        'select',
        'uhUtY',
        'skyblue',
        'gBdFE',
        'weaDM',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-d,\x20.ui-overlay-d\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-b,\x20.ui-overlay-b\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-panel-position-right.ui-panel-display-reveal,\x20.ui-panel-position-right.ui-panel-open,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-panel-position-left.ui-panel-display-reveal,\x20.ui-panel-position-left.ui-panel-open\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.article-page\x20.article-details>.heading\x20.journal-actions\x20.journal-actions-trigger',
        'puMbH',
        'Pbjfn',
        '.entry-thumb',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ab_button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20form[action=\x22/search\x22]\x20:first-child\x20>\x20div[jsmodel]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[style^=\x27background-image:\x20url(\x22data:image/png;base64,iVBORw0KGgoAAAANSUh\x27]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.HOslld,\x20.mnr-c:not(:empty),\x20.MDLhlf{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x200\x200\x200\x201px\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sbib_b::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ml-searchbox-left-side-button-inner,\x20.ml-searchbox-right-side-button\x20.ml-icon-search{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20button[jsaction=\x22pane.homescreen.start\x22]\x20.noprint[nitefall_imageType=\x22png\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[id^=\x22section-directions-trip-travel-mode\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22gridcell\x22]\x20.suggest-icon-container{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mapsLiteJsControlsSettings__ml-settings-scroll\x20.ml-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mapsLiteJsControlsSettings__ml-settings-google-logo,\x20.ml-settings-drawer-region-section-google-logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(25%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20..mapsLiteJsStart__feedback{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(25%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ml-icon.ml-icon-chevron-up,\x20.ml-searchbox-button\x20.ml-icon-hamburger{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*\x20google\x20becoming\x20theme_color\x20after\x20closing\x20image\x20in\x20search*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20body.srp\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*gradient\x20on\x20google\x20search*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.P1Ycoe\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20-webkit-linear-gradient(0deg,transparent,transparent)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.KSfJec\x20.aXBZVd\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.FjdPod\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.YIMUJb,\x20.YsGUOb,\x20.ZseVEf,\x20.XCKyNd,\x20.i8Msie{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.w8qArf\x20.fl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cG5GOd{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.fl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#8d87d6\x20!important\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.yuRUbf\x20>\x20a[data-ved]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#8d87d6\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[data-ved]:visited,\x20a.fl:visited\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#cd82f2\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.iI6nue\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.NOiGgb\x20.sb-unsaved\x20svg,\x20.Rqu0ae\x20.cJC1zb-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*\x20material\x20textfield\x20bottom\x20border\x20on\x20google\x20forms\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20.quantumWizTextinputPaperinputUnderline\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.amFhOb,\x20.fes0he,\x20.fHujJ{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.XMHySb.MUxGbd.lyLwlc.lEBKkf,\x20div.MUxGbd.lNMe4.ZhSjR.aLF0Z\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20hr.BUybKe\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20opacity:\x200.2\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.ml-promotion.ml-promotion-on-screen.ml-pushup\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.highres\x20.searchbox-searchbutton::before,\x20img.searchbox-icon,.KY3DLe-settings-LgbsSe-icon,\x20.Liguzb-AHe6Kc\x20.Liguzb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sbox-focus\x20.sbib_b::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.section-cardbox\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22listitem\x22]\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20a\x20div[role=\x22heading\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20contrast(40%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-index]\x20a[href^=\x22https://www.youtube.com\x22]:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sbhl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20svg[aria-label=\x22Google\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pWEaFf\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20c-wiz\x20a\x20>\x20svg[fill=\x22none\x22],\x20a[href^=\x22https://accounts.google.com/ServiceLogin?\x22]\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Navigation\x20drawer\x22],\x20header\x20div[role=\x22menu\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-iso]:before,\x20div[data-iso]:after,\x20div[data-iso]\x20div[role=\x22button\x22]:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-hveid]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-top-left-radius:\x200px\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-top-right-radius:\x200px\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#rp_13\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mnr-c:not(:empty){\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-hveid]\x20div[style*=\x22background-color:\x20rgb(255,\x20255,\x20255);\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-hveid]\x20div[style*=\x22background-color:\x20rgb(255,\x20255,\x20255);\x22]\x20img[src^=\x22data:\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20hue-rotate(180deg)\x20invert(100%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20g-tray-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.zZnjCf,\x20.ccEnac,\x20.TkL5bb,.htyage\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.PxxJne,\x20.AHyjFe,\x20.NrF3hd,\x20.xVyTdb,\x20.wzUQBf,\x20.Q8lakc,\x20.pxFzCf,\x20.ZB3Ebc\x20.ZAGvjd,\x20.FEFWbc,.RCcRmb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ZB3Ebc\x20.ZAGvjd{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-webkit-text-fill-color\x20:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ml2Uge\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#storyline-menu-title\x20>\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'set',
        'dZJIh',
        '.mc-logo',
        'pmXhJ',
        'RyJBt',
        'tr.msg-read',
        'QkCMP',
        '.hamburger',
        'darkMaps',
        'DIbjd',
        'div[class^=\x22StyledComponents__DisabledOverlay-\x22',
        'sin',
        'BYRVQ',
        'powderblue',
        'darkgrey',
        'HnpHK',
        'UbEjP',
        'etDIq',
        'kxsNs',
        'http',
        '.player_container',
        'KCmRR',
        'QRzRL',
        'nitefall_pseudo_elements_style',
        'MXWRJ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#container,\x20.board-body\x20.title-line\x20>\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ZItho',
        'BIbkq',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.overview-card-wrapper,\x20.bg-white\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text-black,\x20.text-gray-800,\x20.prose.prose-doc\x20h3,\x20.prose.prose-doc\x20h1\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.prose\x20:where(code):not(:where([class~=not-prose]\x20*)),\x0a\x20\x20\x20\x20\x20\x20\x20\x20.prose\x20:where(a):not(:where([class~=not-prose]\x20*)),\x20.prose.prose-doc\x20h2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#4876d9\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'HPawV',
        'cOLoA',
        '.ndm-chart__image-anchor\x20svg',
        'palegreen',
        'aqua',
        '.photo_block',
        'GcBTX',
        'lightcyan',
        'zCWMV',
        '.svg-sign',
        'keys',
        'JwKTh',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ArticleHeader-wrapperHero:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'UimwN',
        'kuMuu',
        'img[loading=\x22auto\x22]',
        'span[id^=\x22MathJax-Element\x22]',
        'setProperty',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ver1.ver2\x20.ArticleHeaderApp\x20h2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-webkit-text-fill-color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[alt=\x22ynet-logo\x22],\x20.main-logo-icon-image{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[data-text=\x22true\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bm-burger-button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bm-burger-bars\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'oMrRb',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20suggest-table\x20.table-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ga-mobile-events-page\x20suggest-table\x20.table-suggest-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ga-viz-table\x20.ga-viz-table-default-background\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.iframed\x20.realtime-card.md-scionTheme-theme\x20.ga-data-table\x20.ga-viz-table-row-background\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20rgb(0,\x2087,\x20227)\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20g\x20text,\x20.ga-data-table\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'QwiII',
        'darkseagreen',
        'rwtJI',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20fieldset>a>div>div>select,\x20fieldset>a[href]>div>div\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAANCAYAAACQN/8FAAAAUElEQVQoz2NggIKysrI6EGbAB6CK/kNxHT6FLUgKQbiaaorb0RRXUK4YKCENxG+RFD4BYiFsim6jKVKhnSIWID6CVxGSYhWoAtyK0BTjVAQA7b9/uRuNojcAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'CxISl',
        'deeppink',
        'length',
        'NWuTL',
        '.title-mint',
        'border-color',
        'background',
        '.cm-line',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fig-media__container,\x20.fig-lazy\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#fh\x20.fh-top{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'shade',
        'ZCCPU',
        'CtssW',
        'maroon',
        'nHQzU',
        'YvsNe',
        'zecWr',
        'papayawhip',
        'a[href*=\x22search_mode=flex_destinations_search\x22]\x20>\x20span',
        'IsvrN',
        'test',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-d,\x20.ui-dialog.ui-overlay-d,\x20.ui-btn-up-d\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-bar-c\x20,\x20.ui-bar-b,\x20.ui-btn-up-c,\x20.ui-body-e,\x20.ui-dialog.ui-overlay-e,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-bar-d,\x20.ui-btn-down-d{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#maps_sb,\x20#id_hbfo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.MicrosoftMap\x20.taskBarPopout\x20.menuLinkIcon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'JAvDm',
        'rxYQI',
        'ywccx',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#page\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'floralwhite',
        'nfohw',
        'CVseC',
        'navy',
        'uFroC',
        'TvJZh',
        '.bus_layer',
        'jhnsd',
        'PvRbQ',
        'has',
        'hueRotate',
        'meta[name=\x22theme-color\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.AnimatedWordmark_image__EdH1l\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#__next\x20div[style^=\x22background-color:\x20rgb(2\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ol\x20div[style^=\x22background-image\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dropdown-wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#secGroupings,\x20#SecYearSelect,\x20span[role=\x22columnheader\x22],\x20#_ctrl0_ctl66_lblMailingListsText,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#_ctrl0_ctl66_chkLists\x20td\x20label,\x20#_ctrl0_ctl66_lblEmailAddressText,\x20.module_options-select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.module_input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.home-search\x20>\x20input[type=\x22search\x22],\x20.sidebar-search\x20>\x20input[type=\x22search\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'data-target',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#contents\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.post\x20h3,\x20#footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#ulCommentWidget\x20iframe,\x20.menu-btn\x20>\x20span{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'push',
        'sandybrown',
        'UendG',
        'peru',
        'BAYcD',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#content-thumbs,\x20#header\x20.topbar,\x20#header\x20#site-nav,\x20#video-content-metadata,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.video-page\x20#video-content-metadata\x20.tabs\x20.tab,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.x-thread\x20.thread-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.free-plate,\x20.gold-plate,\x20#header\x20#site-nav\x20ul,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.x-thread\x20.thread-node,.x-thread\x20.thread-node-btn,\x20.x-thread\x20.thread-node-btn\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.icon1\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20li\x20a.gold-plate\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20wheat\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'observe',
        'vjRaW',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cTopicOverview__preview:after,\x20.ortem-content\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '#salestrends\x20.nav-link',
        'min',
        'mediumaquamarine',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.oa_rd,\x20.search_error_wrap\x20.bx_atmp\x20.msg_atcmp\x20.spr_ico_msg2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'hotpink',
        'veSxE',
        '.button-modulebutton3Gm3c',
        'YcNwB',
        'RNBCh',
        'QcVrq',
        'rQaUa',
        'VfnZy',
        'lWrUZ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20*#dm\x20*.dmBody\x20div.u_1942127116\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20*#dm\x20*.dmBody\x20*.u_1942127116:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#layout-drawer-hamburger\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'UFmZY',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tlf_cdefinition\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20black\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.8)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'bgColors',
        'substr',
        '.article-page\x20.article-details>.keywords-section\x20.keyword-actions\x20.keyword-actions-trigger',
        'meta',
        'CANVAS',
        'lIJye',
        'flat',
        'url(',
        'bMGxW',
        'gejpD',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.id-MainNavigation-layer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.7)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'getContext',
        'WvKeM',
        'insertBefore',
        'LYkQw',
        'dpctN',
        'qzHSo',
        'Ywmkj',
        'PATH',
        'OzFSt',
        'CYutW',
        'SYyNw',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mw-page-base,\x20div.vectorTabs\x20span,\x20div.vectorTabs\x20ul\x20li,\x20#simpleSearch,\x20div.vectorTabs\x20ul\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.com.fr',
        'invertPng',
        '.nitefall_processed',
        'OzxZE',
        '#__next\x20.jwQWkK',
        '.static-filters\x20.side-timeline-filter\x20.inner-wrap',
        'img[data-ezsrc]',
        '\x20derived\x20from:\x20',
        'get',
        'steelblue',
        'nitefallHashCode',
        'ZbDWI',
        'data:image/jpeg',
        '#program-listing-body\x20tr',
        '.content-page__navigation__group__header',
        '#chart_beta',
        'LqTih',
        'shadowRoot',
        '2|0|3|5|1|6|4|7',
        'a[class^=\x22CollapsibleSidebarMenuItem__StyledLink\x22]\x20svg',
        'palevioletred',
        'referrer',
        'www.',
        'oWXaH',
        '0|4|5|2|1|3|6',
        '.ezlazyloaded',
        'NMpFO',
        'XegrF',
        'chctg',
        'moccasin',
        'diaSK',
        'red',
        'DdBXR',
        'FILTER_SKIP',
        '.hero-image.blankets',
        'svg[set=\x22weather\x22]',
        'palegoldenrod',
        '.com.cn',
        'salmon',
        'yzXfq',
        'iWwxS',
        'ilcsv',
        'olivedrab',
        'fillStyle',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html\x20body\x20#onetrust-consent-sdk\x20#onetrust-banner-sdk\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-ratings-bar,\x20.pip-product-information-section\x20.pip-chunky-header__icon,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-click-and-collect__icon,\x20.pip-stockcheck__icon,\x20.pip-btn__label,\x0a\x20\x20\x20\x20\x20\x20\x20\x20button[aria-label=\x22Save\x20to\x20shopping\x20list\x22]\x20>\x20span\x20>\x20svg{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-product-information-section\x20.pip-chunky-header__title,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-product-information-section\x20.pip-average-rating__reviews,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-header-section__title--big\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sidebar\x20.section-heading,\x20#specs-list\x20p,\x20#specs-list\x20table,\x20.user-thread\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.review-header::after,\x20.specs-photo-main:after{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'yYujn',
        'querySelectorAll',
        'sfDVl',
        'nkjpi',
        '.accordion-item',
        '\x0a\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20#app-container.vasquette:not(.app-imagery-mode):not(.app-globe-mode)\x20.widget-scene-canvas,\x20.gm-style\x20img[role=\x22presentation\x22]:not([src*=\x22v=\x22]),\x0a\x20\x20\x20\x20.wm-map__leaflet,\x20.leaflet-bottom,\x20.leaflet-popup-content-wrapper{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20#scene\x20img[decoding=\x22async\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20.map-centered\x20.map-pane\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20.wm-marker-label\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(255,\x20143,\x20131)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20/*\x20bing\x20maps\x20*/\x0a\x20\x20\x20\x20div.ms-composite\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20.leaflet-tile,\x20.leaflet-tile-loaded\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20.leaflet-popup-pane\x20.leaflet-popup,\x20.leaflet-popup-pane\x20.leaflet-popup-tip-container{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20',
        '.mwe-math-fallback-image-display',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.m-header\x20.m-logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sr-com-place\x20.com-place-one\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'html',
        'LFJVd',
        'QfOHI',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bismillah\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'mintcream',
        'qENFl',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.python-navigation\x20.super-navigation,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.donate-button:hover,\x20.header-banner\x20.button:hover,\x20.header-banner\x20a.button:hover,\x20.user-profile-controls\x20div.section\x20span:hover,\x20a.delete:hover,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20form.deletion-form\x20button[type=\x22submit\x22]:hover,\x20.search-button:hover,\x20#dive-into-python\x20.flex-control-paging\x20a:hover,\x20.text\x20form\x20button:hover,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text\x20form\x20input[type=submit]:hover,\x20.sidebar-widget\x20form\x20button:hover,\x20.sidebar-widget\x20form\x20input[type=submit]:hover,\x20input[type=submit]:hover,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20input[type=reset]:hover,\x20button:hover,\x20.button:hover,\x20.donate-button:focus,\x20.header-banner\x20.button:focus,\x20.header-banner\x20a.button:focus,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.user-profile-controls\x20div.section\x20span:focus,\x20a.delete:focus,\x20form.deletion-form\x20button[type=\x22submit\x22]:focus,\x20.search-button:focus,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#dive-into-python\x20.flex-control-paging\x20a:focus,\x20.text\x20form\x20button:focus,\x20.text\x20form\x20input[type=submit]:focus,\x20.sidebar-widget\x20form\x20button:focus,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sidebar-widget\x20form\x20input[type=submit]:focus,\x20input[type=submit]:focus,\x20input[type=reset]:focus,\x20button:focus,\x20.button:focus,\x20.donate-button:active,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header-banner\x20.button:active,\x20.header-banner\x20a.button:active,\x20.user-profile-controls\x20div.section\x20span:active,\x20a.delete:active,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20form.deletion-form\x20button[type=\x22submit\x22]:active,\x20.search-button:active,\x20#dive-into-python\x20.flex-control-paging\x20a:active,\x20.text\x20form\x20button:active,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text\x20form\x20input[type=submit]:active,\x20.sidebar-widget\x20form\x20button:active,\x20.sidebar-widget\x20form\x20input[type=submit]:active,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20input[type=submit]:active,\x20input[type=reset]:active,\x20button:active,\x20.button:active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.psf-widget\x20.button,\x20.python-needs-you-widget\x20.button,\x20.donate-button,\x20.header-banner\x20.button,\x20.header-banner\x20a.button,\x20.user-profile-controls\x20div.section\x20span,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.delete,\x20form.deletion-form\x20button[type=\x22submit\x22],\x20button[type=submit],\x20.search-button,\x20#dive-into-python\x20.flex-control-paging\x20a,\x20.text\x20form\x20button,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text\x20form\x20input[type=submit],\x20.sidebar-widget\x20form\x20button,\x20.sidebar-widget\x20form\x20input[type=submit],\x20input[type=submit],\x20input[type=reset],\x20button,\x20a.button,\x20.button,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.python-navigation\x20.subnav,\x20.jobs-navigation\x20.subnav\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tds-form-input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.content-page__title-bar',
        'lmVMi',
        'PUUqg',
        'GzLpu',
        'peachpuff',
        'img[data-lazy-srcset]',
        'pdAyB',
        'BjTRA',
        'BWpUQ',
        'only',
        'HESIw',
        'gptgV',
        'iuvbn',
        'hrgAy',
        '*[nitefall_imageType],\x20img\x20{transform:\x20translateZ(0);\x20filter:\x20brightness(',
        'vRSUY',
        'getPropertyValue',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#contentarea,\x20#contentarea2,\x20ul.menu\x20li\x20a:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        ':before',
        '.accordion-item__body__container',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mobile-header-components\x20.nav-icon:before,\x20.mobile-header-components\x20.nav-icon:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mobile-header-components\x20.nav-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'lCuav',
        'ahyFy',
        'nitefall_processed',
        'JaOvT',
        '6IFkVhz',
        'ptSUl',
        'substring',
        'RlWDe',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20header.clearfix\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cd__headline-text\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Header__burgerIcon,\x20.Header__burgerIcon::before,\x20.Header__burgerIcon::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.SocialBar__icon{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        ':after',
        'NCFVN',
        'svg[data-visualcompletion=\x22ignore-dynamic\x22]',
        'PeDEH',
        'beige',
        'QCqXq',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#article,\x20#header{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '#dropDownMenuButton\x20.moreButton',
        'darkcyan',
        '.mw-ui-icon-wikimedia-language-base20',
        '[stop-color]',
        'KXfII',
        'stringify',
        'SzWWw',
        '.icon-contentFixedh5s',
        'gVlxL',
        'SICDN',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.JyscU{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20._8-yf5,\x20img[alt=\x22Instagram\x22],\x20.glyphsSpriteFriend_Follow\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg[aria-label=\x22Audio\x20is\x20playing\x22],\x20svg[aria-label=\x22Audo\x20is\x20muted.\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg[aria-label=\x22Tags\x22],\x20svg[aria-label=\x22Video\x20has\x20no\x20audio.\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg[fill=\x22#ed4956\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'OLdGk',
        '#ca-watch',
        'QcZRR',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header-wrap,\x20#page\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.promo-area\x20.bg-wool-light\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.cytyle-flat\x20#escape',
        '.swiper-wrapper',
        'styleSheets',
        'TWAzj',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.k_head\x20.tit_pay\x20.ico_logo,\x20.k_head\x20.btn_menu,\x20a.btn_close\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'AkmAM',
        'stroke',
        'SbPzC',
        'Qgask',
        'string',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.primary_logo,\x20.mobile_logo_inside,\x20.icon-cart,\x20.icon-menu,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mm-menu.mm-theme-white\x20.mm-listview>li\x20.mm-next:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'zzumF',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.logo\x20.cnsmr-app-image,\x20#appstore\x20.icon___3r8jH,\x20.itc-logo-alt{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20body.login-type-asc.login-page\x20#pageWrapper,\x20body.login-type-asc.login-page\x20#footer::before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#appstore\x20.sticky-header___1_Y3q:before,\x20#appstore\x20.section-container___GYtsI\x20.sticky-header___O648q:before,\x20.isdumPw,\x20.footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#sub-nav\x20._2b7H8wl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#testflight\x20.sticky-header___1_Y3q:before,\x20#testflight\x20.section-container___GYtsI\x20.sticky-header___O648q:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.messageList\x20li.selected\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#salestrends\x20.nav-link:hover{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#46a9ff\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.audience-review__default-image',
        'tEhea',
        'MVisC',
        'BAqhY',
        'IfINq',
        'ZlRNZ',
        '.paginate',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.scroll-y,\x20.container,\x20#background-content,\x20ion-title\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'concat',
        'toUpperCase',
        'FxzJG',
        'VJSUN',
        'QquQv',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-d,\x20.ui-dialog.ui-overlay-d,\x20.ui-btn-up-d\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-bar-c\x20,\x20.ui-bar-b,\x20.ui-btn-up-c,\x20.ui-body-e,\x20.ui-dialog.ui-overlay-e,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-bar-d,\x20.ui-btn-down-d{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.postbitlegacy\x20.postfoot\x20a.newreply,\x20.postbit\x20.postfoot\x20a.newreply\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.notices\x20li\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#866e00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.navtabs\x20li.selected\x20a.navtab\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'SVG',
        '[fill]',
        'png',
        'postMessage',
        'qdvUn',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20body.not-front\x20div.header-top-inner2{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#ffd600\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'kLHKp',
        '0|3|2|1|4',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mw-page-base\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#searchInput\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mw-ui-icon-wikimedia-menu-base20:before,\x20.mw-ui-background-icon-menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'JceWz',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.top-header,\x20.inner-section-video:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.section_nav_v2\x20.next-nav,\x20.wrap-main-nav.sticky\x20.main-nav\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mini-suggest__popup_old-style_yes.mini-suggest__popup::after,\x20.promo-popup__content,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.serp-user__registration-button.button2[class]::before,\x20.check-button_theme_normal:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.radio-button_view_classic.radio-button_theme_normal\x20.radio-button__radio:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.button2_view_classic.button2_theme_normal:before,\x20.button2_theme_default::before,\x20.header3__clear\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.serp-header__logo\x20.logo.logo_name_yslogo-en-86x35,\x20.logo-wrapper__logo_name_ys-en,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header3__logo\x20svg,.m-svg\x20.logo__image_bg,\x20.yandex-search__logo,\x20a.logo{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.7)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.serp-footer__link:before,\x20.region-change__link:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.competitors__link:first-child::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.actions__button_action_refresh\x20.actions__button-image,\x20.actions__button_action_audio\x20.actions__button-image{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transaprent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.submit\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#cba306\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.advanced-search\x20.input__clear[class],\x20.mini-suggest_expanding_yes.mini-suggest_expanded::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20[class].header3__input:-webkit-autofill,[class].header3__input::-webkit-textfield-decoration-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.i-ua_js_no\x20[class].header3__input,\x20.header3__layout\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header3__layout,\x20.Theme_color_yandex-default\x20.Button2_view_raised:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.images-viewer-tabs\x20.images-viewer-tabs__tabs-menu\x20.images-viewer-tabs__tab.tabs-menu__tab:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mini-suggest_expanding_yes.mini-suggest_expanded\x20.mini-suggest__input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header3__service_current::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header3__input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.9)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.directblock_native\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.yandex-search__form::after,\x20.yandex-search__form::after,\x20.yandex-search__form::before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-left-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'zswfX',
        'wZVng',
        'cssRules',
        'hUXVx',
        'AlAtO',
        'NbpXS',
        '<svg\x20xmlns=\x22',
        'location',
        'img[data-src]',
        'item',
        '.PageSECFilings\x20.pane--banner',
        'indianred',
        '.PNG',
        '3|5|0|6|1|8|4|2|9|7',
        '#FeaturedRoundupCountdown',
        'RLmRs',
        '.faq-page-header__title',
        'a.focus-logo',
        '.com.br',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.diff\x20table.inline\x20tbody.mod\x20td.r,\x20.diff\x20table.inline\x20tbody.add\x20td.r\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#004a00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.diff\x20table.trac-diff\x20td\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x20!important',
        'RRhiB',
        'call',
        'div',
        'chocolate',
        'ejXRo',
        'sOmyg',
        'darkred',
        'textContent',
        'HmECf',
        'nitefall_imageType',
        'eMZBG',
        '.svg',
        '.cytyle-flat\x20#controls',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*\x20this\x20is\x20a\x20full\x20page\x20css\x20because\x20this\x20website\x20uses\x20eski\x20mobi\x20which\x20replaces\x20the\x20whole\x20document\x20html\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20@media\x20(prefers-color-scheme:\x20dark)\x20{\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20html,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20:not([style*=\x22background-color:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20html,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.sr-reader\x20*:not([class*=\x27sr-pivot\x27])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h1:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h2:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h3:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h4:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h5:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h6:not([style*=\x22color:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20cite:not([style*=\x22color:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(232,\x20255,\x20228)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:not([style*=\x22background-color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20[role=\x22button\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(59,\x2075,\x2088)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-color:\x22]):hover,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-color:\x22]):hover,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:not([style*=\x22background-color:\x22]):hover,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20[role=\x22button\x22]:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(55,\x2079,\x20101)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-color:\x22]):active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-color:\x22]):focus,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-color:\x22]):active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-color:\x22]):focus,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:not([style*=\x22background-color:\x22]):active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:not([style*=\x22background-color:\x22]):focus,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20[role=\x22button\x22]:active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20[role=\x22button\x22]:focus\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(53,\x2080,\x20105)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a:not([style*=\x22color:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(230,\x20255,\x20255)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a:not([style*=\x22color:\x22]):hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(218,\x20247,\x20255)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a:not([style*=\x22color:\x22]):active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a:not([style*=\x22color:\x22]):focus\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(206,\x20240,\x20255)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20:not([style*=\x22border-color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20::before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-color:\x20rgb(145,\x20165,\x20172)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div:empty,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.sr-reader\x20*,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.sr-backdrop\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgba(28,\x2031,\x2033,\x200.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input::placeholder,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea::placeholder\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgba(255,\x20249,\x20212,\x200.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-image:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-image:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.ibutton\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20rgba(28,\x2031,\x2033,\x200.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'KoBNF',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#accs_survey_offer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#936d0b\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#container.psp\x20#main\x20#more-results-wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#container.psp\x20#more-results-button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.featured\x20.top-results.dt-thumbnail\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'VhIzC',
        '.dotnav',
        'KcJbX',
        'ZjQRU',
        'OXaiT',
        '.shareIcon1280',
        '.ProseMirror',
        'rsJrd',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.jqm-navmenu-link,\x20.jqm-navmenu-panel\x20.ui-btn:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.jqm-navmenu-panel\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'cQGkD',
        'rPPFn',
        '4ljpoxf',
        '#gMenu_outer',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.field\x20.text-input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#nasName\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#appLinks\x20div,\x20#mappLinks\x20div,\x20#tools-frame\x20.field\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'CwfMs',
        'img',
        '.SVG',
        'uKoit',
        '#ca-edit',
        '.kix-zoomdocumentplugin-outer',
        'xnLvo',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.close-btn-container,\x20.report_income_by_category_3,\x20.amount-expense\x20\x20i,\x20span.item-navigation,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn-jump-today,\x20.icon-search,\x20\x20.search-border\x20i\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.search-border{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20rgba(250,\x20250,\x20250,\x200.2)\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'DksTa',
        '.sc_option\x20.sc_view',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.w_header\x20.b_menu\x20strong,\x20.w_header\x20.w_aside\x20.b_close\x20strong,\x20.b_home\x20strong,\x20\x20.b_scrap\x20strong,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.b_live\x20strong,\x20.w_header\x20.w_aside\x20.w_quick\x20a.b_schedule\x20strong:before,\x20.w_header\x20.w_aside\x20.w_quick\x20a\x20strong:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.navbar-default[_ngcontent-c0],\x20.well[_ngcontent-c2],\x20.panel-default[_ngcontent-c2]\x20>\x20.panel-heading[_ngcontent-c2]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'RcrEF',
        'darkMode',
        'awaCU',
        'FlWTJ',
        'tLuPE',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.v-application\x20.grey.lighten-5,\x20.theme--light.v-light,\x20.theme--light.v-card,\x20.theme--light.v-sheet{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.v-btn__content,\x20.theme--light.v-list-item:not(.v-list-item--active):not(.v-list-item--disabled),\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme--light.v-card,\x20.v-application\x20.black--text,\x20.v-application\x20.grey--text.text--darken-3,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme--light.v-card\x20.v-card__subtitle,\x20.theme--light.v-card>.v-card__text{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.MyIcon\x20i[data-v-2e1cc9c9]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'SKKbi',
        'div[data-sf-element=\x22Accordion_Title\x22]',
        'invert\x20png\x20for\x20',
        '.onesignal-bell-svg',
        'RcWrl',
        'host',
        'lawngreen',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.table2\x20th\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '#app-boot-bg-loader',
        'fBLNu',
        'script[src*=\x22eBay.app\x22]',
        'TchWL',
        'DwMpA',
        'midnightblue',
        '#searchIcon',
        '.lozad',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.eSfmjG,\x20.FSTEV,\x20.eRZbqB,\x20.card-header\x20>\x20div,\x20div[class^=\x22UserAppStats__StatTitleSection\x22]\x20>\x20div,\x20div[class^=\x22UserAppStats__Stat-\x22],\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[class^=\x22AppTile__ComingSoonText-\x22],\x20div[class^=\x22Profile__PhoneText\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-webkit-text-fill-color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[class^=\x22NewUserAccount__AccountMenu-\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[class^=\x22Header__LogoImage-\x22],\x20a[class^=\x22footerLinks_logo\x22]\x20img{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'tagNam',
        '.id-HeaderDoubleGum-actions',
        '.table-maybe',
        'content',
        'ZtYnr',
        '#bottom_ribbon_modal_wrapper',
        'orangered',
        'royalblue',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.g81fxb.ROuVee,\x20.g81fxb.sxlEM{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'LGjTs',
        'DsfyJ',
        'lime',
        'ntMjQ',
        'map',
        'taAjL',
        'DfjuP',
        'a[id^=\x22powered_by_pixlee\x22',
        'olive',
        'slategray',
        'PvMvT',
        'max',
        '.copy-to-clipboard-button',
        '[style]',
        '.com.pt',
        '.com.ve',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bg-master\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bg-white,\x20.form-select,\x20.form-input,\x20bg-gray-100:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.form-select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pack-header-image\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'HPEGA',
        'div[class^=\x22listItem-\x22]\x20svg',
        'slategrey',
        'error\x20extracting\x20svg\x20colors\x20',
        'kEvZu',
        'abs',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#docs-editor.companion-enabled\x20#waffle-grid-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20hue-rotate(180deg)\x20invert(100%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.kix-paginateddocumentplugin\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20hue-rotate(180deg)\x20invert(100%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#kix-current-user-cursor-caret\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(50%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#t-formula-bar-input\x20.cell-input,\x20.cell-input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.docs-grille-gm3\x20#docs-chrome:not(.docs-hub-chrome),\x20.docs-grille-gm3\x20#docs-header:not(.docs-hub-appbar)\x20.docs-titlebar-buttons\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'disableTemporarily',
        'dodgerblue',
        'userAgent',
        'lJDRE',
        'active',
        '#mw-mf-main-menu-button',
        'isLight',
        'mFNQT',
        'vOedl',
        '*[class^=\x22Overlay__overlay__\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'textColors',
        'COrRg',
        'fstEZ',
        'QdLlv',
        'ssPjW',
        'FYcjS',
        'HtiaZ',
        'oWPkF',
        '.search-modal',
        'image/svg+xml',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tl_article.tl_article_edit\x20[data-placeholder].empty:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tl_article.tl_article_edit\x20[data-label]:after,\x20.tl_article.tl_article_edit.title_focused\x20[data-label].empty:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.cytyle-flat\x20#output',
        'FttoV',
        'toString',
        'nodeName',
        'snow',
        'RGzNu',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bubble-action\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#0366d6\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.reponav-item\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgba(255,255,255,0.75)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text-white\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#fff\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20strong.list-item-title\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#0366d6\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.list-item\x20.byline\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#586069\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.user-following-container\x20.btn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20linear-gradient(-180deg,\x20theme_sub_color\x200%,\x20theme_sub_color\x2090%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.btn.btn-outline.border-gray-dark.width-full.f6.mt-3\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20linear-gradient(-180deg,\x20theme_sub_color\x200%,\x20theme_sub_color\x2090%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.SelectMenu-modal,\x20.dropdown-menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'startsWith',
        'turquoise',
        'springgreen',
        'rWnSQ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20h2,\x20h3\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.icon-xbox-game-studios',
        'ofsxQ',
        'OaRjk',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22tablist\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'dvBwq',
        'Priek',
        'qcGYf',
        'RbqFe',
        'COrOp',
        'classList',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.yalm\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'OROor',
        'backgroundColor',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.package-header\x20.name{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'cRPQS',
        'dark-gray',
        'lnWiN',
        '.ant-card-body',
        '.entry-title',
        'Yhixs',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#canvas-navigation,\x20#canvas-sidebar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'label[role=\x22checkbox\x22]',
        'iFwHL',
        '.bm-burger-bars',
        '.JPG',
        'PmsEv',
        'amazon.',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.amp-fn-content,\x20.amp-fn-content-wrapper\x20p\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.amp-wp-title-bar\x20.hamburger\x20span,\x20.a-icon-comments-black:before,\x20.lrv-u-cursor-pointer:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'vTXRM',
        'yandex.',
        'vbQnR',
        'aPeEz',
        'plum',
        '843046sgRrzz',
        'abGkM',
        'FILTER_ACCEPT',
        'culQf',
        '-color',
        'wSapI',
        'ytm-custom-control\x20#player-control-overlay',
        'IFRAME',
        'ilhBV',
        'a[slot=\x22logo\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#ac-globalnav\x20.ac-gn-link-apple-developer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'tepmO',
        'jauVI',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-c,\x20.ui-overlay-c\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.primary-link',
        'rgba(',
        'Izgeo',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20table.halytyslista\x20tr.halytys\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.date-outer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'IBnfB',
        'background-color',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fix\x20.gnb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header.section.fix\x20.hd_cafe_v2\x20h1,\x20.header.section.fix\x20h1,\x20.header.section.fix\x20h1\x20span,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb\x20h1\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb\x20a.gnb_search:after,\x20.header.section.fix\x20.gnb\x20a.gnb_search:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb\x20a.gnb_ham:after,\x20.header.section.fix\x20.gnb\x20a.gnb_ham:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb\x20a.gnb_home:after,\x20.header.section.fix\x20.gnb\x20a.gnb_home:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.side_menu\x20header\x20.btn_list\x20.btn_cafe\x20a:before,\x20.side_menu\x20header\x20.btn_list\x20.btn_write\x20a:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.side_menu\x20header\x20.btn_list\x20.btn_news\x20a:before,\x20.side_menu\x20header\x20.btn_list\x20.btn_talk\x20a:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.side_menu\x20.menu_first\x20.all:before,\x20.side_menu\x20.menu_first\x20.popular:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.side_menu\x20.menu_first\x20.popular_member:before,\x20.side_menu\x20.menu_first\x20.cafe_tag:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'seagreen',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.toggle__label::after{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.show-more-less-html__markup::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#app-boot-bg-loader,\x20.loading-bg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pv-profile-sticky-header__container,\x20.artdeco-card{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.feed-follows-module-recommendation__description\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.banner__image\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.page-header,\x20nav.fixed\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'meta[name=\x27color-scheme\x27]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#program-listing\x20tr:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#register-tab-view\x20.input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'BzdWr',
        '\x0a\x20\x20\x20\x20/*\x20====================\x20end\x20of\x20css\x20for\x20all\x20host\x20======================*/\x0a\x0a\x20\x20\x20\x20/*\x20====================\x20css\x20for\x20',
        '.module_container',
        'resolve',
        '.ecs-facet-wrapper',
        'header\x20.gnb',
        'svg.bdl-CollapsibleSidebar-logoIcon',
        'YPndr',
        '.actions__button-image',
        'fuchsia',
        '.swiper-slide',
        'bottom',
        'lightslategray',
        'tydgS',
        'pink',
        'jipPy',
        'PHFMY',
        'img[loading=\x22lazy\x22]',
        'smbiE',
        'qARZr',
        'vYrgk',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.buy__dropdown>ul.active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x205px\x20solid\x20#2f2a2a\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20ul.active\x20.buy__variant{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'function',
        'lavender',
        'quuEk',
        'ZVKLN',
        'lzDiz',
        't.co',
        'jkFpO',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#body-wrap:not(.cactus-box)\x20#cactus-body-container>.cactus-sidebar-control.sb-ct-medium.sb-ct-small>.cactus-container:not(.ct-default):before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cactus-sidebar:before,\x20#body-wrap:not(.cactus-box)\x20.cactus-sidebar-control.sb-ct-medium\x20.main-content-col:after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#body-wrap:not(.cactus-box)\x20.cactus-sidebar-control.sb-ct-small\x20.cactus-container:not(.ct-default)\x20.main-content-col:before,\x20.cactus-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pdf\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'wNMlj',
        '#top_search',
        'cyan',
        '#id-MainNavigation',
        '.refract-container\x20.addition\x20pre.source',
        'qrpkI',
        'znsyA',
        'gcVWp',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.background-layer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'google.',
        'PsUkz',
        '12HprhlI',
        '.bundle_sc\x20.u_hc',
        '.lazyload',
        'UkZSt',
        '.slick-slide',
        '.filter-INTERIOR',
        'WahMW',
        'UgyjJ',
        'MvmVq',
        'HBsSr',
        '.header',
        'UoXas',
        'applewebdata://',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20the\x20*\x20background\x20color\x20rule\x20has\x20to\x20be\x20first\x20because\x20it\x20will\x20updated\x20to\x20real\x20page\x20color\x20as\x20soon\x20we\x20fetch\x20the\x20settings\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20',
        '.ndfHFb-c4YZDc-j7LFlb',
        'nitefall_image_invert_pdf',
        'FScMp',
        'blue',
        'slice',
        'fqXDg',
        '.module-item',
        'join',
        'OaGHp',
        '_0xd79f86_0xdaeae5_0x1fe767\x20>\x20_0xd35a0e',
        '.highcharts-root',
        '4|5|1|0|3|2',
        'RtBBu',
        'mediumpurple',
        'JborK',
        'zvGvt',
        '#000000',
        '.blocks-gallery-item\x20figure',
        'jBTel',
        'UcHPE',
        '.LinkCard',
        'gold',
        'Zebra/',
        'KksSk',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.hx\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bd_btn,\x20.btn_img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'gIIbH',
        '.br-lazy',
        'antiquewhite',
        'qUqyg',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bundle_sc\x20.u_hc,\x20.dsc\x20.u_hc{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'sprgH',
        'getSVGColors',
        'fOnfI',
        'nABEC',
        '.comment-gray',
        'ZBxAR',
        'DMWyx',
        'LPfLg',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme-ekstrabladet\x20.dre-item--skin-yellow\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#b7b707\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.docs-sheet-tab-name',
        '.tl_main_logo',
        '.menu-text',
        '#waffle-grid-container',
        'orange',
        'div.tile',
        'IXyyP',
        'url',
        'rTvMB',
        '.related-products\x20.gallery-item\x20.product-img.orange-color',
        'rules',
        'jGFPw',
        '20ORgynd',
        'XUdXK',
        'cornflowerblue',
        'cEYzf',
        'pYdML',
        '.lazy-image-placeholder',
        'mUnNc',
        'GQmVt',
        'ISnvi',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb_header_area__1B3hK,\x20._3FXlRFu_o6,\x0a\x20\x20\x20\x20\x20\x20\x20\x20._header_header_REoTl,\x20.co_header_fix,\x20.header_header__3Owj1\x20,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.g_header\x20.g_header_area{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20._1-E6pu5hXf\x20._2484Ldw4O8\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#c1a90d\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.searchInput_search_wrap__21YH1\x20.searchInput_input_area__3LdQZ:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.g_search\x20.g_input_area:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.g_lnb:before,\x20.g_btn_service:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb_header_area__1B3hK\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.nav\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comp_promotion\x20.cp_channel_event\x20.cp_channel::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comp_promotion\x20.cp_event_area\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrap.id_search\x20.comp_container.type_square_card\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.shm_ico_npay,\x20.shm_ico_notify,\x20.shm_ico_qrcheckin,\x20.sch_ico_aside,\x20.ah_close,\x20.ah_link_theme,\x20#MM_SEARCH_BACK,\x20.HeaderGnbLeft\x20.icon-logo-naver-cafe,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn_back\x20.icon_back,\x20.footer_list\x20.footer_logo,\x20.header\x20.lang\x20.lang_select::after,\x20.header\x20.lang\x20.lang_select::before,\x20.icon_pw,\x20.icon_id\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.HeaderTabList\x20.tab_link[aria-selected=true]:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.HeaderTabList\x20.tab_menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.valori_wrapper\x20.valore_attributo',
        '.lazy',
        'pSEhN',
        'g-img',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20h4#draft,\x20h4#non-standard\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:transparent\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.notecard.draft,\x20.notecard.experimental,\x20.notecard.secure,\x20.notecard.warning{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:#b19e00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-color:#b19e00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.copy-icon,\x20.search-button{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bc-platforms\x20.bc-platform-desktop:before,\x20.bc-platforms\x20.bc-platform-mobile:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bc-browsers\x20.bc-head-txt-label:before,\x20.ic-footnote:before,\x20a.external:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20ul.main-menu\x20.top-level-entry:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'div[class^=\x22informers__icon\x22',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.coto_slide-button.prev:after,\x20.coto_slide-button.next:after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ctpx-testimonials\x20.slick-slider\x20.slick-arrow.slick-prev:before,\x20.ctpx-testimonials\x20.slick-slider\x20.slick-arrow.slick-next:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sub-nav-arrow,\x20.coto_short-stack\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.stars\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.main-nav,\x20.ui-autocomplete,\x20.nav-dropdown\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'nextSibling',
        'h3.LC20lb',
        'www.finam.ru',
        'sATpV',
        'lavenderblush',
        'zunIf',
        'AqRCW',
        'forestgreen',
        'bYKNy',
        '.character-slide-image',
        'EFTiW',
        'ohYOD',
        'ardvU',
        '.attachment-woocommerce_thumbnail',
        '.jpg',
        '.thumbnail',
        'from',
        'firstChild',
        'arnAM',
        '#chart_final',
        'createTreeWalker',
        'ABJzd',
        'GQkwG',
        'XFNXJ',
        '-width',
        '.bg-mint',
        'rpYkr',
        'DOMContentLoaded',
        'data:image',
        'DINTK',
        'dUxRG',
        'kIBTF',
        '.tlf_cdefinition',
        'dBmfz',
        'OfoGu',
        'UCxNz',
        'aOLGg',
        'lightcoral',
        'DQPjb',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product-icon[nitefall_imagetype=\x22svg\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'greenyellow',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#menu_logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20control-layer-group\x20>\x20*,\x20control-measure-group\x20>\x20*,\x20control-export-group\x20>\x20*{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20control-layer-group\x20>\x20*\x20>\x20button,\x20control-measure-group\x20>\x20*\x20>\x20button,\x20control-export-group\x20>\x20*\x20>\x20button,\x20.btn_location,\x20.btn_zoom_in,\x20.btn_zoom_out{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn_share\x20>\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.oa_rd,\x20.search_error_wrap\x20.bx_atmp\x20.msg_atcmp\x20.spr_ico_msg2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'GrdUw',
        '.mwe-math-element',
        'darkslateblue',
        'WgTro',
        'TGrQw',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.searchfield_input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#dictionarySelector\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(122,\x20111,\x209)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'fHXTA',
        'ohxAA',
        'rBEVD',
        'wKcoL',
        'className',
        '.btn[_ngcontent-c2]\x20.caret[_ngcontent-c2]',
        'enabled',
        'wESrk',
        'Iedqs',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-tags-item[data-a-63b685b3],\x20.c-navs-scroll-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-container,\x20.c-row,\x20#head_wrapper,\x20.wrapper_new\x20#head,\x20#head,\x20.head_wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20.se-page-hd\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-tags-item[data-a-63b685b3]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-text-box-gray,\x20.darkmode\x20.c-text-box-gray,\x20.defaultmode\x20.c-text-box-gray\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20wheat\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fy-dictwisenew-icon__3tlXQ,.call:after,\x20.voice:after,\x20.callicon-wrap\x20.baiduapp-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-tags-container\x20.c-tags-scroll-right-mask[data-a-63b685b3]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.item-menu\x20svg:not(.menu-item-arrow),\x20.BulkAddToCollectionsFlyout-addToCollectionsButtonIcon,\x20.files-page\x20.icon-ellipsis,\x20.itemList-OneClickShareButton\x20>\x20span{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ItemListActions\x20.btn:not(.btn-primary):not(.create-dropdown-menu-toggle-button)\x20.btn-content{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Body.is-deja-blue\x20.table.has-hover-styles\x20.table-body\x20.table-row:not(.is-selected).hover-styles,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Body.is-deja-blue\x20.table.has-hover-styles\x20.table-body\x20.table-row:not(.is-selected):hover,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Body.is-deja-blue\x20.table.has-hover-styles\x20.table-body\x20.table-row.is-selected,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.menu-item:not([aria-disabled]):focus,\x20.menu-item:not([aria-disabled]):hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'pfYOl',
        'catch',
        'sEHen',
        'data:image/svg+xml',
        'llMWj',
        'bzctY',
        '.bx-custom-pager',
        'rxxbl',
        'indigo',
        'OLPdB',
        'darkturquoise',
        'Jdtpm',
        'trim',
        'licenseNumber',
        'DIV',
        'nRMOY',
        'head',
        'yqWDI',
        'ul\x20.shortcut-tile',
        'UusAA',
        'Dqram',
        'lightgray',
        'hMQGj',
        'RDOwW',
        'img.picture-image',
        'WRSOs',
        '.btn-mint',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.button-modulebutton3Gm3c.button-modulevariantLight1f21J\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.age_and_budget_ranges-modulebuttonDescription18jdo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.appearance_selector-modulethumbnail2lNyP.appearance_selector-moduleactiveL8SRl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'nitefall_dark_maps',
        'addListener',
        'SCRIPT',
        '.solve-button',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fire-appbar\x20.app-bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fire-stacked-card::before\x20,\x20fire-stacked-card::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'LOxix',
        'gUTFN',
        'vxdzT',
        'visitedWebsites',
        'sjfaX',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#coral_thread\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'XdajA',
        'ETuKE',
        '.timeline-filter\x20.download-results-by-year-button',
        'dimgray',
        'nitefall-custom-css',
        'Zzknk',
        'STYLE',
        'NtyNz',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.repo-gh\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20code[class*=language-],\x20pre[class*=language-]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'kDslt',
        'bKUBi',
        'ZVEox',
        'img[decoding=\x22async\x22]',
        'JnMBz',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22button\x22]\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a[href*=\x22/intl/en/about/products?\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'dxqNH',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#gnb_mobile\x20.t_menu_onw\x20.pre_page,\x20#gnb_mobile\x20.t_menu_onw\x20.t_search\x20.btn_search,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#gnb_mobile\x20.all_menu,\x20body.oneapp\x20#gnb_mobile\x20.menu_nav.menu_nav_onw\x20.menu_close,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20#gnb_mobile\x20.menu_nav.menu_nav_onw.menu_new_ver\x20.menu_search,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#gnb_mobile\x20.t_menu_onw\x20.search_chatbot\x20.search_sec_in\x20.btn_mirror,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.layer_cardComplete_wrap\x20.layer_cardComplete.v220208\x20.layer_close{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20.gnb_banner_wrap\x20.type_link.chatbot_wrap,\x20#footer.footer_onw\x20.awards:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'GlCeM',
        'TfQPz',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-testid*=\x22structured-search-input-field-split-dates-\x22]:hover::after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-testid=\x22structured-search-input-field-guests-button\x22]:hover::after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20label[for=\x22bigsearch-query-detached-query\x22]:hover::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'BKNXG',
        'charCodeAt',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.title-bar\x20.logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.4)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment-gray\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.newlist_normal\x20.title_newlist_normal\x20.comment-gray\x20i.fa.fa-comment\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAABYklEQVQokd2SMUvDUBDH/4nP60FpDR0eqFnEzdXNbyC4+Qn8Lo4Ogs5OfgDd3DqIjopQLE4ORiJFQ0yipO+ZRK5NhwqFipsHB493d7/7v3vnpGl6FATBnjGmifmtIqKe7/unTr/fDzqdzjIRuVLuuu5clDzPP6IoCpUxZpWZf9F8bMzcNMasz9dutjl/BeAfABQRFXmeu8zs/AyWZTmz0BhTEFEsi3QQBMGGMWbL87wlz/OmEuM4Fq8AFPXVO4BXIop83792qqqSJVgBcBiG4U5RFE673Z4UW2Z+1FpfAXgAEAG4BPAM4EtEKgBDAE8AbhuNxnaWZUqkJ0lSMvO91nofQBdAKisMwE7NQJZBSABeiGhorVVJkmTM3NNanwC4APBZ54kv1PkCGwHkIN5VSt1Ya9darda51voMwF0dW6yVyq9NQCObzMDUsN3BYLCptT4G8FYXSkzeKy4AUTBWAQy/Ac4mjxRGs3sdAAAAAElFTkSuQmCC\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tel_item\x20.detail_tel_item\x20.buttons_container\x20.btn:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'theme_sub_color',
        'setAttribute',
        'button.input__settings',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.well,\x20.panel-default>.panel-heading\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'yYrWW',
        'yAegy',
        'iCnER',
        'bSFPO',
        'PoPoA',
        '.fhr_mobLogo',
        'weEpQ',
        'whitesmoke',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.jw-reset.jw-button-container{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'Nefol',
        'appendChild',
        'ESQSa',
        'eeCAf',
        '.gif',
        'paleturquoise',
        '.amp-fn-content-wrapper\x20p',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20pre,\x20.pre-lang\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#2e2e00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.accordion-item__header',
        'LkDZy',
        'WSVwV',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mobileBtns\x20li,\x20#mobileBtnsBot\x20li,\x20.button_last,\x20.calendar_img,\x20#septa_main_content\x20ul.subnav\x20li.normal\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.button_beg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#septa_left_navigation\x20form#septa_location_destination_planner\x20p.septa_trip_planner_apps\x20.planner_button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'XTGZx',
        'rosybrown',
        'purple',
        '.noUi-connect',
        'then',
        'jKODm',
        'darkslategray',
        'XpQTd',
        'muTBn',
        'NVUxx',
        'DOzBN',
        'SvQyp',
        'nitefall_image_dim_style',
        'yCaBV',
        'UUHgF',
        'lightsteelblue',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.id-MainNavigation-layer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.7)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'left',
        '3830292XtYivO',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#loignPanel\x20{background:\x20theme_sub_color\x20!important;}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20table.loginarea\x20input[type=\x22submit\x22],\x20table.loginarea\x20input[type=\x22submit\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#article\x20#commentaire,\x20#article\x20#links,\x20#article\x20#retroviseur,\x20#article\x20.cadre,\x20#article\x20.springboard,\x20#article\x20.pub,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#article\x20article,\x20#article\x20h1.listeTitle,\x20#pagination,\x20#search,\x20#search-title,\x20#tagcloud,\x20#team,\x20.auteurInfo,\x20#article\x20#shareit\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header-wrapper,\x20#UH-0-UH-0-MobileHeader\x20>\x20div,\x20#UH-0-UH-0-TabletHeader\x20>\x20div\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#closebtn\x20>\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'saturation',
        '.voice-search-button',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrap\x20header\x20.area-bottom\x20.header-more\x20.btn-aside,\x20.wrap\x20header\x20.area-bottom\x20.header-more:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrap\x20header\x20.area-bottom\x20.header-more:after,\x20.wrap\x20header\x20.area-bottom\x20.header-more:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrap\x20header\x20.area-bottom\x20.header-more\x20.btn-aside\x20.name{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20span.nav-logo-base\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.1)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'darkolivegreen',
        'RGHtY',
        'style',
        'button.toast',
        'CeqMa',
        'WUXkv',
        'lp-rich-link',
        '.jpeg',
        'AsGsC',
        'DHOBh',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.textwidget\x20li\x20>\x20a{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header-blue,\x20#the-footer,\x20#sidebar\x20.widget\x20h4,\x20.footer-widget\x20.widget\x20h4,\x20#sidebar\x20h3,\x20.footer-widget\x20h3,\x20#main-wrapper\x20table.gsc-search-box{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#031928\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'firebrick',
        'HhuGZ',
        'WABYX',
        'ftjqS',
        'div[data-testid=\x22messenger_hotlike_svg\x22]',
        'matches',
        'name',
        'data:image/png',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pn-page--front:last-of-type,\x20.pn-page--front:first-of-type\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'llBIg',
        'gzwaL',
        'WSeLd',
        'UsEEo',
        'monokai',
        'exports',
        'TJNzG',
        'closest',
        'com.some.email.app',
        'wMuwJ',
        'Fmxuf',
        'rgb',
        '\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.localinfomap,\x20.LocalInfo:before,\x20.LocalInfo:after,\x20.ThemePoiControlView\x20h3,\x20.ThemePoiControlView\x20.poi_item\x20span,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.MapTypeControl,\x20.MapTypeControl\x20.ACTIVE,\x20.Tool\x20.tit_tool,\x20.tit_login,\x20.ThemePoiControlView\x20.Wrap\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.viewbuttons\x20.rv,\x20.viewbuttons\x20.lv-accessibility,\x20.MapControlView\x20.accessLocation,\x20.MapControlView\x20.tools,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.MapControlView\x20.tools\x20a,\x20.viewbuttons\x20.lv\x20.list_map_setting\x20i,\x20.MapControlView\x20.extension,\x20.MapControlView\x20.add_place\x20.link_new,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.FlagWrap\x20.Flag,\x20.Flag\x20a,\x20.Flag-drag\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'UzJYF',
        'a.read_more',
        'LLwDV',
        '221894MsuwDw',
        'important',
        'invertPdf',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ql-img-inline-formula,\x20button.toast\x20*,\x20.toast:after,\x20.toast:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'thistle',
        'OVtcF',
        'RAVUW',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.knockout-image,\x20.product-card__thumbnail-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20mix-blend-mode:\x20unset\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'etLds',
        'FsDEB',
        'IWGXH',
        'header.page-header\x20.page-header-image\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20z-index:\x20auto\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.section-3,\x20.view-replay-term-page\x20.attachment-after\x20.view-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.item_title,\x20.item_hot_topic_title,\x20.normal.button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#DigitalOcean,\x20#LogoMobile,\x20#Logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'iLaOw',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*\x20auction\x20page\x20on\x20ebay*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pc_template\x20>\x20.pastore_top_background\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pnl\x20.msg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#0062ab\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-std,\x20.c-std-bb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#glbfooter{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20tr.msg-read,tr.msg-unread\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20tr.msg-read:hover,tr.msg-unread:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20tr.msg-read\x20.m-cur\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20tr.msg-unread\x20.m-cur\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn-ter{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#glbfooter{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sticky-header,\x20.m-items-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.hmNwsSpe1'
    ];
    _0x2ba5 = function () {
        return _0x1c78a0;
    };
    return _0x2ba5();
}
function _0x4c3d(_0x58880c, _0xc9b4bb) {
    var _0x2ba54b = _0x2ba5();
    return _0x4c3d = function (_0x4c3db1, _0x634195) {
        _0x4c3db1 = _0x4c3db1 - 0x134;
        var _0xcda8b6 = _0x2ba54b[_0x4c3db1];
        return _0xcda8b6;
    }, _0x4c3d(_0x58880c, _0xc9b4bb);
}
const defaultedSettingForHost = _0x3d84bc => {
        var _0xae8b24 = _0x4a728d, _0x2d3697 = {
                'dvBwq': function (_0x5a972a, _0x3e60f3) {
                    return _0x5a972a === _0x3e60f3;
                }
            };
        return !_0x3d84bc && (_0x3d84bc = {
            'darkMode': !![],
            'invertPng': ![],
            'imageBrightness': 0x1
        }), _0x3d84bc['darkMode'] = _0x2d3697[_0xae8b24(0x36c)](_0x3d84bc[_0xae8b24(0x30e)], undefined) ? !![] : _0x3d84bc[_0xae8b24(0x30e)], _0x3d84bc[_0xae8b24(0x234)] = _0x3d84bc[_0xae8b24(0x234)] === undefined ? ![] : _0x3d84bc[_0xae8b24(0x234)], _0x3d84bc[_0xae8b24(0x5a9)] = _0x2d3697[_0xae8b24(0x36c)](_0x3d84bc[_0xae8b24(0x5a9)], undefined) ? 0x1 : _0x3d84bc['imageBrightness'], _0x3d84bc;
    }, getSettings = async _0x383b99 => {
        var _0x119b55 = {
            'OzFSt': function (_0x4baecd, _0x32c712) {
                return _0x4baecd === _0x32c712;
            },
            'jGFPw': function (_0x5b08f2, _0x182de8) {
                return _0x5b08f2 === _0x182de8;
            },
            'IWGXH': function (_0x3e1d41, _0x27a9a9) {
                return _0x3e1d41 === _0x27a9a9;
            },
            'FNKWU': function (_0x5bc7e8, _0x55a51c) {
                return _0x5bc7e8(_0x55a51c);
            },
            'eWsyq': function (_0x26f39e, _0x1e7da2) {
                return _0x26f39e(_0x1e7da2);
            }
        };
        return new Promise((_0x28f9c8, _0x323e10) => {
            var _0x1c8661 = _0x4c3d;
            let _0x571e21 = DELUMINATOR_SETTINGS_STRING;
            _0x571e21[_0x1c8661(0x456)] = _0x119b55[_0x1c8661(0x22f)](_0x571e21[_0x1c8661(0x456)], undefined) ? !![] : _0x571e21[_0x1c8661(0x456)], _0x571e21[_0x1c8661(0x5f1)] = _0x119b55[_0x1c8661(0x22f)](_0x571e21['theme'], undefined) ? _0x1c8661(0x377) : _0x571e21[_0x1c8661(0x5f1)], _0x571e21['visitedWebsites'] = _0x119b55['OzFSt'](_0x571e21[_0x1c8661(0x47f)], undefined) ? [] : _0x571e21[_0x1c8661(0x47f)], _0x571e21[_0x1c8661(0x4f2)] = _0x119b55[_0x1c8661(0x40d)](_0x571e21[_0x1c8661(0x4f2)], undefined) ? ![] : _0x571e21['invertPdf'], _0x571e21[_0x1c8661(0x1a9)] = _0x119b55[_0x1c8661(0x4fa)](_0x571e21[_0x1c8661(0x1a9)], undefined) ? !![] : _0x571e21[_0x1c8661(0x1a9)], _0x383b99 && (_0x571e21[_0x383b99] = _0x119b55[_0x1c8661(0x601)](defaultedSettingForHost, _0x571e21[_0x383b99])), _0x119b55['eWsyq'](_0x28f9c8, _0x571e21);
        });
    }, getSettingForHost = async _0x2b0324 => {
        var _0x5a0a1d = _0x4a728d, _0x40d50f = {
                'IKjgn': function (_0x3cefd4, _0xcd00ab) {
                    return _0x3cefd4(_0xcd00ab);
                }
            };
        let _0x330f4e = await _0x40d50f[_0x5a0a1d(0x142)](getSettings, _0x2b0324);
        return _0x330f4e[_0x2b0324];
    }, saveSetting = async (_0x6b4acc, _0x1c1954) => {
        var _0x28a94a = {
            'TPClB': function (_0x1ea5fb) {
                return _0x1ea5fb();
            }
        };
        let _0x4bac90 = await _0x28a94a['TPClB'](getSettings);
        _0x4bac90[_0x6b4acc] = _0x1c1954, saveSettings(_0x4bac90);
    }, getSetting = async (_0x2b07c0, _0x1bf655) => {
        var _0x41c45a = _0x4a728d, _0xd5ebc1 = {
                'kxsNs': function (_0x4a5722) {
                    return _0x4a5722();
                },
                'TTtZn': function (_0x270f15, _0x5dd6a5) {
                    return _0x270f15 === _0x5dd6a5;
                }
            };
        let _0xe566a5 = await _0xd5ebc1[_0x41c45a(0x1b3)](getSettings), _0x5744dd = _0xe566a5[_0x2b07c0];
        return _0xd5ebc1['TTtZn'](_0x5744dd, undefined) ? _0x1bf655 : _0x5744dd;
    }, saveSettings = async _0x1ba28c => {
    }, isLicenseStringOriginal = _0x400a90 => {
        var _0x15a791 = _0x4a728d;
        let _0x4c1bab = _0x400a90[_0x15a791(0x5e1)]('__');
        if (_0x4c1bab[_0x15a791(0x1d9)] < 0x2)
            return ![];
        let _0x3cbd31 = _0x4c1bab[0x0], _0x1fb8d1 = _0x4c1bab[0x1], _0x43752f = _0x3cbd31[_0x15a791(0x23d)]();
        return _0x43752f == _0x1fb8d1;
    }, hasPremium = _0x3a0775 => {
        var _0x4755b9 = _0x4a728d, _0x47207b = {
                'QIDWI': function (_0xe90bfb, _0x3091d0) {
                    return _0xe90bfb(_0x3091d0);
                }
            };
        let _0x4beeed = _0x3a0775[_0x4755b9(0x468)];
        if (!_0x4beeed)
            return ![];
        return _0x47207b['QIDWI'](isLicenseStringOriginal, _0x4beeed);
    }, hasTrialExpired = _0x11e973 => {
        var _0x33ffc0 = _0x4a728d, _0x4eac28 = {
                'OaRjk': function (_0x2cfac1, _0x1e5f68) {
                    return _0x2cfac1(_0x1e5f68);
                }
            };
        if (_0x4eac28[_0x33ffc0(0x36a)](hasPremium, _0x11e973))
            return ![];
        if (_0x11e973[_0x33ffc0(0x47f)][_0x33ffc0(0x1d9)] > NUM_ALLOWED_WEBSITES_FOR_TRIAL)
            return !![];
        return ![];
    }, isAllowedToUseExtension = _0x416ab4 => {
        var _0x421c09 = _0x4a728d, _0x3b7c9c = {
                'JborK': function (_0x22dbaa, _0x1986c1) {
                    return _0x22dbaa(_0x1986c1);
                }
            };
        return _0x3b7c9c[_0x421c09(0x3e9)](hasPremium, _0x416ab4) || !_0x3b7c9c[_0x421c09(0x3e9)](hasTrialExpired, _0x416ab4);
    }, getMainDomain = _0x45a539 => {
        var _0x57cec3 = _0x4a728d, _0x5729fc = {
                'FuzTx': _0x57cec3(0x2e0),
                'BfqWG': _0x57cec3(0x258),
                'IbNsC': _0x57cec3(0x662),
                'uFsHw': _0x57cec3(0x233),
                'Mvlkx': '.com.tw',
                'RlWDe': _0x57cec3(0x33b),
                'ETnQa': _0x57cec3(0x65b),
                'HmECf': function (_0x32809b, _0xd7132c) {
                    return _0x32809b + _0xd7132c;
                },
                'EpzgD': _0x57cec3(0x14c)
            };
        (_0x45a539[_0x57cec3(0x529)]('.com.au') || _0x45a539[_0x57cec3(0x529)](_0x5729fc[_0x57cec3(0x5f9)]) || _0x45a539[_0x57cec3(0x529)](_0x5729fc[_0x57cec3(0x50e)]) || _0x45a539[_0x57cec3(0x529)](_0x5729fc[_0x57cec3(0x667)]) || _0x45a539[_0x57cec3(0x529)](_0x5729fc['uFsHw']) || _0x45a539[_0x57cec3(0x529)](_0x57cec3(0x17c)) || _0x45a539[_0x57cec3(0x529)](_0x5729fc['Mvlkx']) || _0x45a539[_0x57cec3(0x529)](_0x5729fc[_0x57cec3(0x28d)]) || _0x45a539[_0x57cec3(0x529)](_0x57cec3(0x33c)) || _0x45a539['endsWith'](_0x5729fc['ETnQa'])) && (_0x45a539 = _0x45a539[_0x57cec3(0x28c)](0x0, _0x5729fc[_0x57cec3(0x2eb)](_0x45a539[_0x57cec3(0x6a1)](_0x5729fc[_0x57cec3(0x5bf)]), 0x4)));
        let _0x423226 = _0x45a539[_0x57cec3(0x609)](/^(?:[a-z0-9\-\.]+\.)??([a-z0-9\-]+)(?:\.com|\.mu|\.net|\.org|\.biz|\.ws|\.in|\.me|\.co\.uk|\.co|\.org\.uk|\.ltd\.uk|\.plc\.uk|\.me\.uk|\.edu|\.mil|\.br\.com|\.cn\.com|\.eu\.com|\.hu\.com|\.no\.com|\.qc\.com|\.sa\.com|\.se\.com|\.se\.net|\.us\.com|\.uy\.com|\.ac|\.co\.ac|\.gv\.ac|\.or\.ac|\.ac\.ac|\.af|\.am|\.as|\.at|\.ac\.at|\.co\.at|\.gv\.at|\.or\.at|\.asn\.au|\.com\.au|\.edu\.au|\.org\.au|\.net\.au|\.id\.au|\.be|\.ac\.be|\.adm\.br|\.adv\.br|\.am\.br|\.arq\.br|\.art\.br|\.bio\.br|\.cng\.br|\.cnt\.br|\.com\.br|\.ecn\.br|\.eng\.br|\.esp\.br|\.etc\.br|\.eti\.br|\.fm\.br|\.fot\.br|\.fst\.br|\.g12\.br|\.gov\.br|\.ind\.br|\.inf\.br|\.jor\.br|\.lel\.br|\.med\.br|\.mil\.br|\.net\.br|\.nom\.br|\.ntr\.br|\.odo\.br|\.org\.br|\.ppg\.br|\.pro\.br|\.psc\.br|\.psi\.br|\.rec\.br|\.slg\.br|\.tmp\.br|\.tur\.br|\.tv\.br|\.vet\.br|\.zlg\.br|\.br|\.ab\.ca|\.bc\.ca|\.mb\.ca|\.nb\.ca|\.nf\.ca|\.ns\.ca|\.nt\.ca|\.on\.ca|\.pe\.ca|\.qc\.ca|\.sk\.ca|\.yk\.ca|\.ca|\.cc|\.ac\.cn|\.com\.cn|\.edu\.cn|\.gov\.cn|\.org\.cn|\.bj\.cn|\.sh\.cn|\.tj\.cn|\.cq\.cn|\.he\.cn|\.nm\.cn|\.ln\.cn|\.jl\.cn|\.hl\.cn|\.js\.cn|\.zj\.cn|\.ah\.cn|\.gd\.cn|\.gx\.cn|\.hi\.cn|\.sc\.cn|\.gz\.cn|\.yn\.cn|\.xz\.cn|\.sn\.cn|\.gs\.cn|\.qh\.cn|\.nx\.cn|\.xj\.cn|\.tw\.cn|\.hk\.cn|\.mo\.cn|\.cn|\.cx|\.cz|\.de|\.dk|\.fo|\.com\.ec|\.tm\.fr|\.com\.fr|\.asso\.fr|\.presse\.fr|\.fr|\.gf|\.gs|\.co\.il|\.net\.il|\.ac\.il|\.k12\.il|\.gov\.il|\.muni\.il|\.ac\.in|\.co\.in|\.org\.in|\.ernet\.in|\.gov\.in|\.net\.in|\.res\.in|\.is|\.it|\.ac\.jp|\.co\.jp|\.go\.jp|\.or\.jp|\.ne\.jp|\.ac\.kr|\.co\.kr|\.go\.kr|\.ne\.kr|\.nm\.kr|\.or\.kr|\.li|\.lt|\.lu|\.asso\.mc|\.tm\.mc|\.com\.mm|\.org\.mm|\.net\.mm|\.edu\.mm|\.gov\.mm|\.ms|\.nl|\.no|\.nu|\.pl|\.ro|\.org\.ro|\.store\.ro|\.tm\.ro|\.firm\.ro|\.www\.ro|\.arts\.ro|\.rec\.ro|\.info\.ro|\.nom\.ro|\.nt\.ro|\.se|\.si|\.com\.sg|\.org\.sg|\.net\.sg|\.gov\.sg|\.sk|\.st|\.tf|\.ac\.th|\.co\.th|\.go\.th|\.mi\.th|\.net\.th|\.or\.th|\.tm|\.to|\.com\.tr|\.edu\.tr|\.gov\.tr|\.k12\.tr|\.net\.tr|\.org\.tr|\.com\.tw|\.org\.tw|\.net\.tw|\.ac\.uk|\.uk\.com|\.uk\.net|\.gb\.com|\.gb\.net|\.vg|\.sh|\.kz|\.ch|\.info|\.ua|\.gov|\.name|\.pro|\.ie|\.hk|\.com\.hk|\.org\.hk|\.net\.hk|\.edu\.hk|\.us|\.tk|\.cd|\.by|\.ad|\.lv|\.eu\.lv|\.bz|\.es|\.jp|\.cl|\.ag|\.mobi|\.eu|\.co\.nz|\.org\.nz|\.net\.nz|\.maori\.nz|\.iwi\.nz|\.io|\.la|\.md|\.sc|\.sg|\.vc|\.tw|\.travel|\.my|\.se|\.tv|\.pt|\.com\.pt|\.edu\.pt|\.asia|\.fi|\.com\.ve|\.net\.ve|\.fi|\.org\.ve|\.web\.ve|\.info\.ve|\.co\.ve|\.tel|\.im|\.gr|\.ru|\.net\.ru|\.org\.ru|\.hr|\.com\.hr)$/, '$1'), _0x3e8bc8 = _0x45a539[_0x57cec3(0x28c)](_0x5729fc[_0x57cec3(0x2eb)](_0x45a539[_0x57cec3(0x6a1)](_0x423226), _0x423226['length']));
        return _0x423226 + _0x3e8bc8;
    };
function NFColor(_0x3d0ca5, _0x3436e7, _0x42cfae, _0x1917f8) {
    var _0x11a2bb = _0x4a728d, _0x1b1814 = {
            'Pbjfn': function (_0x154cda, _0x152073) {
                return _0x154cda == _0x152073;
            },
            'MXWRJ': function (_0x2771e1, _0x409907) {
                return _0x2771e1 + _0x409907;
            },
            'UNEwW': function (_0x120eef, _0x3f8e68) {
                return _0x120eef + _0x3f8e68;
            },
            'vbQnR': function (_0x55ff5b, _0x40de24) {
                return _0x55ff5b + _0x40de24;
            },
            'GMhyE': function (_0x5c9d86, _0x876f10) {
                return _0x5c9d86 + _0x876f10;
            },
            'GrdUw': 'rgb(',
            'JnMBz': function (_0x4fe6ec, _0x16aa16) {
                return _0x4fe6ec + _0x16aa16;
            },
            'obhQe': function (_0xc1401a, _0x453a47) {
                return _0xc1401a + _0x453a47;
            },
            'DZTsC': function (_0x4788e3, _0x5efea) {
                return _0x4788e3 + _0x5efea;
            },
            'ZBxAR': function (_0x507cad, _0x2f7fa2) {
                return _0x507cad + _0x2f7fa2;
            },
            'QfOHI': function (_0x24393a, _0x4bdeb0) {
                return _0x24393a + _0x4bdeb0;
            },
            'nIdkr': function (_0x3349ed, _0x54ebb6) {
                return _0x3349ed + _0x54ebb6;
            },
            'NtyNz': _0x11a2bb(0x398),
            'tydgS': function (_0x4c75f9, _0x239a0e) {
                return _0x4c75f9 + _0x239a0e;
            },
            'QSFBb': function (_0x441f7e, _0x1c5626) {
                return _0x441f7e + _0x1c5626;
            },
            'vYrgk': function (_0x567449, _0x3648a3) {
                return _0x567449 | _0x3648a3;
            },
            'ABJzd': function (_0x2fc736, _0x56ae00) {
                return _0x2fc736 + _0x56ae00;
            },
            'xVEIB': function (_0x4f4b23, _0x4e6b91) {
                return _0x4f4b23 << _0x4e6b91;
            },
            'NpPco': function (_0x3cc1c2, _0x243b5a) {
                return _0x3cc1c2 | _0x243b5a;
            },
            'iWwxS': function (_0x8c2771, _0x37109d) {
                return _0x8c2771 << _0x37109d;
            },
            'OjnnY': function (_0x3a724e, _0xd6038b) {
                return _0x3a724e | _0xd6038b;
            },
            'DIbjd': function (_0x46c35a, _0x41bf89) {
                return _0x46c35a << _0x41bf89;
            },
            'NiOkE': function (_0x1f7acf, _0x23a20a) {
                return _0x1f7acf === _0x23a20a;
            },
            'lCuav': function (_0x1c2cd5, _0x563c7d) {
                return _0x1c2cd5 / _0x563c7d;
            },
            'BKNXG': function (_0x54191c, _0x37127f) {
                return _0x54191c - _0x37127f;
            },
            'YcNwB': function (_0x4de915, _0x16aa93) {
                return _0x4de915 > _0x16aa93;
            },
            'skhTy': function (_0x581fd3, _0x411d24) {
                return _0x581fd3 >> _0x411d24;
            },
            'grtxZ': function (_0x3da8c2, _0x5d89c5) {
                return _0x3da8c2 + _0x5d89c5;
            },
            'Nefol': function (_0x205f4f, _0x13c29f) {
                return _0x205f4f * _0x13c29f;
            },
            'KfnxB': _0x11a2bb(0x2db),
            'diaSK': function (_0x35f2de, _0x2f120c) {
                return _0x35f2de + _0x2f120c;
            },
            'pmXhJ': function (_0x5357c0, _0x48e129) {
                return _0x5357c0 * _0x48e129;
            },
            'IWhee': function (_0x3952a3, _0x17e8ba) {
                return _0x3952a3 - _0x17e8ba;
            },
            'OaGHp': function (_0x245df4, _0xf8611a) {
                return _0x245df4 < _0xf8611a;
            },
            'ardvU': function (_0x3c856c, _0x34b4c9) {
                return _0x3c856c / _0x34b4c9;
            },
            'BzdWr': function (_0x251717, _0x32d813) {
                return _0x251717 * _0x32d813;
            },
            'SbPzC': '6|20|10|0|25|9|24|23|22|26|11|1|14|3|17|27|2|7|4|21|8|5|19|16|15|12|18|13',
            'iCwDd': function (_0x55b953, _0x517c2f, _0x2589e0) {
                return _0x55b953(_0x517c2f, _0x2589e0);
            },
            'oHkXd': function (_0x52c0e5, _0xa94c1b) {
                return _0x52c0e5 - _0xa94c1b;
            },
            'CwfMs': function (_0x8f5632, _0x282233) {
                return _0x8f5632 * _0x282233;
            },
            'Dkbii': function (_0x330676, _0x4b19e3) {
                return _0x330676 * _0x4b19e3;
            },
            'LFJVd': function (_0x2c8107, _0x5663ed) {
                return _0x2c8107 + _0x5663ed;
            },
            'fiqmZ': function (_0x5e81b3, _0x1d4b81) {
                return _0x5e81b3 - _0x1d4b81;
            },
            'oWPkF': function (_0x868e65, _0x40a91d) {
                return _0x868e65 * _0x40a91d;
            },
            'ZJGkn': function (_0x48afa6, _0x40eb59) {
                return _0x48afa6 - _0x40eb59;
            },
            'sFIWY': function (_0x8be77f, _0x1ec935) {
                return _0x8be77f * _0x1ec935;
            },
            'BBSsX': function (_0xb794ca, _0x1610a2) {
                return _0xb794ca - _0x1610a2;
            },
            'rEgFP': function (_0xac6fa8, _0x27b378) {
                return _0xac6fa8 - _0x27b378;
            },
            'UendG': function (_0x23663d, _0x3cce7c) {
                return _0x23663d + _0x3cce7c;
            },
            'tPpBs': function (_0x3e90e6, _0x25728d) {
                return _0x3e90e6 % _0x25728d;
            },
            'cECWc': function (_0x856e76, _0x538f5a) {
                return _0x856e76 + _0x538f5a;
            },
            'YPndr': function (_0xac235c, _0x3c4e38) {
                return _0xac235c * _0x3c4e38;
            },
            'qVHTA': function (_0x3a97d6, _0x2975cf) {
                return _0x3a97d6 * _0x2975cf;
            },
            'AlAtO': function (_0x31200c, _0x5aa995) {
                return _0x31200c / _0x5aa995;
            },
            'ilcsv': function (_0x328db0, _0x4cbf55) {
                return _0x328db0 + _0x4cbf55;
            },
            'FYcjS': function (_0x30f7b3, _0x15a450) {
                return _0x30f7b3 + _0x15a450;
            },
            'Priek': function (_0x4a2fa5, _0x1e50e6) {
                return _0x4a2fa5 * _0x1e50e6;
            },
            'wyoti': function (_0x14e9a8, _0x560a2b) {
                return _0x14e9a8 + _0x560a2b;
            },
            'vOedl': function (_0x3887ac, _0x2ad5b8) {
                return _0x3887ac - _0x2ad5b8;
            },
            'HBsSr': function (_0x204134, _0x3483db) {
                return _0x204134 + _0x3483db;
            }
        };
    this['r'] = _0x3d0ca5, this['g'] = _0x3436e7, this['b'] = _0x42cfae, this['a'] = _0x1917f8, this['rgbString'] = function () {
        var _0x23a5ff = _0x11a2bb;
        return _0x1b1814[_0x23a5ff(0x19d)](this['a'], 0x1) ? _0x1b1814[_0x23a5ff(0x1b9)](_0x1b1814[_0x23a5ff(0x1b9)](_0x1b1814[_0x23a5ff(0x1b9)](_0x1b1814[_0x23a5ff(0x172)](_0x1b1814[_0x23a5ff(0x386)](_0x1b1814[_0x23a5ff(0x5ac)](_0x1b1814[_0x23a5ff(0x44a)], this['r']), ','), this['g']), ','), this['b']), ')') : _0x1b1814[_0x23a5ff(0x48f)](_0x1b1814[_0x23a5ff(0x5e7)](_0x1b1814[_0x23a5ff(0x501)](_0x1b1814[_0x23a5ff(0x501)](_0x1b1814[_0x23a5ff(0x3fe)](_0x1b1814[_0x23a5ff(0x26b)](_0x1b1814['nIdkr'](_0x1b1814[_0x23a5ff(0x489)] + this['r'], ','), this['g']), ','), this['b']), ','), this['a']), ')');
    }, this[_0x11a2bb(0x68c)] = function () {
        var _0x492227 = _0x11a2bb;
        return _0x1b1814[_0x492227(0x3b0)]('#', _0x1b1814['QSFBb'](_0x1b1814[_0x492227(0x3b7)](0x0, _0x1b1814['ABJzd'](_0x1b1814[_0x492227(0x533)](0x1, 0x8), this['r']))[_0x492227(0x35e)](0x10)['substr'](0x1), _0x1b1814['NpPco'](0x0, _0x1b1814[_0x492227(0x434)](_0x1b1814[_0x492227(0x25b)](0x1, 0x8), this['g']))[_0x492227(0x35e)](0x10)['substr'](0x1)) + _0x1b1814[_0x492227(0x5ec)](0x0, _0x1b1814[_0x492227(0x434)](_0x1b1814[_0x492227(0x1aa)](0x1, 0x8), this['b']))[_0x492227(0x35e)](0x10)[_0x492227(0x21d)](0x1));
    }, this[_0x11a2bb(0x5ab)] = function () {
        var _0x3a1a83 = _0x11a2bb;
        return _0x1b1814[_0x3a1a83(0x60b)](this['a'], 0x0);
    }, this[_0x11a2bb(0x4c8)] = function () {
        var _0x2a1f4a = _0x11a2bb, _0xba94f9 = Math[_0x2a1f4a(0x338)](this['r'], Math[_0x2a1f4a(0x338)](this['g'], this['b'])), _0x362f51 = Math['min'](this['r'], Math['min'](this['g'], this['b']));
        return _0x1b1814[_0x2a1f4a(0x286)](_0x1b1814[_0x2a1f4a(0x496)](_0xba94f9, _0x362f51), _0xba94f9);
    }, this[_0x11a2bb(0x565)] = function () {
        var _0x2f3961 = _0x11a2bb;
        return _0x1b1814[_0x2f3961(0x213)](this['saturation'](), 0.2);
    }, this[_0x11a2bb(0x158)] = function () {
        var _0x411398 = _0x11a2bb;
        return _0x1b1814[_0x411398(0x503)](_0x1b1814['grtxZ'](_0x1b1814[_0x411398(0x4a6)](this['r'], 0x3) + this['b'], _0x1b1814[_0x411398(0x4a6)](this['g'], 0x4)), 0x3);
    }, this[_0x11a2bb(0x34c)] = function () {
        var _0x121903 = _0x11a2bb;
        return _0x1b1814['YcNwB'](this[_0x121903(0x158)](), 0x64);
    }, this[_0x11a2bb(0x1e0)] = function (_0x4a445e) {
        var _0x242a53 = _0x11a2bb, _0x5799b2 = _0x1b1814[_0x242a53(0x68d)][_0x242a53(0x5e1)]('|'), _0x1515d8 = 0x0;
        while (!![]) {
            switch (_0x5799b2[_0x1515d8++]) {
            case '0':
                var _0xebf6a3 = _0x1b1814[_0x242a53(0x251)](this['b'], _0x1b1814[_0x242a53(0x1a4)](_0x1b1814[_0x242a53(0x167)](0x100, this['b']), _0x4a445e) / 0x64);
                continue;
            case '1':
                _0x3ade5b = _0x1b1814[_0x242a53(0x3e3)](_0x3ade5b, 0x0) ? 0x0 : _0x3ade5b;
                continue;
            case '2':
                _0x3ade5b = _0x1b1814['YcNwB'](_0x3ade5b, 0xff) ? 0xff : _0x3ade5b;
                continue;
            case '3':
                var _0x3cfd1e = _0x1b1814[_0x242a53(0x251)](this['r'], _0x1b1814[_0x242a53(0x42b)](_0x1b1814[_0x242a53(0x3a3)](_0x1b1814[_0x242a53(0x167)](0x100, this['r']), _0x4a445e), 0x64));
                continue;
            case '4':
                _0x3cfd1e = _0x1b1814[_0x242a53(0x213)](_0x3cfd1e, 0xff) ? 0xff : _0x3cfd1e;
                continue;
            case '5':
                var _0x3ade5b = _0x1b1814[_0x242a53(0x251)](this['g'], _0x1b1814[_0x242a53(0x3a3)](0x100 - this['g'], _0x4a445e) / 0x64);
                continue;
            case '6':
                _0x3cfd1e = _0x1b1814[_0x242a53(0x3e3)](_0x3cfd1e, 0x0) ? 0x0 : _0x3cfd1e;
                continue;
            case '7':
                return new NFColor(Math[_0x242a53(0x502)](_0x3cfd1e), Math[_0x242a53(0x502)](_0x3ade5b), Math[_0x242a53(0x502)](_0xebf6a3), this['a']);
            case '8':
                _0xebf6a3 = _0x1b1814[_0x242a53(0x3e3)](_0xebf6a3, 0x0) ? 0x0 : _0xebf6a3;
                continue;
            case '9':
                _0xebf6a3 = _0x1b1814[_0x242a53(0x213)](_0xebf6a3, 0xff) ? 0xff : _0xebf6a3;
                continue;
            }
            break;
        }
    }, this['invert'] = function () {
        var _0x1d09c3 = _0x11a2bb;
        return new NFColor(_0x1b1814[_0x1d09c3(0x167)](0xff, this['r']), _0x1b1814[_0x1d09c3(0x167)](0xff, this['g']), 0xff - this['b'], this['a']);
    }, this['clamp'] = function (_0x4bb411) {
        var _0x2c3056 = _0x11a2bb;
        return Math[_0x2c3056(0x502)](Math[_0x2c3056(0x338)](0x0, Math[_0x2c3056(0x20d)](0xff, _0x4bb411)));
    }, this[_0x11a2bb(0x1fb)] = function () {
        var _0xdd15cd = _0x11a2bb, _0x1402c8 = _0x1b1814[_0xdd15cd(0x2ae)][_0xdd15cd(0x5e1)]('|'), _0x569db8 = 0x0;
        while (!![]) {
            switch (_0x1402c8[_0x569db8++]) {
            case '0':
                var _0x213cb5 = _0x1b1814[_0xdd15cd(0x603)](parseInt, _0x5892ca[_0xdd15cd(0x21d)](0x2, 0x2), 0x10);
                continue;
            case '1':
                var _0x506c86 = 0.14;
                continue;
            case '2':
                _0x1f4a98[0x1] = _0x1b1814['IWhee'](_0x1b1814[_0xdd15cd(0x669)](_0x211d35, _0x1b1814[_0xdd15cd(0x301)](_0x211d35, _0x158f0f)), _0x1b1814['Dkbii'](_0x211d35, _0x27cd9c));
                continue;
            case '3':
                var _0x158f0f = Math['cos'](_0x1b1814['ardvU'](_0x198ba1 * Math['PI'], 0xb4));
                continue;
            case '4':
                _0x1f4a98[0x3] = _0x1b1814[_0xdd15cd(0x26a)](_0x1b1814['fiqmZ'](_0x3443ba, _0x1b1814[_0xdd15cd(0x358)](_0x3443ba, _0x158f0f)), _0x1b1814[_0xdd15cd(0x358)](_0x4ee87c, _0x27cd9c));
                continue;
            case '5':
                _0x1f4a98[0x6] = _0x1b1814[_0xdd15cd(0x591)](_0x3443ba, _0x1b1814['sFIWY'](_0x3443ba, _0x158f0f)) - _0x1b1814[_0xdd15cd(0x516)](_0x1b1814[_0xdd15cd(0x591)](0x1, _0x3443ba), _0x27cd9c);
                continue;
            case '6':
                var _0x5892ca = this['hexString']()['replace']('#', '');
                continue;
            case '7':
                _0x1f4a98[0x2] = _0x1b1814[_0xdd15cd(0x591)](_0x3b02ac, _0x3b02ac * _0x158f0f) + _0x1b1814[_0xdd15cd(0x516)](_0x1b1814[_0xdd15cd(0x66a)](0x1, _0x3b02ac), _0x27cd9c);
                continue;
            case '8':
                _0x1f4a98[0x5] = _0x1b1814[_0xdd15cd(0x641)](_0x3b02ac, _0x1b1814['sFIWY'](_0x3b02ac, _0x158f0f)) - _0x1b1814[_0xdd15cd(0x516)](_0x504a51, _0x27cd9c);
                continue;
            case '9':
                var _0x198ba1 = _0x1b1814[_0xdd15cd(0x205)](_0x1b1814[_0xdd15cd(0x57e)](parseInt(_0x198ba1), 0x168), 0x168) % 0x168;
                continue;
            case '10':
                var _0x36cd61 = _0x1b1814[_0xdd15cd(0x603)](parseInt, _0x5892ca[_0xdd15cd(0x21d)](0x0, 0x2), 0x10);
                continue;
            case '11':
                var _0x4ee87c = 0.143;
                continue;
            case '12':
                var _0x543961 = this[_0xdd15cd(0x514)](_0x1b1814[_0xdd15cd(0x519)](_0x1b1814['sFIWY'](_0x1f4a98[0x3], _0x36cd61) + _0x1b1814[_0xdd15cd(0x3aa)](_0x1f4a98[0x4], _0x213cb5), _0x1b1814[_0xdd15cd(0x3aa)](_0x1f4a98[0x5], _0x9dc60c)));
                continue;
            case '13':
                return new NFColor(Math[_0xdd15cd(0x502)](_0x203004), Math['round'](_0x543961), Math[_0xdd15cd(0x502)](_0x13abf4), 0x1);
            case '14':
                var _0x504a51 = 0.283;
                continue;
            case '15':
                var _0x203004 = this[_0xdd15cd(0x514)](_0x1b1814[_0xdd15cd(0x519)](_0x1b1814['cECWc'](_0x1b1814[_0xdd15cd(0x3aa)](_0x1f4a98[0x0], _0x36cd61), _0x1b1814[_0xdd15cd(0x144)](_0x1f4a98[0x1], _0x213cb5)), _0x1f4a98[0x2] * _0x9dc60c));
                continue;
            case '16':
                _0x1f4a98[0x8] = _0x1b1814[_0xdd15cd(0x519)](_0x3b02ac, (0x1 - _0x3b02ac) * _0x158f0f) + _0x1b1814['qVHTA'](_0x3b02ac, _0x27cd9c);
                continue;
            case '17':
                var _0x27cd9c = Math[_0xdd15cd(0x1ac)](_0x1b1814[_0xdd15cd(0x2d2)](_0x1b1814[_0xdd15cd(0x144)](_0x198ba1, Math['PI']), 0xb4));
                continue;
            case '18':
                var _0x13abf4 = this[_0xdd15cd(0x514)](_0x1b1814[_0xdd15cd(0x25c)](_0x1b1814[_0xdd15cd(0x356)](_0x1b1814[_0xdd15cd(0x144)](_0x1f4a98[0x6], _0x36cd61), _0x1b1814['qVHTA'](_0x1f4a98[0x7], _0x213cb5)), _0x1b1814[_0xdd15cd(0x36d)](_0x1f4a98[0x8], _0x9dc60c)));
                continue;
            case '19':
                _0x1f4a98[0x7] = _0x1b1814['wyoti'](_0x1b1814[_0xdd15cd(0x34e)](_0x211d35, _0x211d35 * _0x158f0f), _0x211d35 * _0x27cd9c);
                continue;
            case '20':
                var _0x198ba1 = 0xb4;
                continue;
            case '21':
                _0x1f4a98[0x4] = _0x1b1814[_0xdd15cd(0x3d6)](_0x211d35 + _0x1b1814['Priek'](_0x1b1814[_0xdd15cd(0x34e)](0x1, _0x211d35), _0x158f0f), _0x1b1814[_0xdd15cd(0x36d)](_0x506c86, _0x27cd9c));
                continue;
            case '22':
                var _0x211d35 = 0.7152;
                continue;
            case '23':
                var _0x3443ba = 0.2126;
                continue;
            case '24':
                var _0x1f4a98 = [
                    0x1,
                    0x0,
                    0x0,
                    0x0,
                    0x1,
                    0x0,
                    0x0,
                    0x0,
                    0x1
                ];
                continue;
            case '25':
                var _0x9dc60c = parseInt(_0x5892ca[_0xdd15cd(0x21d)](0x4, 0x2), 0x10);
                continue;
            case '26':
                var _0x3b02ac = 0.0722;
                continue;
            case '27':
                _0x1f4a98[0x0] = _0x1b1814[_0xdd15cd(0x34e)](_0x3443ba + _0x1b1814[_0xdd15cd(0x34e)](0x1, _0x3443ba) * _0x158f0f, _0x3443ba * _0x27cd9c);
                continue;
            }
            break;
        }
    };
}
const NFColorFromRGBString = _0xe7dff2 => {
        var _0x42f8e3 = _0x4a728d, _0x52b334 = {
                'ywccx': _0x42f8e3(0x672),
                'Nqahf': function (_0x2af33, _0x47972d) {
                    return _0x2af33(_0x47972d);
                },
                'tLuPE': function (_0x37ae3a, _0x89bf35) {
                    return _0x37ae3a === _0x89bf35;
                },
                'BjTRA': function (_0x19c3e3, _0x343c33) {
                    return _0x19c3e3(_0x343c33);
                }
            }, _0x40cf03 = _0x52b334[_0x42f8e3(0x1ef)]['split']('|'), _0x11de4a = 0x0;
        while (!![]) {
            switch (_0x40cf03[_0x11de4a++]) {
            case '0':
                var _0x18f86d = _0x52b334[_0x42f8e3(0x5b3)](parseInt, _0x4caa5b[0x2]);
                continue;
            case '1':
                return new NFColor(_0x618e71, _0x20c479, _0x18f86d, _0xd62517);
            case '2':
                if (!_0xe7dff2)
                    return null;
                continue;
            case '3':
                var _0x4caa5b = _0xe7dff2[_0x42f8e3(0x609)](/rgba?\(/, '')[_0x42f8e3(0x609)](/\)/, '')[_0x42f8e3(0x5e1)](',');
                continue;
            case '4':
                var _0xd62517 = _0x52b334[_0x42f8e3(0x311)](_0x4caa5b[0x3], undefined) ? 0x1 : _0x52b334[_0x42f8e3(0x5b3)](parseFloat, _0x4caa5b[0x3]);
                continue;
            case '5':
                var _0x20c479 = _0x52b334[_0x42f8e3(0x278)](parseInt, _0x4caa5b[0x1]);
                continue;
            case '6':
                var _0x618e71 = _0x52b334[_0x42f8e3(0x278)](parseInt, _0x4caa5b[0x0]);
                continue;
            }
            break;
        }
    }, NFColorFromHexString = _0x363213 => {
        var _0x562c4c = _0x4a728d, _0x28331a = {
                'AgRzP': _0x562c4c(0x24b),
                'mcSVl': function (_0x578fce, _0x4d82ac) {
                    return _0x578fce(_0x4d82ac);
                },
                'EuwcO': function (_0x1bee06, _0x4859ac) {
                    return _0x1bee06(_0x4859ac);
                },
                'WUXkv': function (_0x8f70e4, _0x273fe1) {
                    return _0x8f70e4 === _0x273fe1;
                },
                'KXfII': function (_0x59a530, _0xfb807f) {
                    return _0x59a530(_0xfb807f);
                }
            }, _0x3f492c = _0x28331a['AgRzP'][_0x562c4c(0x5e1)]('|'), _0x2ab11d = 0x0;
        while (!![]) {
            switch (_0x3f492c[_0x2ab11d++]) {
            case '0':
                if (!_0x363213)
                    return null;
                continue;
            case '1':
                var _0x5980d4 = _0x28331a['mcSVl'](parseInt, _0x375bcb[0x2]);
                continue;
            case '2':
                var _0x45f764 = _0x28331a[_0x562c4c(0x653)](parseInt, _0x375bcb[0x1]);
                continue;
            case '3':
                var _0x2261c2 = _0x28331a[_0x562c4c(0x4d1)](_0x375bcb[0x3], undefined) ? 0x1 : _0x28331a[_0x562c4c(0x29b)](parseFloat, _0x375bcb[0x3]);
                continue;
            case '4':
                var _0x375bcb = NFHexToRgb(_0x363213);
                continue;
            case '5':
                var _0x2ae90e = _0x28331a[_0x562c4c(0x29b)](parseInt, _0x375bcb[0x0]);
                continue;
            case '6':
                return new NFColor(_0x2ae90e, _0x45f764, _0x5980d4, _0x2261c2);
            }
            break;
        }
    }, convertToHex6Digits = _0x577b7e => {
        var _0x337b75 = _0x4a728d, _0x334ef9 = {
                'Jdtpm': function (_0x392de9, _0x1c3a62) {
                    return _0x392de9 + _0x1c3a62;
                },
                'aOLGg': function (_0x56b9d6, _0x51fa4c) {
                    return _0x56b9d6 != _0x51fa4c;
                },
                'QCqXq': function (_0x18fded, _0x4a57d4) {
                    return _0x18fded > _0x4a57d4;
                },
                'rpYkr': function (_0x4841d7, _0x334b3f) {
                    return _0x4841d7 != _0x334b3f;
                }
            };
        if (_0x334ef9[_0x337b75(0x443)](_0x577b7e[_0x337b75(0x6a1)]('#'), 0x0))
            return _0x577b7e;
        if (_0x334ef9[_0x337b75(0x295)](_0x577b7e['length'], 0x4))
            return _0x577b7e;
        return _0x577b7e = _0x577b7e[_0x337b75(0x5e1)]('')['map'](_0x315bff => {
            var _0x236e4c = _0x337b75;
            if (_0x315bff == '#')
                return _0x315bff;
            return _0x334ef9[_0x236e4c(0x466)](_0x315bff, _0x315bff);
        })['join'](''), _0x334ef9[_0x337b75(0x439)](_0x577b7e[0x0], '#') && (_0x577b7e = _0x334ef9['Jdtpm']('#', _0x577b7e)), _0x577b7e;
    }, NFHexToRgb = _0x5637f0 => {
        var _0x5de77 = _0x4a728d;
        return _0x5637f0['replace'](/^#?([a-f\d])([a-f\d])([a-f\d])$/i, (_0x4c8152, _0x59645a, _0x1e8f20, _0x3def74) => '#' + _0x59645a + _0x59645a + _0x1e8f20 + _0x1e8f20 + _0x3def74 + _0x3def74)[_0x5de77(0x28c)](0x1)[_0x5de77(0x58b)](/.{2}/g)[_0x5de77(0x331)](_0x4d0633 => parseInt(_0x4d0633, 0x10));
    }, rgbToHex = _0x2fe7f8 => {
        var _0x14a0e5 = _0x4a728d, _0x5502ca = {
                'zvGvt': function (_0x221f5d, _0x63e039) {
                    return _0x221f5d === _0x63e039;
                },
                'ZfXNk': function (_0x2752a7, _0xb2054e) {
                    return _0x2752a7 + _0xb2054e;
                },
                'CbLzY': function (_0x3b4c56, _0x5bf0ee) {
                    return _0x3b4c56(_0x5bf0ee);
                }
            }, _0x40db5b = _0x2fe7f8['replace'](/rgba?\(/, '')[_0x14a0e5(0x609)](/\)/, '')[_0x14a0e5(0x5e1)](','), _0x1465af = _0x5502ca[_0x14a0e5(0x5fc)](parseInt, _0x40db5b[0x0]), _0x4dcde0 = _0x5502ca[_0x14a0e5(0x5fc)](parseInt, _0x40db5b[0x1]), _0x197db8 = _0x5502ca[_0x14a0e5(0x5fc)](parseInt, _0x40db5b[0x2]);
        return '#' + [
            _0x1465af,
            _0x4dcde0,
            _0x197db8
        ]['map'](_0x55f54f => {
            var _0x383f8e = _0x14a0e5;
            const _0x9f0779 = _0x55f54f[_0x383f8e(0x35e)](0x10);
            return _0x5502ca[_0x383f8e(0x3ea)](_0x9f0779[_0x383f8e(0x1d9)], 0x1) ? _0x5502ca[_0x383f8e(0x67b)]('0', _0x9f0779) : _0x9f0779;
        })[_0x14a0e5(0x3e2)]('');
    }, namedColorToHex = _0x5c4838 => {
        var _0x24f2d1 = _0x4a728d, _0x409c0c = { 'fqXDg': 'canvas' }, _0x2de76d = document['createElement'](_0x409c0c[_0x24f2d1(0x3e0)])[_0x24f2d1(0x227)]('2d');
        return _0x2de76d[_0x24f2d1(0x25e)] = _0x5c4838, _0x2de76d[_0x24f2d1(0x25e)][_0x24f2d1(0x2bd)]();
    }, BlackColor = () => {
        return new NFColor(0x0, 0x0, 0x0, 0x1);
    }, GrayColor = () => {
        return new NFColor(0xf5, 0xf5, 0xf5, 0x1);
    }, TransparentColor = () => {
        return new NFColor(0x0, 0x0, 0x0, 0x0);
    }, isBlack = _0x20cd65 => {
        var _0x3daf77 = _0x4a728d, _0x377eea = {
                'kovzF': function (_0x2780db, _0x35a02d) {
                    return _0x2780db == _0x35a02d;
                },
                'cEYzf': function (_0x35d12b, _0x2d5f92) {
                    return _0x35d12b == _0x2d5f92;
                },
                'HnpHK': function (_0x5738c3, _0x1808ee) {
                    return _0x5738c3 == _0x1808ee;
                },
                'COrRg': function (_0x483d1b, _0x14bd14) {
                    return _0x483d1b < _0x14bd14;
                }
            };
        if (_0x20cd65['a'] !== 0x1)
            return ![];
        return _0x377eea['kovzF'](_0x20cd65['r'], 0x0) && _0x377eea[_0x3daf77(0x411)](_0x20cd65['g'], 0x0) && _0x377eea[_0x3daf77(0x1b0)](_0x20cd65['b'], 0x0) || _0x20cd65['r'] < 0x19 && _0x377eea[_0x3daf77(0x352)](_0x20cd65['g'], 0x19) && _0x377eea[_0x3daf77(0x352)](_0x20cd65['b'], 0x19);
    }, getIgnoredSelectors = _0x510dbe => {
        var _0x5156e0 = _0x4a728d, _0xaa05e5 = {
                'rxYQI': _0x5156e0(0x2f9),
                'bGtQj': '.listing-top.with-feature\x20a.overlay',
                'kAoVU': '.listing-top.with-feature\x20figure\x20.listing-large',
                'DOGID': _0x5156e0(0x513),
                'Dadpw': _0x5156e0(0x2d6),
                'lJDRE': _0x5156e0(0x64d),
                'wSapI': 'img[data-lazy-src]',
                'bxCEa': _0x5156e0(0x3cf),
                'EKaDb': _0x5156e0(0x3b4),
                'uFroC': _0x5156e0(0x1cd),
                'kuMuu': _0x5156e0(0x419),
                'qUqyg': _0x5156e0(0x24c),
                'iFwHL': _0x5156e0(0x48e),
                'CtAXd': _0x5156e0(0x3f5),
                'QZOOz': _0x5156e0(0x64a),
                'aqPsX': _0x5156e0(0x4b5),
                'WgTro': _0x5156e0(0x20c),
                'VahWo': _0x5156e0(0x3ec),
                'aPeEz': '.et_mobile_menu',
                'pdAyB': 'ul#top-menu',
                'ZLHYA': _0x5156e0(0x46d),
                'ZtYnr': _0x5156e0(0x473),
                'culQf': '.ac-gn-menuicon',
                'rQaUa': _0x5156e0(0x2f4),
                'AsyYS': _0x5156e0(0x297),
                'Fjcvv': _0x5156e0(0x2a7),
                'wNMlj': _0x5156e0(0x5ff),
                'PUUqg': _0x5156e0(0x292),
                'CYutW': _0x5156e0(0x4db),
                'zZhms': _0x5156e0(0x587),
                'XTGZx': 'svg.highcharts-root',
                'etLds': _0x5156e0(0x246),
                'eMZBG': 'svg.bdl-IconCaretRound',
                'UTKeW': _0x5156e0(0x692),
                'mfBeg': _0x5156e0(0x5b0),
                'HtiaZ': _0x5156e0(0x3a9),
                'qARZr': _0x5156e0(0x654),
                'zecWr': _0x5156e0(0x156),
                'vTXRM': _0x5156e0(0x3db),
                'sprgH': _0x5156e0(0x306),
                'HhXqU': _0x5156e0(0x2df),
                'QSDbv': _0x5156e0(0x38f),
                'hMQGj': _0x5156e0(0x3c6),
                'qaahf': _0x5156e0(0x1a6),
                'cLHbV': _0x5156e0(0x5e9),
                'fouNo': 'a[ping]\x20div[role=\x22heading\x22]',
                'gIIbH': _0x5156e0(0x407),
                'WSVwV': _0x5156e0(0x626),
                'LDJyq': 'a.fl',
                'awaCU': _0x5156e0(0x5d2),
                'gejpD': _0x5156e0(0x1fe),
                'TQDNK': 'a[href^=\x22/travel/explore\x22]\x20div[style^=\x22background-image\x22]',
                'LKTQh': _0x5156e0(0x41b),
                'nociN': _0x5156e0(0x405),
                'UxNtM': _0x5156e0(0x666),
                'uhjrR': _0x5156e0(0x402),
                'AsGsC': _0x5156e0(0x19e),
                'rBEVD': '.ndm-chart__image-wrapper\x20svg',
                'FexcL': _0x5156e0(0x1c0),
                'fBLNu': _0x5156e0(0x684),
                'YvNMC': _0x5156e0(0x1ce),
                'cQGkD': '.MJXc-display',
                'NCFVN': '.Vue-Toastification__container',
                'AkmAM': '.right-item-img\x20a',
                'OXaiT': _0x5156e0(0x49b),
                'VhIzC': _0x5156e0(0x3ab),
                'qZFXP': '.images-viewer-content2__button',
                'DksTa': _0x5156e0(0x4c9),
                'yXFJG': _0x5156e0(0x41d),
                'JceWz': _0x5156e0(0x554),
                'QquQv': '.ninetofive-icon',
                'UyPFE': _0x5156e0(0x455),
                'YfwZP': _0x5156e0(0x3e5),
                'SKKbi': _0x5156e0(0x379),
                'WRSOs': _0x5156e0(0x1de),
                'yYrWW': _0x5156e0(0x34b),
                'ZCCPU': _0x5156e0(0x305),
                'PvMvT': '.mw-ui-icon',
                'ZbDWI': _0x5156e0(0x267),
                'Avugj': _0x5156e0(0x44b),
                'FrDro': _0x5156e0(0x413),
                'IuASa': _0x5156e0(0x4ee),
                'YpVEE': 'a.hx',
                'RbqFe': _0x5156e0(0x69f),
                'ZxtXR': _0x5156e0(0x1c3),
                'RmeRI': _0x5156e0(0x136),
                'lIHfv': _0x5156e0(0x5ce),
                'bSFPO': _0x5156e0(0x58f),
                'KCmRR': _0x5156e0(0x5f8),
                'hSvhQ': _0x5156e0(0x567),
                'ZjQRU': _0x5156e0(0x3fd),
                'puYef': _0x5156e0(0x5fe),
                'dpctN': 'svg',
                'GHSMk': _0x5156e0(0x37f),
                'gcVWp': _0x5156e0(0x195),
                'JaOvT': _0x5156e0(0x63b),
                'MjyOw': _0x5156e0(0x5d6),
                'gzwaL': _0x5156e0(0x3ef),
                'rZlgK': _0x5156e0(0x403),
                'BWpUQ': _0x5156e0(0x159),
                'VJSUN': _0x5156e0(0x61a),
                'CtssW': _0x5156e0(0x5ca),
                'pivvJ': _0x5156e0(0x29e),
                'vycSw': '.slide__image',
                'tZWVs': _0x5156e0(0x42e),
                'WPVTA': _0x5156e0(0x2ba),
                'QGdrZ': _0x5156e0(0x174),
                'VkGMj': _0x5156e0(0x149),
                'lIJye': _0x5156e0(0x37d),
                'GXpsE': '.icon',
                'QKQGW': '#mobile-menu',
                'weEpQ': '.fastforward-left',
                'lKiUM': '.product_img_area__cmeBU',
                'YvsNe': _0x5156e0(0x2dc),
                'bMGxW': '.timer',
                'IpxCI': _0x5156e0(0x500),
                'cFsdJ': _0x5156e0(0x194),
                'qxfSU': '.all-over-thumb-link',
                'mFNQT': _0x5156e0(0x5c1),
                'UzJYF': _0x5156e0(0x63f),
                'KksSk': '.listitem',
                'ZyZpP': _0x5156e0(0x5e3),
                'kuhUj': _0x5156e0(0x546),
                'sOmyg': _0x5156e0(0x3a5),
                'Kyeho': _0x5156e0(0x2d8),
                'DMWyx': _0x5156e0(0x4a2),
                'dqGjJ': _0x5156e0(0x271),
                'CEnik': _0x5156e0(0x241),
                'nkjpi': _0x5156e0(0x265),
                'mguyP': '.content-page__navigation__group',
                'TeUQW': _0x5156e0(0x2de),
                'YCscz': _0x5156e0(0x697),
                'Yhixs': _0x5156e0(0x314),
                'UwrPw': _0x5156e0(0x53a),
                'cjZZZ': _0x5156e0(0x65a),
                'smbiE': 'p[color=\x22labelPlaceholder\x22]',
                'VfMTj': '.pt-btn',
                'kMNhk': _0x5156e0(0x47a),
                'ngpeF': _0x5156e0(0x5d8),
                'UusAA': _0x5156e0(0x339),
                'dfWRA': '.icon-questionmark',
                'iQZsL': '.search-form\x20.submit-button',
                'vxdzT': _0x5156e0(0x37a),
                'LKliS': _0x5156e0(0x404),
                'EbuVi': _0x5156e0(0x617),
                'Atjfb': _0x5156e0(0x397),
                'GQkwG': _0x5156e0(0x63c),
                'dBmfz': _0x5156e0(0x1a8),
                'nfohw': _0x5156e0(0x535),
                'eemsX': _0x5156e0(0x67e),
                'fOnfI': _0x5156e0(0x564),
                'taAjL': _0x5156e0(0x1ab),
                'CVseC': _0x5156e0(0x678),
                'rRLhS': _0x5156e0(0x139),
                'SYAev': _0x5156e0(0x1db),
                'MFtDB': _0x5156e0(0x475),
                'vMKYz': _0x5156e0(0x438),
                'kbmWW': '.vis-stacked-nav',
                'LyrAi': _0x5156e0(0x586),
                'veRMu': _0x5156e0(0x60f),
                'VchGy': _0x5156e0(0x649),
                'NdVPh': '.table-yes',
                'RdubZ': '.table-no',
                'PsUkz': _0x5156e0(0x326),
                'CeqMa': _0x5156e0(0x53b),
                'CxISl': _0x5156e0(0x592),
                'ziqkh': _0x5156e0(0x51d),
                'MRZJt': _0x5156e0(0x418),
                'UPOGa': _0x5156e0(0x461),
                'qPbUl': _0x5156e0(0x212),
                'sFYOv': '.appearance_selector-modulethumbnail2lNyP',
                'uIkzv': _0x5156e0(0x150),
                'puMbH': _0x5156e0(0x4ac),
                'yaSKK': _0x5156e0(0x21e),
                'nKPNt': _0x5156e0(0x661),
                'BAYcD': _0x5156e0(0x238),
                'uyrGp': _0x5156e0(0x585),
                'DdBXR': _0x5156e0(0x484),
                'TJNzG': _0x5156e0(0x3c3),
                'LUTLE': _0x5156e0(0x1a3),
                'RtBBu': _0x5156e0(0x59b),
                'gptgV': '.icon-esrb',
                'fRCRa': _0x5156e0(0x368),
                'GxxSt': 'div[class^=\x22NewUserAccount__AccountMenu-\x22]',
                'KCozX': _0x5156e0(0x62c),
                'qJdtv': _0x5156e0(0x3a7),
                'ETuKE': _0x5156e0(0x2ff),
                'dCoRl': _0x5156e0(0x255),
                'gVlxL': _0x5156e0(0x4cf),
                'UbEjP': _0x5156e0(0x16a),
                'uBoZp': _0x5156e0(0x43f),
                'mwiUQ': _0x5156e0(0x359),
                'SYyNw': _0x5156e0(0x52c),
                'bYKNy': '.sidebar-search\x20>\x20input[type=\x22search\x22]',
                'CEKDa': _0x5156e0(0x674),
                'oBLnS': 'div[class^=\x22avatar-\x22]\x20svg',
                'UoXas': _0x5156e0(0x340),
                'kEvZu': _0x5156e0(0x597),
                'bXdkS': _0x5156e0(0x3d7),
                'pljyq': 'div.nav',
                'PeDEH': _0x5156e0(0x30a),
                'UimwN': _0x5156e0(0x3ce),
                'dJsKj': '.dsc\x20.u_hc',
                'rwZBV': _0x5156e0(0x176),
                'fHXTA': _0x5156e0(0x633),
                'liFoK': '#mw-mf-page-left\x20li\x20>\x20a',
                'mgqoD': '.gnb-btn',
                'vuXQG': _0x5156e0(0x559),
                'MVisC': _0x5156e0(0x3a8),
                'izCDW': _0x5156e0(0x269),
                'AJaxo': '.buy__mask',
                'uhUtY': _0x5156e0(0x689),
                'WyUQR': _0x5156e0(0x517),
                'DwMpA': _0x5156e0(0x432),
                'fCfAe': _0x5156e0(0x242),
                'iVnEi': '#drawer-close',
                'WpAeR': _0x5156e0(0x1f7),
                'rWnSQ': '#id-MainNavigation',
                'LYkQw': _0x5156e0(0x325),
                'fstEZ': _0x5156e0(0x428),
                'aVJxG': '.tds-modal-backdrop',
                'GtDAR': '.filter-PAINT',
                'ViUww': _0x5156e0(0x3d2),
                'KaeOR': _0x5156e0(0x2a8),
                'NZJTH': _0x5156e0(0x192),
                'QRzRL': function (_0x217510, _0x49ba32) {
                    return _0x217510(_0x49ba32);
                },
                'cIycM': 'google.',
                'EGZox': _0x5156e0(0x382),
                'vxwdx': _0x5156e0(0x385),
                'huHgu': function (_0x374f14, _0x5041e7) {
                    return _0x374f14 + _0x5041e7;
                }
            };
        if (!_0x510dbe)
            return [];
        var _0x268c42 = {
            'default': [
                _0xaa05e5[_0x5156e0(0x1ee)],
                _0xaa05e5[_0x5156e0(0x15a)],
                _0xaa05e5['kAoVU'],
                _0xaa05e5['DOGID'],
                _0xaa05e5[_0x5156e0(0x17f)],
                _0xaa05e5[_0x5156e0(0x349)],
                _0x5156e0(0x276),
                _0xaa05e5[_0x5156e0(0x38e)],
                _0xaa05e5[_0x5156e0(0x5a5)],
                _0xaa05e5['EKaDb'],
                _0xaa05e5[_0x5156e0(0x1f5)],
                _0x5156e0(0x322),
                _0xaa05e5[_0x5156e0(0x1cc)],
                _0x5156e0(0x239),
                _0xaa05e5[_0x5156e0(0x3f7)],
                _0xaa05e5[_0x5156e0(0x37e)],
                _0xaa05e5[_0x5156e0(0x68e)],
                _0x5156e0(0x18a),
                _0xaa05e5['QZOOz']
            ],
            'm.gsmarena.com': [_0xaa05e5['aqPsX']],
            'appstoreconnect.apple.com': [
                _0xaa05e5[_0x5156e0(0x44d)],
                _0x5156e0(0x392)
            ],
            'lux.camera': [_0xaa05e5['VahWo']],
            'shortcutsgallery.com': [
                _0xaa05e5[_0x5156e0(0x387)],
                _0xaa05e5[_0x5156e0(0x277)],
                _0xaa05e5['ZLHYA']
            ],
            'www.airbnb.com': [_0x5156e0(0x1e8)],
            'apple.com': [
                _0xaa05e5[_0x5156e0(0x328)],
                _0xaa05e5[_0x5156e0(0x38c)],
                _0xaa05e5[_0x5156e0(0x216)]
            ],
            'my.jdownloader.org': [_0xaa05e5[_0x5156e0(0x17d)]],
            'cydia.saurik.com': [
                _0x5156e0(0x35c),
                _0x5156e0(0x2ef),
                _0xaa05e5[_0x5156e0(0x595)]
            ],
            'shop.shpresa.al': [
                _0xaa05e5[_0x5156e0(0x3c2)],
                _0x5156e0(0x42c)
            ],
            'www.messenger.com': [
                _0xaa05e5[_0x5156e0(0x273)],
                _0xaa05e5[_0x5156e0(0x230)],
                _0xaa05e5[_0x5156e0(0x5df)]
            ],
            'app.box.com': [
                _0xaa05e5[_0x5156e0(0x4b2)],
                '.file-list-icon\x20svg.item-icon',
                _0xaa05e5[_0x5156e0(0x4f8)],
                _0xaa05e5[_0x5156e0(0x2ed)],
                _0xaa05e5[_0x5156e0(0x548)],
                _0xaa05e5['mfBeg'],
                _0xaa05e5[_0x5156e0(0x357)]
            ],
            'www.linkedin.com': [
                _0x5156e0(0x31b),
                _0xaa05e5[_0x5156e0(0x3b6)],
                _0x5156e0(0x55f)
            ],
            'drive.google.com': [
                _0xaa05e5[_0x5156e0(0x1e6)],
                _0xaa05e5[_0x5156e0(0x384)],
                _0xaa05e5[_0x5156e0(0x3f9)]
            ],
            'iosgods.com': [_0xaa05e5['HhXqU']],
            'm.youtube.com': [_0xaa05e5['QSDbv']],
            'bitbucket.org': [_0xaa05e5[_0x5156e0(0x471)]],
            'www.rottentomatoes.com': [
                '.tpSubtitles',
                _0x5156e0(0x665),
                _0x5156e0(0x2b4)
            ],
            'ebay.com': [
                _0xaa05e5['qaahf'],
                _0xaa05e5[_0x5156e0(0x673)]
            ],
            'google.com': [
                _0xaa05e5[_0x5156e0(0x57d)],
                _0xaa05e5[_0x5156e0(0x3f4)],
                _0xaa05e5[_0x5156e0(0x4b0)],
                _0xaa05e5['LDJyq'],
                _0xaa05e5[_0x5156e0(0x30f)],
                _0x5156e0(0x420),
                '.yuRUbf\x20>\x20a',
                _0xaa05e5[_0x5156e0(0x225)],
                _0xaa05e5[_0x5156e0(0x183)],
                _0xaa05e5['LKTQh']
            ],
            'docs.google.com': [
                _0xaa05e5[_0x5156e0(0x650)],
                _0xaa05e5[_0x5156e0(0x3f9)],
                _0xaa05e5[_0x5156e0(0x611)],
                _0xaa05e5[_0x5156e0(0x600)]
            ],
            'play.google.com': [_0x5156e0(0x193)],
            'www.redmondpie.com': [_0x5156e0(0x5cc)],
            'www.androidauthority.com': [_0x5156e0(0x237)],
            'mashtips.com': [
                _0xaa05e5[_0x5156e0(0x510)],
                _0xaa05e5[_0x5156e0(0x4d4)]
            ],
            'olcayaksoy.keenetic.pro': [
                _0xaa05e5[_0x5156e0(0x452)],
                _0xaa05e5['FexcL']
            ],
            'lamar.edu': [
                _0xaa05e5[_0x5156e0(0x31c)],
                _0xaa05e5['YvNMC'],
                _0xaa05e5[_0x5156e0(0x2fc)]
            ],
            'habr.com': [_0xaa05e5[_0x5156e0(0x291)]],
            'giaxe.2banh.vn': [
                _0x5156e0(0x3d1),
                _0x5156e0(0x160),
                _0xaa05e5[_0x5156e0(0x2ac)],
                _0xaa05e5[_0x5156e0(0x5a5)]
            ],
            'yandex.com': [
                'div[class^=\x22informers__icon\x22',
                _0xaa05e5[_0x5156e0(0x2f7)],
                _0xaa05e5[_0x5156e0(0x2f3)],
                _0xaa05e5[_0x5156e0(0x13d)],
                _0xaa05e5[_0x5156e0(0x309)]
            ],
            'yandex.ru': [
                _0xaa05e5[_0x5156e0(0x683)],
                _0x5156e0(0x49b),
                _0xaa05e5['VhIzC'],
                _0xaa05e5['qZFXP'],
                _0xaa05e5[_0x5156e0(0x309)]
            ],
            'journals.biologists.com': [_0x5156e0(0x180)],
            '9to5mac.com': [
                _0xaa05e5[_0x5156e0(0x2cb)],
                _0xaa05e5[_0x5156e0(0x2c0)]
            ],
            'www.igeeksblog.com': [_0x5156e0(0x316)],
            'bwt.cbp.gov': [
                _0xaa05e5[_0x5156e0(0x5b6)],
                _0xaa05e5['YfwZP']
            ],
            'covid19.mohp.gov.np': [_0xaa05e5[_0x5156e0(0x313)]],
            'vimeo.com': [_0x5156e0(0x1b5)],
            'www.diffchecker.com': [_0xaa05e5[_0x5156e0(0x474)]],
            'wikipedia.org': [
                _0x5156e0(0x321),
                _0xaa05e5[_0x5156e0(0x49d)],
                _0xaa05e5[_0x5156e0(0x1e1)],
                _0x5156e0(0x2a3),
                _0x5156e0(0x299),
                _0xaa05e5[_0x5156e0(0x337)],
                _0xaa05e5[_0x5156e0(0x23e)],
                '.mwe-math-fallback-image-inline',
                _0xaa05e5['Avugj'],
                _0xaa05e5['FrDro'],
                _0x5156e0(0x53b)
            ],
            'fmkorea.com': [
                _0xaa05e5['IuASa'],
                _0xaa05e5[_0x5156e0(0x147)],
                _0x5156e0(0x660),
                _0xaa05e5[_0x5156e0(0x36f)]
            ],
            'www.cotopaxi.com': [
                _0xaa05e5[_0x5156e0(0x682)],
                _0xaa05e5[_0x5156e0(0x169)],
                _0x5156e0(0x334),
                _0xaa05e5['lIHfv'],
                _0xaa05e5[_0x5156e0(0x4a0)]
            ],
            'www.hdblog.it': [
                _0xaa05e5['KCmRR'],
                _0xaa05e5[_0x5156e0(0x141)],
                _0xaa05e5['ZjQRU'],
                _0xaa05e5['puYef']
            ],
            'www.hdmotori.it': [
                _0xaa05e5[_0x5156e0(0x1b6)],
                _0x5156e0(0x567),
                _0xaa05e5[_0x5156e0(0x2f6)],
                _0xaa05e5[_0x5156e0(0x57b)],
                '.toggleside'
            ],
            'fontawesome.com': [_0xaa05e5[_0x5156e0(0x22b)]],
            'www.ynet.co.il': [_0x5156e0(0x2f8)],
            'm.ynet.co.il': [_0xaa05e5['GHSMk']],
            'apexapr.mu': [
                _0x5156e0(0x53c),
                _0xaa05e5[_0x5156e0(0x3c9)]
            ],
            'www.liverpool.ac.uk': ['#continue-button'],
            'www.galaxy.mu': [_0xaa05e5[_0x5156e0(0x289)]],
            'zhihu.com': [
                _0xaa05e5['MjyOw'],
                _0xaa05e5[_0x5156e0(0x4e1)]
            ],
            'telegram.org': [_0xaa05e5['rZlgK']],
            'kakaku.com': [_0xaa05e5[_0x5156e0(0x279)]],
            'www.dateks.lv': [_0xaa05e5[_0x5156e0(0x2bf)]],
            'www.paypal.com': [_0xaa05e5[_0x5156e0(0x1e2)]],
            'www.samsungeshop.com.cn': [
                _0x5156e0(0x530),
                _0xaa05e5['pivvJ']
            ],
            'www.kiiroo.com': [_0xaa05e5[_0x5156e0(0x540)]],
            'm.i-m-all.com': [
                _0xaa05e5[_0x5156e0(0x5a2)],
                _0xaa05e5['WPVTA']
            ],
            'www.dynamed.com': [_0xaa05e5['QGdrZ']],
            'calendar.google.com': [
                _0xaa05e5[_0x5156e0(0x551)],
                _0xaa05e5[_0x5156e0(0x221)]
            ],
            'xnxx.com': [
                _0xaa05e5['GXpsE'],
                _0xaa05e5['QKQGW'],
                '.fastforward-right',
                _0xaa05e5[_0x5156e0(0x4a3)]
            ],
            'msearch.shopping.naver.com': [_0xaa05e5['lKiUM']],
            'www.macrumors.com': [
                _0xaa05e5[_0x5156e0(0x1e5)],
                _0xaa05e5[_0x5156e0(0x224)]
            ],
            'www.24h.com.vn': [
                _0xaa05e5[_0x5156e0(0x526)],
                _0xaa05e5[_0x5156e0(0x657)]
            ],
            'www.thedailybeast.com': [_0x5156e0(0x329)],
            'thuthuatjb.com': [
                _0xaa05e5['qxfSU'],
                _0xaa05e5[_0x5156e0(0x34d)]
            ],
            'granatovyjablko.cz': [_0xaa05e5[_0x5156e0(0x4ed)]],
            'investor.apple.com': [
                _0xaa05e5[_0x5156e0(0x3f2)],
                _0xaa05e5[_0x5156e0(0x608)],
                _0x5156e0(0x3e1),
                _0xaa05e5['kuhUj'],
                _0xaa05e5[_0x5156e0(0x2e8)],
                _0xaa05e5['Kyeho']
            ],
            'finam.ru': [
                _0xaa05e5[_0x5156e0(0x3ff)],
                _0x5156e0(0x5c8),
                _0x5156e0(0x1c7),
                _0xaa05e5[_0x5156e0(0x3ff)],
                '.finfin-header-logo-name'
            ],
            'wizzair.com': [
                _0xaa05e5['dqGjJ'],
                '.accordion-item__header',
                _0xaa05e5[_0x5156e0(0x134)],
                _0xaa05e5[_0x5156e0(0x264)],
                _0xaa05e5['mguyP'],
                _0xaa05e5['TeUQW'],
                _0x5156e0(0x284),
                _0xaa05e5['YCscz'],
                _0x5156e0(0x4ae),
                _0x5156e0(0x265),
                _0xaa05e5[_0x5156e0(0x37b)],
                _0xaa05e5[_0x5156e0(0x140)],
                _0xaa05e5[_0x5156e0(0x5c5)]
            ],
            'weather.com': [_0x5156e0(0x256)],
            'www.kvakil.me': [
                _0x5156e0(0x240),
                '#register-tab-view\x20.input'
            ],
            'appstoreconnect.apple.com': [_0xaa05e5[_0x5156e0(0x3b5)]],
            'conquest.mathusee.com': [_0xaa05e5[_0x5156e0(0x588)]],
            'developer.apple.com': [
                _0xaa05e5[_0x5156e0(0x52b)],
                _0xaa05e5['ngpeF'],
                _0x5156e0(0x542),
                _0xaa05e5[_0x5156e0(0x46e)],
                _0xaa05e5[_0x5156e0(0x562)],
                _0xaa05e5['iQZsL']
            ],
            'amazon.com': [
                '*[class^=\x22style__overlay__\x22]',
                _0x5156e0(0x34f)
            ],
            'www.ingrooves.com': [
                _0xaa05e5[_0x5156e0(0x47e)],
                _0xaa05e5[_0x5156e0(0x670)],
                _0xaa05e5[_0x5156e0(0x681)]
            ],
            'www.sony.de': [
                _0xaa05e5['Atjfb'],
                _0xaa05e5[_0x5156e0(0x435)],
                _0x5156e0(0x40b),
                '.pagination-bullets'
            ],
            'apnews.com': [
                _0xaa05e5[_0x5156e0(0x440)],
                _0xaa05e5[_0x5156e0(0x1f2)],
                _0xaa05e5[_0x5156e0(0x2cb)],
                _0xaa05e5['eemsX']
            ],
            'www.elcorteingles.es': [_0xaa05e5[_0x5156e0(0x3fb)]],
            'www.br.de': [_0xaa05e5[_0x5156e0(0x332)]],
            'www.twisto.cz': [
                _0xaa05e5[_0x5156e0(0x1f3)],
                _0x5156e0(0x61b),
                _0xaa05e5['rRLhS']
            ],
            '365.bank': [
                _0xaa05e5['SYAev'],
                _0xaa05e5[_0x5156e0(0x66b)],
                _0xaa05e5[_0x5156e0(0x16d)],
                _0x5156e0(0x61e)
            ],
            'www.toyota.com': [_0xaa05e5[_0x5156e0(0x520)]],
            'm.ilbe.com': [_0xaa05e5[_0x5156e0(0x550)]],
            'm.albamon.com': [
                _0x5156e0(0x580),
                _0xaa05e5[_0x5156e0(0x62b)]
            ],
            'www.mobily.com.sa': [
                _0xaa05e5['VchGy'],
                _0x5156e0(0x563)
            ],
            'en.m.wikipedia.org': [
                _0xaa05e5['NdVPh'],
                _0xaa05e5['RdubZ'],
                _0xaa05e5[_0x5156e0(0x3cc)],
                '.table-partial',
                _0xaa05e5[_0x5156e0(0x4d0)]
            ],
            'www.alsscan.com': [_0xaa05e5[_0x5156e0(0x1d7)]],
            'www.trendevice.com': [
                _0xaa05e5[_0x5156e0(0x69d)],
                _0xaa05e5['MRZJt'],
                _0xaa05e5['UPOGa']
            ],
            'www.thread.com': [
                _0xaa05e5['qPbUl'],
                _0xaa05e5['sFYOv'],
                '.form_select_button-moduleformSelectButton39w9m'
            ],
            'math.nakaken88.com': [
                _0xaa05e5[_0x5156e0(0x51f)],
                _0xaa05e5[_0x5156e0(0x31c)]
            ],
            'variety.com': [_0xaa05e5[_0x5156e0(0x19c)]],
            'pubmed.ncbi.nlm.nih.gov': [
                _0x5156e0(0x19b),
                _0xaa05e5[_0x5156e0(0x5bc)],
                _0xaa05e5[_0x5156e0(0x5be)],
                _0xaa05e5[_0x5156e0(0x207)],
                _0xaa05e5[_0x5156e0(0x685)],
                _0xaa05e5[_0x5156e0(0x253)]
            ],
            'www.city.hiroshima.lg.jp': [_0xaa05e5[_0x5156e0(0x4e6)]],
            'minecraft.net': [
                _0xaa05e5[_0x5156e0(0x61f)],
                _0xaa05e5[_0x5156e0(0x3e7)],
                _0xaa05e5[_0x5156e0(0x27c)],
                _0xaa05e5['fRCRa']
            ],
            'powerlanguage.co.uk': [_0x5156e0(0x181)],
            'neverinstall.com': [
                _0xaa05e5[_0x5156e0(0x145)],
                '.intercom-lightweight-app-launcher-icon'
            ],
            'cegepgranby.omnivox.ca': ['.container-roles'],
            'www.avocadostore.de': [
                _0xaa05e5['KCozX'],
                _0xaa05e5['qJdtv']
            ],
            'www.media.hiroshima-u.ac.jp': [_0xaa05e5[_0x5156e0(0x483)]],
            'www.mimeophotos.com': [_0xaa05e5['dCoRl']],
            'www.geeksforgeeks.org': [_0xaa05e5[_0x5156e0(0x29f)]],
            'www.bnext.com.tw': [_0xaa05e5[_0x5156e0(0x1b1)]],
            'www.cnrtl.fr': [_0xaa05e5['uBoZp']],
            'www.frandroid.com': [_0xaa05e5[_0x5156e0(0x5ef)]],
            'issuein.org': ['a.hx'],
            'greasyfork.org': [
                _0xaa05e5[_0x5156e0(0x231)],
                _0xaa05e5[_0x5156e0(0x427)]
            ],
            'www.desmos.com': [_0xaa05e5['CEKDa']],
            'discord.com': [
                _0xaa05e5[_0x5156e0(0x16c)],
                _0xaa05e5[_0x5156e0(0x3d8)]
            ],
            'www.therakyatpost.com': [_0xaa05e5[_0x5156e0(0x343)]],
            'm.bboom.naver.com': [
                _0xaa05e5[_0x5156e0(0x560)],
                _0xaa05e5['pljyq'],
                _0xaa05e5[_0x5156e0(0x293)],
                _0xaa05e5[_0x5156e0(0x1cb)],
                _0xaa05e5[_0x5156e0(0x607)]
            ],
            'm.map.naver.com': [
                _0xaa05e5['rwZBV'],
                _0xaa05e5[_0x5156e0(0x450)]
            ],
            'm.uncyclopedia.kr': [
                _0x5156e0(0x34b),
                _0xaa05e5[_0x5156e0(0x5c0)]
            ],
            'news.kbs.co.kr': [_0xaa05e5['mgqoD']],
            'thesweetsetup.com': [_0xaa05e5['vuXQG']],
            'm.cafe.naver.com': [_0xaa05e5[_0x5156e0(0x2b6)]],
            'winxp.vercel.app': [_0xaa05e5['izCDW']],
            'developer.salesforce.com': [_0xaa05e5['izCDW']],
            'www.quadlockcase.com': [_0xaa05e5[_0x5156e0(0x55e)]],
            'www.startech.com': ['.product-image-gallery\x20.mt-2'],
            'www.pixelmator.com': [_0xaa05e5[_0x5156e0(0x196)]],
            'www.maildesigner365.com': [_0x5156e0(0x579)],
            'www.mql5.com': [_0xaa05e5['WyUQR']],
            'www.thinkybits.com': [
                _0xaa05e5[_0x5156e0(0x31f)],
                _0xaa05e5[_0x5156e0(0x14f)]
            ],
            'www.letsgojp.com': [_0xaa05e5['iVnEi']],
            'map.kakao.com': [_0xaa05e5['WpAeR']],
            'www.merkur.de': [_0xaa05e5[_0x5156e0(0x366)]],
            'www.24hamburg.de': [
                _0x5156e0(0x3c5),
                _0xaa05e5[_0x5156e0(0x22a)]
            ],
            'beta.character.ai': [_0xaa05e5[_0x5156e0(0x353)]],
            'newsensations.com': ['div[class^=\x22videothumb_\x22]'],
            'tesla.com': [
                _0xaa05e5[_0x5156e0(0x56f)],
                _0xaa05e5[_0x5156e0(0x538)],
                _0xaa05e5['ViUww']
            ],
            'hyperx.com': [
                _0x5156e0(0x3ad),
                _0xaa05e5['KaeOR']
            ]
        };
        const _0x12becb = _0x268c42[_0xaa05e5[_0x5156e0(0x60e)]];
        let _0x1f1737 = _0x12becb[_0x5156e0(0x2bc)](_0x268c42[_0x510dbe] ? _0x268c42[_0x510dbe] : []), _0xc98ef1 = _0xaa05e5[_0x5156e0(0x1b7)](getMainDomain, _0x510dbe);
        _0x1f1737 = _0x1f1737['concat'](_0x268c42[_0xc98ef1] ? _0x268c42[_0xc98ef1] : []);
        let _0x2302e4 = [
            _0xaa05e5[_0x5156e0(0x67c)],
            _0xaa05e5[_0x5156e0(0x5d1)],
            _0xaa05e5['vxwdx']
        ];
        for (domain of _0x2302e4) {
            if (_0xc98ef1[_0x5156e0(0x363)](domain)) {
                let _0x27fe2a = _0x510dbe[_0x5156e0(0x28c)](0x0, _0x510dbe[_0x5156e0(0x6a1)](_0xc98ef1));
                _0xc98ef1 = domain + 'com';
                if (_0x268c42[_0xc98ef1])
                    _0x1f1737 = _0x1f1737['concat'](_0x268c42[_0xc98ef1]);
                let _0x47cbe5 = _0xaa05e5[_0x5156e0(0x547)](_0x27fe2a, _0xc98ef1);
                if (_0x268c42[_0x47cbe5])
                    _0x1f1737 = _0x1f1737[_0x5156e0(0x2bc)](_0x268c42[_0x47cbe5]);
            }
        }
        return [...new Set(_0x1f1737)];
    }, getCustomCss = _0x54ecec => {
        var _0x3e9541 = _0x4a728d, _0x548d91 = {
                'EQUCT': _0x3e9541(0x3cb),
                'COrOp': _0x3e9541(0x382),
                'xOfcW': _0x3e9541(0x385),
                'XFNXJ': function (_0x5501c4, _0x51d097) {
                    return _0x5501c4 + _0x51d097;
                },
                'sVLHj': 'default'
            };
        let _0x3b2da1 = {
                'google.com': _0x3e9541(0x19f),
                'mudfish.net': _0x3e9541(0x138),
                'hyperx.com': _0x3e9541(0x4f7),
                'meduza.io': _0x3e9541(0x188),
                'm.bboom.naver.com': _0x3e9541(0x3f8),
                'dev.quranwbw.com': _0x3e9541(0x26c),
                'www.kakaopay.com': _0x3e9541(0x2ab),
                'm.map.kakao.com': _0x3e9541(0x14b),
                'map.kakao.com': _0x3e9541(0x4ec),
                'dekang.en.made-in-china.com': _0x3e9541(0x268),
                'www.boxofficemojo.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mojo-group-label\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.mql5.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product-card__title-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product-card:hover\x20.product-card__wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product-card:hover\x20.product-card__description:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'indominusbyte.github.io': _0x3e9541(0x522),
                'tesla.com': _0x3e9541(0x270),
                'www.tilannehuone.fi': _0x3e9541(0x39a),
                'mnews.sbs.co.kr': _0x3e9541(0x30b),
                'd.comenity.net': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#brand-logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'thesweetsetup.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.category-wrap,\x20.recently,\x20.sponsor,\x20.related,\x20.tips-tricks,\x20.author,\x20.sponsor-full,\x20.newsletter-sidebar,\x20.widget,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#side-bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'app.giftistar.net': _0x3e9541(0x55d),
                'www.desmos.com': _0x3e9541(0x56e),
                'www.manualslib.com': _0x3e9541(0x3c1),
                'news.kbs.co.kr': _0x3e9541(0x686),
                'deepl.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.TextInput-module--textarea--oUXvH:disabled\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.4)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dl_header:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.merkur.de': _0x3e9541(0x4c2),
                'lakinkonieczny.wordpress.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#content,\x20#wrapper,\x20#nav-post,\x20#container,\x20#sidebar,\x20#footer-bott,\x20#footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.24hamburg.de': _0x3e9541(0x226),
                'www.precisionnutrition.com': _0x3e9541(0x4df),
                'www.thinkybits.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20text[fill=\x22#222222\x22],\x20text[fill=\x22#000000\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.barrons.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sticky-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.hDkVhy,\x20.hdtNVh,\x20.jsxbNi\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'm.genk.vn': _0x3e9541(0x5a6),
                'attiora.com': _0x3e9541(0x556),
                'tronscan.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tron-light\x20.tron-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'web.moneylover.me': _0x3e9541(0x308),
                'www.cowellsgc.co.uk': _0x3e9541(0x350),
                'instapundit.com': _0x3e9541(0x1f0),
                'www.ikea.com': _0x3e9541(0x25f),
                'tekno.10terbaik.com': _0x3e9541(0x5eb),
                'issuein.org': _0x3e9541(0x3f3),
                'www.cnrtl.fr': _0x3e9541(0x21b),
                'greasyfork.org': _0x3e9541(0x200),
                'www.thomann.de': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20mix-blend-mode:\x20normal\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'brmgroups.com': _0x3e9541(0x537),
                'rnfirebase.io': _0x3e9541(0x17a),
                'forgetfulbc.blogspot.com': _0x3e9541(0x39b),
                'techno.yandex.com': _0x3e9541(0x372),
                'fleshtest.com': _0x3e9541(0x33d),
                'www.bnext.com.tw': _0x3e9541(0x312),
                'mimeophotos.com': _0x3e9541(0x2bb),
                'www.geeksforgeeks.org': _0x3e9541(0x4f3),
                'huggingface.co': _0x3e9541(0x1bd),
                'www.theverge.com': _0x3e9541(0x481),
                'neverinstall.com': _0x3e9541(0x323),
                'help.disneyplus.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[ng-repeat=\x22container\x20in\x20containers\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'minecraft.net': _0x3e9541(0x2a6),
                'is.fi': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bg-ticker-10,\x20.vignette-breaking-news\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#c8b400\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vignette-breaking-news\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#c8b400\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#cd2129\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.section-header\x20.r-fade:after,\x20.section-header\x20.x-fade:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'variety.com': _0x3e9541(0x383),
                'investor.costco.com': _0x3e9541(0x2a5),
                'stevejobsarchive.com': _0x3e9541(0x1fd),
                'math.nakaken88.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header,\x20#footer-menu,\x20.drawer__title\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.searchform__submit,\x20#toc_container\x20.toc_title:before,\x20.ez-toc-title-container:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cat-name,\x20.pre_tag\x20>\x20span,\x20.pagination\x20.current,\x20.post-page-numbers.current,\x20#submit,\x20.withtag_list\x20>\x20span,\x20.main-bc-before\x20li:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'm.todaysppc.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-btn-up-c\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-listview,\x20.ui-body-c,\x20.ui-overlay-c,\x20.ui-mobile\x20.ui-page-active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20linear-gradient(\x20theme_color,\x20theme_color\x20)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.itworld.co.kr': _0x3e9541(0x19a),
                'm.hotge.co.kr': _0x3e9541(0x58e),
                'www.dailywire.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-spot-im-shadow-host*=\x22conversation\x20conversation-survey\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(92%)\x20hue-rotate(180deg)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.thread.com': _0x3e9541(0x476),
                'www.trendevice.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrapper_attributo\x20.elenco_scelte\x20input:not(:checked)\x20+\x20label\x20.wrapper_valore,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.valori_wrapper\x20input:not(:checked)\x20+\x20.valore_attributo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.skyjos.cn': _0x3e9541(0x2fb),
                'www.samsungcard.com': _0x3e9541(0x492),
                'm.hub.zum.com': _0x3e9541(0x582),
                'www.3gpp.org': _0x3e9541(0x396),
                'www.quadlockcase.com': _0x3e9541(0x3b8),
                'm.zum.com': _0x3e9541(0x4ca),
                'm.cafe.naver.com': _0x3e9541(0x39e),
                'm.blog.naver.com': _0x3e9541(0x536),
                'm.auction.co.kr': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mheader_wrap\x20.btn_cart:after,\x20.mheader_wrap\x20.btn_my:after,\x20.mheader_wrap\x20.btn_menu:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.box__homemain-app-install-banner\x20.button__close\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                '4pda.to': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.post_header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#0051bb\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pagecurrent\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#a26135\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.anonce_body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#937b0f\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.post-block.spoil.open\x20>\x20.block-body:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outline:\x20solid\x205px\x20#theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'ilbe.com': _0x3e9541(0x1ba),
                'twisto.cz': _0x3e9541(0x5af),
                'www1.nyc.gov': _0x3e9541(0x179),
                'seapunks.de': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
                'www.toyota.com': _0x3e9541(0x624),
                'm.albamon.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.aside-btn,\x20.mypage-btn{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.1)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'apnews.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ot-sdk-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'support.apple.com': _0x3e9541(0x2f2),
                'portalmns.mu': _0x3e9541(0x60c),
                'answers.opencv.org': _0x3e9541(0x15b),
                'docs.opencv.org': _0x3e9541(0x53f),
                'm.youtube.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.engagement-panel-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.kvakil.me': _0x3e9541(0x3a2),
                'www.python.org': _0x3e9541(0x26f),
                'www.oxfordlearnersdictionaries.com': _0x3e9541(0x44f),
                'weather.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20[dir]\x20.gradients--sunnyDay--17X6W,\x20.appWrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20[dir]\x20.ExpandableMenu--ExpandableMenu--2HGl7.ExpandableMenu--open--2oMlM>.ExpandableMenu--inner--39JQs,\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[class^=\x22ExpandableMenu--inner\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg[data-testid=\x22DonutChart\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'education.github.com': _0x3e9541(0x33e),
                'wizzair.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content-page__title,\x20.rf-search-tools__title,\x20.banner__title\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20p,\x20li,\x20strong,\x20span,a,\x20h3,\x20.accordion-item__header\x20button,\x20ul,\x20font,\x20h1,button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content-page__navigation__group.accordion-item--opened\x20.content-page__navigation__group__header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#817fdf\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content-page__search\x20input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cookie-policy,\x20.sticky-newsletter-bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.faq-page-header__title__main\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20nav.mobile-navigation,\x20.navigation-dropdown,\x20.language-switcher,\x20.content-page__container\x20.accordion-item__body,\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-test=\x22flight-search-locations\x22],\x20.flight-search__panel__header,\x20.flight-search__panel,\x20.rf-input--location,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sidebar,\x20.box,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.accordion-item__body__container\x20.content__note,\x20.body--campaign-page\x20.campaign__white-box\x20.content__note,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.career__content--continuous\x20.content__note,\x20.career__content\x20.content__note,\x20.content-page__content\x20.content__note\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.language-switcher__item--active,\x20.language-switcher__item:active,\x20.language-switcher__item:focus,\x20.language-switcher__item:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#712153\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'finam.ru': _0x3e9541(0x2f0),
                'pytorch.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cookie-banner-wrapper.is-visible,\x20.mobile-main-menu-links-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'investor.apple.com': _0x3e9541(0x1ff),
                'thuthuatjb.com': _0x3e9541(0x285),
                'www.thedailybeast.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20._3TL8d,\x20.NavMain,\x20.ButtonBurger\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ButtonBurger__line\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.SidePanel__dot\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'swapcash.mu': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#menu-menu,\x20.nice-select\x20.list,\x20.nice-select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20.main-nav,\x20.main-nav.dark_style\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'calendar.google.com': _0x3e9541(0x65e),
                'tenforums.com': _0x3e9541(0x1eb),
                'bimmerforums.com': _0x3e9541(0x2c1),
                'udemy.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[alt=\x22Udemy\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.4)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'xnxx.com': _0x3e9541(0x208),
                'rapidgator.net': _0x3e9541(0x54d),
                'map.naver.com': _0x3e9541(0x449),
                'm.map.naver.com': _0x3e9541(0x20f),
                'naver.com': _0x3e9541(0x417),
                'www.dynamed.com': _0x3e9541(0x165),
                'clipdiary.com': _0x3e9541(0x49c),
                'nitroflare.com': _0x3e9541(0x31a),
                'm.i-m-all.com': _0x3e9541(0x164),
                'apexapr.mu': _0x3e9541(0x5f0),
                'kakaku.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20label[style^=\x22color:\x20rgb(51,\x2051,\x2051)\x22],\x20#searchBySpecBox\x20.specBoxTTL\x20#specTTL\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#specBox\x20.specList,\x20.h1bg,\x20#menu\x20.keysearch_v2,\x20#menuNojs\x20.keysearch_v2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#searchBySpecBox\x20.specBoxTTL\x20,\x20#itemList\x20.switch\x20li.detailOn,\x20#main\x20.h3Area,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#rankCate\x20.rcBoxTop,\x20#rankCate\x20.rcBoxBtm,\x20#historyBox,\x20#corporation\x20.corpTrendsearch\x20p\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#revSort,\x20.digestBox.newVer\x20.digestCtn,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#corporation\x20.corpFeature\x20p\x20a,\x20#corporation\x20.corpPr\x20p\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#corporation\x20.corpShop\x20p\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#menu\x20.menuArea,\x20#main\x20.boxSearchBtm,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.contType001\x20.contTtlIn,\x20.pullDownTtl,\x20.p-main_linkList_item,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20ul.sort\x20li\x20a,\x20ul.sort\x20li\x20span,\x20.p-plan_price_btn,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.p-main_linkList,\x20.p-tab_item.is-active,\x20.submitBtnGray\x20span,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.breadcrumbs\x20ul,\x20.submitBtn4,\x20footer\x20.logoutBtn\x20a,\x20ul.linkBtns.with2Btn\x20li,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20ul.linkBtns\x20li,\x20.favSetTtl1,\x20.favChkLabelToggle,\x20.favStatusLabel,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.favMailLabel,\x20.favFolderBtn,\x20.moreElBtn\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.pricePrAreaSmallSize\x20.prBox,\x20ul.tabs\x20li.active,\x20.pricemail\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.homebtnbnr,\x20#specToggle\x20.hType3Toggle\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#itemList\x20.switch\x20li.normalOff,\x20#itemList\x20.switch\x20li.simpleOff,\x20#itmArea\x20#itmBoxMax\x20.itmBoxBottom,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#itmArea\x20#itmBoxMax\x20.itmBoxIn,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.p-PTPay,\x20#listingPr\x20div,\x20#module\x20.rankingBox180,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mainRight\x20#module\x20.module-enq,\x20#pkuplist\x20#mainRight\x20.module-enq,\x20#pkuplist-top\x20.module-enq,\x20#bbs\x20.module-enq,\x20#review\x20.module-enq,\x20.review\x20.module-enq,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#module\x20.moduleBox01,\x20#module\x20.chosataiBox,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#interior\x20#menu\x20.menuAreaMain\x20h2,\x20.contType001,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.p-plan_search_select_in,\x20.p-plan_search_multiple,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tabbtnList\x20li,\x20.variationList\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.creditCard\x20.viewBtn,\x20#main\x20.h3Area:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pageNavigation\x20li\x20a,\x20.pageNavigation\x20li\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.p-PTFee_select_btn,\x20.p-PTPay_option_btn{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.historyContents\x20.historyItem\x20.historyInner,\x20#linkList,\x20.historyContents\x20.tabMenu,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.historyContents\x20.tabMenu\x20li,\x20.p-tab\x20ul\x20li\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.topicReplyNumLink\x20span.btn\x20.submitBtnGray\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tabbtnList\x20li.active,\x20ul.tabs\x20li.active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#463f08\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.hdrWrpFixed,\x20.kakakuHdrWrp{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.makerComment\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#bea20a\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'm.ynet.co.il': _0x3e9541(0x1d0),
                'www.ynet.co.il': _0x3e9541(0x53e),
                'www.hdblog.it': _0x3e9541(0x498),
                'www.hdmotori.it': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.4)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment-gray\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.newlist_normal\x20.title_newlist_normal\x20.comment-gray\x20i.fa.fa-comment\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAABYklEQVQokd2SMUvDUBDH/4nP60FpDR0eqFnEzdXNbyC4+Qn8Lo4Ogs5OfgDd3DqIjopQLE4ORiJFQ0yipO+ZRK5NhwqFipsHB493d7/7v3vnpGl6FATBnjGmifmtIqKe7/unTr/fDzqdzjIRuVLuuu5clDzPP6IoCpUxZpWZf9F8bMzcNMasz9dutjl/BeAfABQRFXmeu8zs/AyWZTmz0BhTEFEsi3QQBMGGMWbL87wlz/OmEuM4Fq8AFPXVO4BXIop83792qqqSJVgBcBiG4U5RFE673Z4UW2Z+1FpfAXgAEAG4BPAM4EtEKgBDAE8AbhuNxnaWZUqkJ0lSMvO91nofQBdAKisMwE7NQJZBSABeiGhorVVJkmTM3NNanwC4APBZ54kv1PkCGwHkIN5VSt1Ya9darda51voMwF0dW6yVyq9NQCObzMDUsN3BYLCptT4G8FYXSkzeKy4AUTBWAQy/Ac4mjxRGs3sdAAAAAElFTkSuQmCC\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.cotopaxi.com': _0x3e9541(0x41e),
                'routinehub.co': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ethad-container,\x20.dropdown-content\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[alt=\x22RoutineHub\x20logo\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.legifrance.gouv.fr': _0x3e9541(0x68b),
                'pubmed.ncbi.nlm.nih.gov': _0x3e9541(0x16b),
                'www.ncbi.nlm.nih.gov': _0x3e9541(0x504),
                'covid19.mohp.gov.np': _0x3e9541(0x66d),
                'yandex.com': _0x3e9541(0x2cd),
                'translate.yandex.com': _0x3e9541(0x679),
                'iphone-mania.jp': _0x3e9541(0x202),
                'www.engadget.com': _0x3e9541(0x5a4),
                'unsplash.com': _0x3e9541(0x5b1),
                'www.nfe.fazenda.gov.br': _0x3e9541(0x51a),
                'vnexpress.net': _0x3e9541(0x2cc),
                'lamar.edu': _0x3e9541(0x367),
                'www.24h.com.vn': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.gryTbL,\x20.gryTbR{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.mg-leftanhright,\x20.bx4Tbg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.bxDoMrNwsTwo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#566a32\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'docs.google.com': _0x3e9541(0x345),
                'iosninja.io': _0x3e9541(0x655),
                'ekstrabladet.dk': _0x3e9541(0x401),
                'tinhte.vn': _0x3e9541(0x5cf),
                'm.gsmarena.com': _0x3e9541(0x552),
                'books.google.com': _0x3e9541(0x490),
                'passwords.google.com': _0x3e9541(0x32c),
                'apps.apple.com': _0x3e9541(0x5ad),
                'apple.com': _0x3e9541(0x589),
                'producthunt.com': _0x3e9541(0x575),
                'github.com': _0x3e9541(0x362),
                'box.com': _0x3e9541(0x45a),
                'translate.google.com': '\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.RvYhPd::before,\x20.P6w8m.BDJ8fb:not(.Jj6Lae),\x20.QcsUad.BDJ8fb:not(.Jj6Lae)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.VIiyi,\x20div[data-language-code]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.X4DQ0::after,\x20.AzKM4,\x20.DLAnyc,\x20.NBY4Kb{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.ita-kd-icon-button\x20.ita-icon-1\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[soy-server-key]\x20ul[role=\x22listbox\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20c-wiz[jsshadow]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-auto-open-search]\x20div[jsaction*=\x22keydown:\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-auto-open-search]\x20input{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-language-code]:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.jfk-button-standard\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#clp-btn\x20.jfk-button-img,\x20a[title=\x22Google\x20apps\x22],\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ita-kd-img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.jfk-button-standard.jfk-button-checked,\x20.jfk-button-standard.jfk-button-clear-outline.jfk-button-checked,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.KjuTac\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'cjasn.asnjournals.org': _0x3e9541(0x619),
                'www.hollywoodreporter.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20p.larva,\x20p.amp-wp-excerpt\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.a-overlay--r-t0@mobile-max:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.openstreetmap.org': _0x3e9541(0x28e),
                'm-grafolio.naver.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.group_lnb\x20li:last-child\x20a:after,\x20.tabScroll:before,\x20.tabScroll:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tit_category,\x20.tit_artwork\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'opensource.apple.com': _0x3e9541(0x637),
                'mediaspace.mu': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20.stuck,\x20header\x20.container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.owl-item>.product\x20.add-to-cart-wrap\x20.button::before,\x20.owl-item>.product\x20.added_to_cart::before,\x20li.product\x20.add-to-cart-wrap\x20.button::before,\x20li.product\x20.added_to_cart::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'kiiroo.com': _0x3e9541(0x2b1),
                'www.samsungeshop.com.cn': _0x3e9541(0x5f2),
                'www4.septa.org': _0x3e9541(0x4b1),
                'nj.us': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[alt=\x22top\x22],\x20img[alt=\x22footer\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.buttons,.buttons2,\x20\x20.navigation\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[rel^=\x22dropmenu\x22]\x20>\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'discuss.eroscripts.com': _0x3e9541(0x5f7),
                'cegepgranby.omnivox.ca': _0x3e9541(0x57a),
                'bugs.chromium.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20mr-description\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'mra.mu': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-c,\x20.ui-overlay-c,\x20.ui-btn-up-c\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'analytics.google.com': _0x3e9541(0x1d2),
                'www.whiteelephantrestaurant.com': _0x3e9541(0x219),
                'www.airbnb.com': _0x3e9541(0x495),
                'news.google.com': _0x3e9541(0x36b),
                'zingnews.vn': _0x3e9541(0x574),
                'shortcutsgallery.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.et_mobile_menu{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.menu-item\x20>\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'idmsa.apple.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cnsmr-app-image[src^=\x22https://appstoreconnect\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.icloud.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.main-pane,\x20.cw-pane-container{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.banner-view\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#8a7500\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cw-spinner-view,\x20.notes-spinner-view\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.notes-note-editor-view-controller\x20canvas\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.9)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fmip-background-grid\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'cnn.com': _0x3e9541(0x28f),
                'appstoreconnect.apple.com': _0x3e9541(0x2b3),
                'instagram.com': _0x3e9541(0x2a1),
                'messenger.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sp_OVYTba5GJUO_2x,\x20i[data-visualcompletion=\x22css-img\x22],\x20div[aria-label=\x22Settings,\x20help\x20and\x20more\x22]\x20svg{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-visualcompletion]\x20svg[height=\x2224\x22],\x20a[aria-label=\x22New\x20Message\x22]\x20svg,\x20a[aria-label=\x22New\x20message\x22]\x20svg,\x20div[aria-label=\x22Create\x20New\x20Room\x22]\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22menuitem\x22]\x20svg[height=\x2224\x22],\x20a[role=\x22menuitem\x22]\x20svg[height=\x2224\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[role=\x22presentation\x22]\x20svg[height=\x2224\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.qbubdy2e\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'mbcradio.tv': _0x3e9541(0x4fc),
                'my.jdownloader.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#loginContainer\x20#main,\x20#gwtContent,\x20.contextMenu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.contextMenu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.rowSelected\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20wheat\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'psyche.co': _0x3e9541(0x590),
                'getpocket.com': _0x3e9541(0x642),
                'console.firebase.google.com': _0x3e9541(0x47b),
                'travis-ci.com': _0x3e9541(0x48a),
                'drive.google.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.KL4NAf\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.aabwZd\x20.WYuW0e,\x20.aabwZd\x20.N7iPof,\x20.a-t-cb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-bottom-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.s55KNe:not(.KBj6Qd)\x20.GZwC2b\x20.jGNTYb,\x20.aabwZd:not(.KBj6Qd)\x20.GZwC2b,\x20.a-t-J-ha\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.L202Xe{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.RwLyCe{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-top-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20c-wiz\x20span[aria-label=\x22Owned\x20by\x20me\x22],\x20c-wiz\x20span[aria-label^=\x22Last\x20modified\x22],\x20c-wiz\x20span[aria-label^=\x22Size:\x22]\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22menu\x22]::after{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[title=\x22Options\x22]\x20span[nitefall_imagetype=\x22png\x22],\x20div[aria-label=\x22Remove\x22]\x20svg{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[aria-label=\x22Shared\x22]\x20svg{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Connect\x20more\x20apps\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'nytimes.com': _0x3e9541(0x1a0),
                'cnbc.com': _0x3e9541(0x1ca),
                'www.iclarified.com': _0x3e9541(0x448),
                'heroku.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#overview-page\x20.app-overview-metrics\x20timeseries-chart::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'chariz.com': _0x3e9541(0x446),
                'disqus.com': _0x3e9541(0x647),
                'www.iphonedev.wiki': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mw-page-base,\x20div.vectorTabs\x20span,\x20div.vectorTabs\x20ul\x20li,\x20#simpleSearch,\x20div.vectorTabs\x20ul\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.iphonedevwiki.net': _0x3e9541(0x232),
                'theiphonewiki.com': _0x3e9541(0x232),
                'iphoneincanada.ca': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.onesignal-bell-svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'trello.com': _0x3e9541(0x5c6),
                'repo.packix.com': _0x3e9541(0x375),
                'developer.packix.com': _0x3e9541(0x50d),
                'codeproject.com': _0x3e9541(0x4ad),
                'webkit.org': _0x3e9541(0x2e1),
                'medium.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a\x20svg[width=\x2225\x22],\x20a\x20svg[width=\x2229\x22],\x20svg[aria-label=\x22responses\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'defimedia.info': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#block-taxonomymainmenu,\x20.page-node-type-news\x20article.news.full\x20footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'behance.net': _0x3e9541(0x5d4),
                'linkedin.com': _0x3e9541(0x3a0),
                'v2ex.com': _0x3e9541(0x4fd),
                'play.google.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a[href*=\x22/intl/en/about/products?\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a[aria-label=\x22Settings\x22]\x20div[nitefall_imageType=\x22png\x22],\x20button[title=\x22Help\x22]\x20span[nitefall_imageType=\x22png\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20img.gb_tc\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.25)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'pinterest.com': '\x20.VaseCarousel__buttonRight\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
                'finance.yahoo.com': _0x3e9541(0x4c7),
                'yahoo.com': '\x20.caas-readmore-collapse:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fp-ph-block:after,\x20.fp-ph-block:before,\x20.fp-pholder:after,\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.caas-card-loader:before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'm.yahoo.co.jp': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Header__icon--notification,\x20.Header__icon--menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'uncyclopedia.kr': _0x3e9541(0x2ca),
                'lifehacker.com': _0x3e9541(0x4a5),
                'imore.com': _0x3e9541(0x2c7),
                'formula1.com': _0x3e9541(0x4fb),
                'booking.com': _0x3e9541(0x5ba),
                'www.reddit.com': _0x3e9541(0x63d),
                'appleid.apple.com': _0x3e9541(0x64b),
                'forbes.com': _0x3e9541(0x621),
                'mail.google.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22toolbar\x22]\x20>\x20div[command]\x20div[nitefall_imageType=\x22png\x22],\x20td[role=\x22gridcell\x22]\x20div[nitefall_imageType=\x22png\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20span[data-hovercard-id]\x20div[nitefall_imageType=\x22png\x22],\x20td\x20div[command]\x20div[nitefall_imageType=\x22png\x22],\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22More\x20options\x22]\x20div[nitefall_imageType=\x22png\x22],\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label^=\x22Discard\x20draft\x22]\x20div[nitefall_imageType=\x22png\x22],\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20span\x20>\x20img[src=\x22images/cleardot.gif\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20span[role=\x22link\x22]::before,\x20div[aria-label=\x22Not\x20starred\x22]\x20span::before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22menuitemcheckbox\x22]\x20div[nitefall_imageType=\x22png\x22],\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20span[aria-label=\x22Pop\x20out\x20reply\x22],\x20div[aria-label=\x22Type\x20of\x20response\x22]::after{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20td\x20div[style*=\x22clip:\x20rect\x22]::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Download\x20all\x20attachments\x22]\x20div[nitefall_imageType=\x22png\x22],\x20div[aria-label=\x22Add\x20all\x20to\x20Drive\x22]\x20div[nitefall_imageType=\x22png\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Remove\x20attachment\x22],\x20div[aria-label=\x22Show\x20trimmed\x20content\x22]\x20img,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Type\x20of\x20response\x22]\x20img,\x20button[data-overlay-action=\x22spelldismiss\x22]\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Show\x20details\x22]\x20img\x20,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Reply\x22]\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Formatting\x20options\x22]\x20div[nitefall_imagetype=\x22png\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#mutbt,\x20#tltbt,\x20#cv__cntbt\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#pr_\x20,\x20#preftopbar{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.Fb,\x20.ph\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[data-control-type=\x22prmenu+179\x22],\x20div[data-control-type=\x22prusemod+182\x22],\x20div[data-control-type=\x22prusevacmod+188\x22],\x20div[data-control-type=\x22tlasprev+82\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[data-control-type=\x22prmenu+179\x22]\x20>\x20div,\x20div[data-control-type=\x22tlasprev+82\x22]\x20>\x20div\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[data-control-type=\x22toggleaccountscallout+20\x22],\x20div[data-control-type=\x22cmclose+107\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.nl.fl,\x20#mutbb{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAABYCAIAAAC79grhAAAAOklEQVR4AWOAAQ8PXyYgxczPL8z0//9/EBsN/weKk8sHmwfkw9lQPslsgmZjssE0PnEYnxS/EOLDMACvzUZ13+DWTQAAAABJRU5ErkJggg==)\x20repeat-x\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[data-control-type=\x22bti+2\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-image:\x20url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGIAAAA8CAYAAACdIW+JAAAFHklEQVR42u2c72tbVRjHm+b3zzaNbdOk6dL8aGuwTcVEWyldsBRbWgRlkDnfrMYpEzH4CybSRa1WRYS1cz/KHJOCKKsb4htxoAiWDqG4d3s16X8x2N7E57k+J9x1jSS5uScv7nPhC82999ybfj+55znnueectnK53IbSaTsC+g10F1Q2sHZBG6DZqk7pBOJ50A2Dm19Nf4DyMkCcEjcNhUK7S0tLp/f29ubgHocNqtzKysrJxcXFNfDjlgrIJ3qCOC1ulMlkNuG6T4IeBQ2CBgyqQ6Ak6DHQU9PT0xcOhNFEEJUnYWpqao0AhEABkA/kNajwf/eDukFh9AWejg9VMPLNBHFMXBiIfwnXi4MeoS/iYVXkpR9mNJvNnlHFjKaAeEJAGB0dvUzVUBdD+F/hExINBAK75N0zWkE4Qd/gxYaHh6/CdWIMoWYF0un0RwTivFYQZ/FCQ0NDP8E1humxYwg1VlPQonwa/TOZTHe0gHhPVEmlUgmbpz0MoT5tb2+HyMN7jYKYFBByudwpKB+k1gEbXJ86Kq2nBkFsYuGRkZFvqUmGENysuuXRAuIzLBiJRG5QcO5kQxtXoyDyomA+n3+J+goeNlQuiA5Vf2Gd4oKXzZQPQukJJhKJLTg/QhBcLG2qF0RRFFhdXT1MPUM2UjKIcXHyxMREiZJXbjZRPogN6j1vUjaVq6QWgFByIcFg8E9K5mF/wclqnmoB8Zw4aX5+/gQl81xsnlwQNtAveEIqlboAx3spLrB5kkEoTdVYLHZN1VRl4ySDOCkOFovFWUxMgRwsfVQNREIcGB8f/5RSGE42TD6I87gzHo9/D/v6KC6wYZJBKENh8D3qzs7OCMUFO0tfPQCChgKKURhFSmE42Cj5IK5T7/kSvfJ0skmSQcBWwD+i0ejPcKCf4gKbJBuE1WrNqN4zTNMJNpYcqasms9frvYgfAMoVNqeFIPC9c3d391WCcZYNag0IE1ZHMzMzlZaTzWb7APZZWfprfz8CYbiSyeS74oDT6TzCRskHgWrHTlx/f/+aODgwMBBjsySDoJHhGC/8wWBQGUBmNpsvwmcLSz9Vzb4ipfX19XhnZ6cyB85isXzBhrUGBMYLRzabrQwmg5bUm2yaZBAEA+OFG3rbJXGi2+2eZeMkg1DFC19fX98GjeH/MZVKddF+VpNU0ygOotbV29v7HX5sb2//ms1rDQiMF7ZCofC4KAAwPmYDJYNQwXCOjY0VVMH7BJsoGYQqeHugg/e5KOhyubK0n6VBdY8GJ4Id0Nm7QlXUZTayBSBEZw9njvb09GwRjDU2szUgHsrUAoz32VDJIFQwHsjUms3mF2g/qw4lEgm7pum9B2VqHQ7HITa3Ptnt9iTVKv80POF9f6YWB6exufUJALxOP+JLmpaAEJlaEbxxSQg2uHbB9jvNP5nXCkLJ1M7NzT2rGp9zhk2u6Wl4h96E3lSG1WhdJojihWtycvJFFYyv2OzqgsbNUeHV4ODgK0oWttyEhbNEzzudTr+mgoEDmrvaeNu/vS08girpHM3CMjVtKTnRksrlckcDgcCvdLO/QMdpBpKRN1xc7FX1yp+RSOQcjTE2N31xRWpJeZeXl7PhcPgHXlr0Yfl8vr8zmcxbtLaVVbflRsXbPZxfAU/HG36//ya0Du4b2XyPx3MbfphbCwsLL5f/W/nST+kik64L8BIMB1HHGydAQwZVkqZGh8kPV6U6krASsmjaWgiIWOHRiPKQ+Xbyw3SQX/8Cb42i2awperkAAAAASUVORK5CYII=)\x208\x208\x2010\x2024\x20fill\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20form[role=\x22search\x22]\x20>\x20div[nitefall_imagetype=\x22png\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'paypal.com': _0x3e9541(0x5ed),
                'internetaccount.myt.mu': _0x3e9541(0x4c5),
                'bountify.co': _0x3e9541(0x3ca),
                'androidauthority.com': _0x3e9541(0x18b),
                'dtf.ru': _0x3e9541(0x5da),
                '444.hu': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#ember4,\x20.legacy\x20.subhead::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.legacy\x20.ad-highlight\x20a,\x20.legacy\x20.highlight,\x20.kr21osz-str-1__wrapper:any-link,\x20#ember12\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#c7c700\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.hj\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--highlight-color:\x20#c7c700\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.legacy\x20.item\x20.highlight.highlight--black\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-left:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-right:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.ddlvalley.me': _0x3e9541(0x5dc),
                'bing.com': _0x3e9541(0x1ec),
                'macrumors.com': _0x3e9541(0x37c),
                'iosgods.com': _0x3e9541(0x20b),
                'imdb.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pagecontent\x20#content-2-wide{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.bbc.co.uk': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.isite-content\x20td.has-label:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'ebay.com': _0x3e9541(0x4ff),
                'base64decode.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20div.wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.header\x20div.sisters\x20a.active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ad_left\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20main\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20main[nitefall_imagetype=\x22svg\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'urldecoder.org': _0x3e9541(0x606),
                'base64encode.org': _0x3e9541(0x606),
                'wikipedia.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mw-wiki-logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.25)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vector-menu-tabs\x20li,\x20.vector-menu-tabs\x20a,\x20.vector-menu-tabs\x20li\x20a,\x20#mw-page-base\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.lang-list-button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outline:\x201.6rem\x20solid\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[src^=\x22/static/images/mobile/copyright/wikipedia-wordmark-en.svg\x22],\x20.mw-ui-icon-mf-expand:before,\x20.indicator.mw-ui-icon-flush-left::before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mwe-math-fallback-image-display,\x20.mwe-math-fallback-image-inline{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color\x20:\x20transparent\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.table-yes,\x20.table-no,\x20.table-maybe,\x20.table-partial\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20black\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.lazy-image-placeholder{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.infobox_v3\x20caption,\x20.infobox_v3\x20.bloc\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#4895f9\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.infobox_v3\x20.entete\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#4895f9\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20td\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#3366cc\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'context.reverso.net': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#examples-content\x20.example\x20.trg\x20.text-nikkud\x20em,\x20#examples-content\x20.example\x20.trg\x20.text\x20em\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#858500\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'rskey.org': _0x3e9541(0x282),
                'fmkorea.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bd_btn,\x20.btn_img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow\x20:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bubble\x20b[nitefall_imageType=\x22png\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'redmondpie.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li\x20a.top_link\x20span,\x20#winnav\x20li\x20a.top_link,\x20#winnav\x20li.top\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(128,\x20153,\x20165)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li:hover\x20ul.sub\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li:hover\x20ul.sub\x20li\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(128,\x20153,\x20165)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#body2,\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-top:\x204px\x20solid\x20theme_color;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li.top\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li\x20ul.sub\x20li\x20a.fly\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li:hover\x20ul\x20li:hover\x20ul\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.leftalignLogo,\x20.footer\x20h4\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(32%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#SubscribeBoxOption\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(56%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.lefigaro.fr': _0x3e9541(0x1df),
                'blog.google': _0x3e9541(0x677),
                'colorhexa.com': _0x3e9541(0x296),
                'geometricsoftware.se': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.styles_childContainer__3G9RO\x20>\x20div{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'developer.apple.com': _0x3e9541(0x393),
                'iphonetweak.fr': _0x3e9541(0x4c6),
                'iphonehacks.com': _0x3e9541(0x4d6),
                'bwt.cbp.gov': _0x3e9541(0x30c),
                'mozilla.org': _0x3e9541(0x41c),
                'dailymail.co.uk': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#page-container\x20.page-header\x20.nav-primary\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'gsmarena.com': _0x3e9541(0x260),
                'bt.dk': _0x3e9541(0x52a),
                'solohdnet46.net': _0x3e9541(0x532),
                'www.definitions.net': _0x3e9541(0x64e),
                'lux.camera': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.blocks-gallery-item\x20figure{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:white\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'sukre.myqnapcloud.com:8180': _0x3e9541(0x300),
                'telegra.ph': _0x3e9541(0x35b),
                'telegram.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[data-t-l]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnt_m_dl::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'appgallery.huawei.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[src^=\x22data:image/svg+xml\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'logentries.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20[ng-react-component]\x20.btn--tertiary\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'javrave.club': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'javraveclub.com': _0x3e9541(0x3c0),
                'developer.wordpress.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.single-handbook\x20#page{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'amazon.com': _0x3e9541(0x4cb),
                'baidu.com': _0x3e9541(0x459),
                'mail.ru': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pl_p7:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'cydia.saurik.com': _0x3e9541(0x1d6),
                'default': _0x3e9541(0x521)
            }, _0x319fc9 = getMainDomain(_0x54ecec), _0x25ea47 = [
                _0x548d91['EQUCT'],
                _0x548d91[_0x3e9541(0x370)],
                _0x548d91[_0x3e9541(0x5db)]
            ];
        for (domain of _0x25ea47) {
            if (_0x319fc9[_0x3e9541(0x363)](domain)) {
                let _0x47e217 = _0x54ecec['substring'](0x0, _0x54ecec[_0x3e9541(0x6a1)](_0x319fc9));
                _0x319fc9 = domain + 'com', _0x54ecec = _0x548d91[_0x3e9541(0x436)](_0x47e217, _0x319fc9);
            }
        }
        console[_0x3e9541(0x65f)]('finding\x20custom\x20css\x20for\x20' + _0x319fc9 + _0x3e9541(0x23a) + _0x54ecec);
        let _0x3b55b9 = _0x3b2da1[_0x319fc9] || '';
        if (!_0x3b55b9['length'])
            _0x3b55b9 = _0x3b2da1[_0x3e9541(0x249) + _0x319fc9] || '';
        let _0x267b2f = _0x3b2da1[_0x54ecec] || '';
        return _0x3e9541(0x177) + _0x3b2da1[_0x548d91['sVLHj']] + _0x3e9541(0x3a4) + _0x319fc9 + _0x3e9541(0x16e) + _0x3b55b9 + '\x20\x0a\x20\x20\x20\x20/*\x20====================\x20end\x20of\x20css\x20for\x20' + _0x319fc9 + '\x20======================*/\x0a\x20\x20\x20\x20\x0a\x0a\x20\x20\x20\x20/*\x20====================\x20css\x20for\x20' + _0x54ecec + '\x20======================*/\x0a\x20\x20\x20\x20' + _0x267b2f + _0x3e9541(0x69c) + _0x54ecec + '\x20======================*/\x0a\x0a\x20\x20\x20\x20';
    };
var NITEFALL_CUSTOM_CSS_ID = _0x4a728d(0x486), NITEFALL_START_WORKAROUND_CSS_ID = _0x4a728d(0x512), currentTheme = _0x4a728d(0x377), hasProcessedPage = ![], mutationObserver, ignoredElements = [
        'VIDEO',
        _0x4a728d(0x479),
        _0x4a728d(0x61d),
        _0x4a728d(0x220),
        _0x4a728d(0x488),
        'H',
        _0x4a728d(0x2c2),
        _0x4a728d(0x22e),
        'BR',
        'MATH'
    ];
let ignoredBackgroundSelectors = getIgnoredSelectors(document[_0x4a728d(0x2d5)][_0x4a728d(0x318)]);
var WEBPAGE_COLORS = {
        'bgColors': new Map(),
        'textColors': new Map()
    }, globalSettings;
const setNewColor = (_0x29ce08, _0x23e6f9, _0x3fa645) => {
        var _0x5e64a8 = _0x4a728d, _0x378f1b = { 'nRMOY': 'text' };
        switch (_0x29ce08) {
        case 'bg':
            WEBPAGE_COLORS[_0x5e64a8(0x21c)][_0x5e64a8(0x1a1)](_0x23e6f9[_0x5e64a8(0x59d)](), _0x3fa645[_0x5e64a8(0x59d)]());
            break;
        case _0x378f1b[_0x5e64a8(0x46a)]:
            WEBPAGE_COLORS[_0x5e64a8(0x351)][_0x5e64a8(0x1a1)](_0x23e6f9[_0x5e64a8(0x59d)](), _0x3fa645[_0x5e64a8(0x59d)]());
            break;
        }
    }, getNewColor = (_0x36b36c, _0x3503dd) => {
        var _0x1d03ba = _0x4a728d, _0x146368 = { 'PTLqT': _0x1d03ba(0x137) };
        switch (_0x36b36c) {
        case 'bg':
            return WEBPAGE_COLORS[_0x1d03ba(0x21c)][_0x1d03ba(0x23b)](_0x3503dd);
        case _0x146368[_0x1d03ba(0x616)]:
            return WEBPAGE_COLORS['textColors'][_0x1d03ba(0x23b)](_0x3503dd);
        }
    }, getPageColor = () => {
        var _0x1fb4a5 = _0x4a728d, _0x15f36d = {
                'nsQqZ': function (_0x2e4b12, _0x5a60f1) {
                    return _0x2e4b12 == _0x5a60f1;
                },
                'mPaLZ': function (_0x591259, _0x5f3ba2) {
                    return _0x591259 == _0x5f3ba2;
                },
                'MvmVq': _0x1fb4a5(0x4e4)
            };
        if (_0x15f36d['nsQqZ'](currentTheme, 'dark-gray'))
            return new NFColor(0x16, 0x17, 0x16, 0x1);
        else
            return _0x15f36d[_0x1fb4a5(0x627)](currentTheme, _0x15f36d[_0x1fb4a5(0x3d5)]) ? new NFColor(0x28, 0x28, 0x27, 0x1) : new NFColor(0x0, 0x0, 0x0, 0x1);
    }, getPageSubColor = () => {
        var _0x3dd9df = _0x4a728d, _0x4c58fa = {
                'vykZL': _0x3dd9df(0x377),
                'kGage': _0x3dd9df(0x4e4)
            };
        if (currentTheme == _0x4c58fa[_0x3dd9df(0x191)])
            return new NFColor(0x24, 0x23, 0x23, 0x1);
        else
            return currentTheme == _0x4c58fa[_0x3dd9df(0x5c7)] ? new NFColor(0x2e, 0x2e, 0x2e, 0x1) : new NFColor(0x19, 0x19, 0x19, 0x1);
    }, iterateElementsWithShadowHost = (_0xee6ff9, _0xf94362) => {
        var _0x5246b2 = _0x4a728d, _0x5a3b40 = {
                'ArSwb': function (_0x35425b, _0x192d64) {
                    return _0x35425b == _0x192d64;
                },
                'lzDiz': function (_0x5e49b0, _0x3019c1) {
                    return _0x5e49b0 == _0x3019c1;
                },
                'SCwNc': function (_0x5e1ea0, _0x383b1d) {
                    return _0x5e1ea0 != _0x383b1d;
                },
                'abGkM': function (_0x357738, _0x3cd5f8) {
                    return _0x357738(_0x3cd5f8);
                },
                'rPPFn': function (_0x57c5bc, _0x2eb81e, _0x566b51) {
                    return _0x57c5bc(_0x2eb81e, _0x566b51);
                }
            };
        if (_0x5a3b40[_0x5246b2(0x3bd)](_0xee6ff9, null))
            return;
        const _0x54b992 = document[_0x5246b2(0x433)](_0xee6ff9, NodeFilter[_0x5246b2(0x525)], {
            'acceptNode'(_0x16e38d) {
                var _0x175a56 = _0x5246b2;
                return _0x5a3b40['ArSwb'](_0x16e38d[_0x175a56(0x244)], null) ? NodeFilter[_0x175a56(0x254)] : NodeFilter[_0x175a56(0x38b)];
            }
        });
        for (let _0x2d8a0a = _0xee6ff9[_0x5246b2(0x244)] ? _0x54b992['currentNode'] : _0x54b992[_0x5246b2(0x531)](); _0x5a3b40['SCwNc'](_0x2d8a0a, null); _0x2d8a0a = _0x54b992[_0x5246b2(0x531)]()) {
            _0x5a3b40[_0x5246b2(0x38a)](_0xf94362, _0x2d8a0a), _0x5a3b40[_0x5246b2(0x2fd)](iterateElementsWithShadowHost, _0x2d8a0a[_0x5246b2(0x244)], _0xf94362);
        }
    }, processElement = (_0x46b6c9, _0x27cecd) => {
        var _0x4dea73 = _0x4a728d, _0x119bc6 = {
                'XdajA': function (_0x4e046d, _0x4c2af5) {
                    return _0x4e046d(_0x4c2af5);
                },
                'ahyFy': function (_0x1eba7e, _0x21f99c) {
                    return _0x1eba7e(_0x21f99c);
                },
                'FlWTJ': function (_0x4d892c, _0x5bfbb0) {
                    return _0x4d892c(_0x5bfbb0);
                },
                'qcGYf': function (_0x41fd52, _0xe61b3b) {
                    return _0x41fd52 && _0xe61b3b;
                },
                'zswfX': function (_0xb5820, _0x455f88, _0xbc8b58, _0x4387d3) {
                    return _0xb5820(_0x455f88, _0xbc8b58, _0x4387d3);
                },
                'rwtJI': function (_0x36f8c7) {
                    return _0x36f8c7();
                },
                'ISnvi': function (_0x5d852) {
                    return _0x5d852();
                },
                'FrGNK': function (_0x5bc698, _0x45f6c8, _0x590306, _0x14d930) {
                    return _0x5bc698(_0x45f6c8, _0x590306, _0x14d930);
                },
                'xnLvo': function (_0x155f08, _0x5ccc94) {
                    return _0x155f08 == _0x5ccc94;
                },
                'iiaaq': function (_0x34a95e, _0x1ec2b1) {
                    return _0x34a95e(_0x1ec2b1);
                },
                'dxqNH': 'text',
                'tVryl': function (_0x53a174, _0x5ea5e5, _0x404c62, _0x132644) {
                    return _0x53a174(_0x5ea5e5, _0x404c62, _0x132644);
                },
                'ZdzXy': function (_0x35c774) {
                    return _0x35c774();
                },
                'pbKDq': _0x4dea73(0x283),
                'mfFfH': _0x4dea73(0x290),
                'DBmHH': function (_0x28c772, _0x2c25a3, _0x64574b) {
                    return _0x28c772(_0x2c25a3, _0x64574b);
                },
                'qivHd': function (_0x2e250b, _0x168673) {
                    return _0x2e250b(_0x168673);
                },
                'lnWiN': function (_0x2ed53c) {
                    return _0x2ed53c();
                },
                'tnhBR': _0x4dea73(0x13f),
                'VAVWV': _0x4dea73(0x146),
                'mdhvx': 'BODY',
                'DsfyJ': function (_0xdacb03, _0x4dacbc, _0x42e6ff) {
                    return _0xdacb03(_0x4dacbc, _0x42e6ff);
                },
                'IsvrN': _0x4dea73(0x469),
                'ijHYr': _0x4dea73(0x151),
                'RNBCh': _0x4dea73(0x187),
                'kRGnR': _0x4dea73(0x288),
                'QLzce': _0x4dea73(0x39d),
                'ePZek': _0x4dea73(0x584),
                'DPMwG': function (_0x2dbd9a, _0x6a260, _0x5b03ee) {
                    return _0x2dbd9a(_0x6a260, _0x5b03ee);
                }
            };
        if (!_0x46b6c9)
            return;
        if ([
                0x3,
                0x8
            ][_0x4dea73(0x153)](_0x46b6c9['nodeType']) || ignoredElements[_0x4dea73(0x153)](_0x46b6c9['tagName'][_0x4dea73(0x2bd)]()))
            return;
        if (_0x119bc6['XdajA'](isElementBlacklisted, _0x46b6c9))
            return processElement(_0x46b6c9[_0x4dea73(0x41f)], _0x27cecd);
        if (_0x27cecd) {
            if (_0x46b6c9[_0x4dea73(0x371)][_0x4dea73(0x52e)]('nitefall_processed'))
                return;
            _0x46b6c9[_0x4dea73(0x244)] && Array[_0x4dea73(0x42f)](_0x46b6c9[_0x4dea73(0x244)]['childNodes'])[_0x4dea73(0x15c)](_0x172f48 => _0x172f48['tagName'] != 'STYLE')[_0x4dea73(0x190)](_0x5b9c8e => processElement(_0x5b9c8e, _0x27cecd));
            var _0x175b18 = _0x119bc6[_0x4dea73(0x482)](getComputedStyle, _0x46b6c9), _0x356fad = _0x119bc6[_0x4dea73(0x287)](NFColorFromRGBString, _0x175b18['backgroundColor']), _0x4cc60c = _0x119bc6[_0x4dea73(0x310)](NFColorFromRGBString, _0x175b18[_0x4dea73(0x584)]), _0x87b077, _0x5aca1f;
            if (_0x119bc6[_0x4dea73(0x36e)](_0x356fad, _0x4cc60c)) {
                if (!WEBPAGE_COLORS[_0x4dea73(0x21c)][_0x4dea73(0x1fa)](_0x356fad[_0x4dea73(0x59d)]())) {
                    if (_0x356fad['isTransparent']())
                        _0x119bc6[_0x4dea73(0x2ce)](setNewColor, 'bg', _0x356fad, _0x119bc6[_0x4dea73(0x1d5)](TransparentColor));
                    else {
                        if (_0x356fad[_0x4dea73(0x565)]()) {
                            var _0xf55454 = _0x356fad[_0x4dea73(0x1e0)](-0x14);
                            if (_0x119bc6['FlWTJ'](isBlack, _0xf55454))
                                _0xf55454 = _0x119bc6[_0x4dea73(0x416)](getPageColor);
                            _0x119bc6['zswfX'](setNewColor, 'bg', _0x356fad, _0xf55454);
                        } else {
                            if (_0x356fad[_0x4dea73(0x34c)]()) {
                                var _0xf55454 = _0x356fad[_0x4dea73(0x527)]()[_0x4dea73(0x1fb)]();
                                if (_0x119bc6[_0x4dea73(0x310)](isBlack, _0xf55454))
                                    _0xf55454 = getPageColor();
                                _0x119bc6['zswfX'](setNewColor, 'bg', _0x356fad, _0xf55454);
                            } else {
                                var _0xf55454 = _0x356fad[_0x4dea73(0x1e0)](-0x32);
                                if (isBlack(_0xf55454))
                                    _0xf55454 = _0x119bc6[_0x4dea73(0x416)](getPageColor);
                                _0x119bc6[_0x4dea73(0x671)](setNewColor, 'bg', _0x356fad, _0xf55454);
                            }
                        }
                    }
                }
                _0x356fad[_0x4dea73(0x59d)]() == _0x119bc6[_0x4dea73(0x416)](getPageSubColor)['rgbString']() || _0x119bc6[_0x4dea73(0x307)](_0x356fad[_0x4dea73(0x59d)](), _0x119bc6[_0x4dea73(0x416)](getPageColor)[_0x4dea73(0x59d)]()) ? _0x87b077 = _0x356fad : _0x87b077 = _0x119bc6[_0x4dea73(0x602)](NFColorFromRGBString, getNewColor('bg', _0x356fad[_0x4dea73(0x59d)]()));
                if (!WEBPAGE_COLORS[_0x4dea73(0x351)][_0x4dea73(0x1fa)](_0x4cc60c[_0x4dea73(0x59d)]())) {
                    if (_0x4cc60c['isTransparent']())
                        _0x119bc6['FrGNK'](setNewColor, _0x119bc6['dxqNH'], _0x4cc60c, _0x119bc6['ISnvi'](TransparentColor));
                    else
                        _0x4cc60c[_0x4dea73(0x565)]() ? !_0x4cc60c[_0x4dea73(0x34c)]() ? setNewColor(_0x4dea73(0x137), _0x4cc60c, _0x4cc60c[_0x4dea73(0x1e0)](0x32)) : _0x119bc6[_0x4dea73(0x671)](setNewColor, _0x4dea73(0x137), _0x4cc60c, _0x4cc60c) : !_0x4cc60c[_0x4dea73(0x34c)]() ? _0x119bc6['tVryl'](setNewColor, _0x119bc6[_0x4dea73(0x491)], _0x4cc60c, _0x4cc60c[_0x4dea73(0x527)]()[_0x4dea73(0x1fb)]()) : setNewColor(_0x4dea73(0x137), _0x4cc60c, _0x4cc60c);
                }
                _0x5aca1f = NFColorFromRGBString(getNewColor(_0x119bc6[_0x4dea73(0x491)], _0x4cc60c[_0x4dea73(0x59d)]()));
                if (!_0x87b077)
                    _0x87b077 = _0x119bc6[_0x4dea73(0x67d)](getPageColor);
                if (!_0x5aca1f)
                    _0x5aca1f = _0x119bc6[_0x4dea73(0x67d)](GrayColor);
                let _0x1d973d = _0x356fad[_0x4dea73(0x5ab)]() && _0x175b18[_0x4dea73(0x1dd)][_0x4dea73(0x153)](_0x4dea73(0x13f)), _0x56aa89 = [
                        _0x119bc6['pbKDq'],
                        _0x119bc6['mfFfH']
                    ];
                for (let _0x225e20 of _0x56aa89) {
                    let _0x2ed3d9 = _0x119bc6['DBmHH'](getComputedStyle, _0x46b6c9, _0x225e20), _0x1cbe98 = _0x119bc6['qivHd'](NFColorFromRGBString, _0x2ed3d9['backgroundColor']), _0x59e2f7;
                    if (_0x1cbe98[_0x4dea73(0x34c)]())
                        _0x59e2f7 = { 'background-color': _0x119bc6[_0x4dea73(0x378)](getPageColor)[_0x4dea73(0x59d)]() + _0x4dea73(0x2e2) };
                    else
                        _0x2ed3d9[_0x4dea73(0x1dd)][_0x4dea73(0x153)](_0x119bc6['tnhBR']) && (_0x59e2f7 = {
                            'background': _0x119bc6['VAVWV'],
                            'background-image': _0x119bc6['VAVWV']
                        });
                    let _0xb23664 = _0x46b6c9['id']['length'] || _0x46b6c9[_0x4dea73(0x454)]['length'];
                    if (_0x119bc6[_0x4dea73(0x36e)](_0x59e2f7, _0xb23664))
                        addStyleForPseudoElement(_0x46b6c9, _0x225e20, _0x59e2f7);
                }
                switch (_0x46b6c9[_0x4dea73(0x52d)]) {
                case _0x119bc6['mdhvx']:
                    _0x119bc6['DsfyJ'](applyColorChange, _0x46b6c9, {
                        'backgroundColor': _0x87b077,
                        'textColor': _0x5aca1f,
                        'borderColor': darkBorderColorIfNeeded(_0x175b18)
                    });
                    break;
                case _0x4dea73(0x220):
                    _0x46b6c9[_0x4dea73(0x688)]['removeChild'](_0x46b6c9);
                    break;
                case _0x119bc6[_0x4dea73(0x1e9)]:
                case _0x119bc6[_0x4dea73(0x61c)]:
                    var _0x2a6270 = {
                        'backgroundColor': _0x87b077,
                        'textColor': _0x87b077 ? !_0x87b077[_0x4dea73(0x34c)]() ? _0x5aca1f : null : _0x5aca1f,
                        'borderColor': darkBorderColorIfNeeded(_0x175b18),
                        'background': _0x1d973d ? _0x119bc6[_0x4dea73(0x214)] : null
                    };
                    applyColorChange(_0x46b6c9, _0x2a6270);
                    break;
                default:
                    _0x119bc6[_0x4dea73(0x32e)](applyColorChange, _0x46b6c9, {
                        'backgroundColor': _0x87b077,
                        'textColor': _0x5aca1f,
                        'borderColor': darkBorderColorIfNeeded(_0x175b18),
                        'background': _0x1d973d ? _0x119bc6['RNBCh'] : null
                    });
                    break;
                }
            }
        } else {
            _0x46b6c9[_0x4dea73(0x371)][_0x4dea73(0x50f)](_0x119bc6['kRGnR']);
            switch (_0x46b6c9[_0x4dea73(0x52d)]) {
            default:
                _0x46b6c9[_0x4dea73(0x4ce)][_0x4dea73(0x625)](_0x119bc6['QLzce']), _0x46b6c9[_0x4dea73(0x4ce)]['removeProperty'](_0x119bc6['ePZek']), _0x46b6c9[_0x4dea73(0x4ce)]['removeProperty'](_0x4dea73(0x1dc));
            }
        }
        _0x46b6c9 = _0x46b6c9[_0x4dea73(0x430)];
        while (_0x46b6c9) {
            _0x119bc6['DPMwG'](processElement, _0x46b6c9, _0x27cecd), _0x46b6c9 = _0x46b6c9[_0x4dea73(0x41f)];
        }
    }, selectorForElement = _0x2b0214 => {
        var _0x397430 = _0x4a728d, _0x116fc5 = {
                'bWugT': function (_0x3bd953, _0x43597b) {
                    return _0x3bd953 === _0x43597b;
                },
                'ZIwTf': _0x397430(0x65d),
                'mEyUw': function (_0x13a8bb, _0x455641) {
                    return _0x13a8bb < _0x455641;
                },
                'XpQTd': function (_0x4b4c88, _0x2b337a) {
                    return _0x4b4c88 + _0x2b337a;
                },
                'ZVEox': function (_0x764ffb, _0x17309d) {
                    return _0x764ffb + _0x17309d;
                },
                'sATpV': function (_0x43dbf1, _0x21326b) {
                    return _0x43dbf1 + _0x21326b;
                },
                'CwcMd': function (_0x23b176, _0x515567) {
                    return _0x23b176 === _0x515567;
                }
            };
        let _0x5c8575;
        if (_0x2b0214['id'])
            _0x5c8575 = '#' + _0x2b0214['id'];
        else {
            if (_0x2b0214[_0x397430(0x454)]) {
                for (var _0x51822a = '', _0x59ea32 = _0x2b0214; null != _0x59ea32;)
                    if (_0x59ea32[_0x397430(0x454)]) {
                        var _0x2a3be1 = '';
                        if (_0x116fc5['bWugT'](_0x116fc5[_0x397430(0x5a1)], _0x59ea32['tagName']))
                            _0x2a3be1 = _0x59ea32[_0x397430(0x454)]['baseVal'];
                        else {
                            for (var _0x32e48c = 0x0; _0x116fc5[_0x397430(0x5f4)](_0x32e48c, _0x59ea32['classList'][_0x397430(0x1d9)]); ++_0x32e48c)
                                _0x2a3be1 += _0x116fc5[_0x397430(0x4b9)]('.', _0x59ea32[_0x397430(0x371)][_0x32e48c]);
                        }
                        _0x51822a = '' === _0x51822a ? _0x2a3be1 : _0x116fc5[_0x397430(0x48d)](_0x116fc5[_0x397430(0x422)](_0x2a3be1, '\x20'), _0x51822a), _0x59ea32 = _0x59ea32[_0x397430(0x688)];
                    } else
                        _0x116fc5[_0x397430(0x54f)]('', _0x51822a) && (_0x51822a = _0x59ea32[_0x397430(0x324)]), _0x59ea32 = _0x59ea32[_0x397430(0x688)];
                _0x5c8575 = _0x51822a;
            } else
                _0x5c8575 = _0x2b0214[_0x397430(0x35f)];
        }
        return _0x5c8575;
    }, addStyleForPseudoElement = (_0x5c56ce, _0x120c12, _0x3cd44a) => {
        var _0x4ef2a8 = _0x4a728d, _0x56d51d = { 'XNegQ': _0x4ef2a8(0x235) };
        let _0x3a547a = selectorForElement(_0x5c56ce);
        if (!_0x3a547a)
            return;
        _0x3a547a = _0x3a547a[_0x4ef2a8(0x594)](_0x56d51d[_0x4ef2a8(0x157)], ''), _0x3a547a = '' + _0x3a547a + _0x120c12, addCSSRule(_0x3a547a, _0x3cd44a);
    }, addCSSRule = (_0x395b8b, _0x2c3b9e) => {
        var _0x282a73 = _0x4a728d, _0x7e33f9 = {
                'hOOTd': function (_0xa9ef37, _0x120f23) {
                    return _0xa9ef37 + _0x120f23;
                },
                'yAegy': function (_0x588207, _0xe7f7a8) {
                    return _0x588207 + _0xe7f7a8;
                },
                'VDFgH': _0x282a73(0x4ce),
                'kLHKp': function (_0x18f443, _0x126ba3) {
                    return _0x18f443 + _0x126ba3;
                }
            };
        let _0x2ccfe7 = 'nitefall_pseudo_elements_style';
        var _0x21a360 = document[_0x282a73(0x652)](_0x2ccfe7);
        !_0x21a360 && (_0x21a360 = document[_0x282a73(0x534)](_0x7e33f9['VDFgH']), _0x21a360['id'] = _0x2ccfe7, document['head'][_0x282a73(0x4a7)](_0x21a360));
        var _0x388b95 = _0x21a360[_0x282a73(0x610)];
        for (rule of _0x388b95[_0x282a73(0x40c)]) {
            if (rule['selectorText'][_0x282a73(0x609)]('::', ':') == _0x395b8b)
                return;
        }
        let _0x26bba2 = Object[_0x282a73(0x1c8)](_0x2c3b9e)['map'](_0x5765d0 => {
            var _0x386de0 = _0x282a73;
            return _0x7e33f9['hOOTd'](_0x7e33f9[_0x386de0(0x49e)](_0x5765d0, ':'), _0x2c3b9e[_0x5765d0]);
        })[_0x282a73(0x3e2)](';');
        try {
            _0x388b95[_0x282a73(0x56b)](_0x7e33f9['kLHKp'](_0x7e33f9['kLHKp'](_0x7e33f9[_0x282a73(0x2c8)](_0x395b8b, '{'), _0x26bba2), '}'), _0x388b95[_0x282a73(0x2d0)][_0x282a73(0x1d9)]);
        } catch (_0x25bc5c) {
            console[_0x282a73(0x698)](_0x25bc5c);
        }
    }, darkBorderColorIfNeeded = _0x5e1f1f => {
        var _0x57b9e1 = _0x4a728d, _0x8c2940 = {
                'hHcYA': _0x57b9e1(0x668),
                'sfgnz': _0x57b9e1(0x3ae),
                'zJrVM': _0x57b9e1(0x4c3),
                'MCjsb': function (_0x5cef7c, _0x19473e) {
                    return _0x5cef7c < _0x19473e;
                },
                'OLdGk': function (_0xaa4dc8, _0xf68444) {
                    return _0xaa4dc8 + _0xf68444;
                },
                'HuXdo': function (_0x4a89ef, _0x504647) {
                    return _0x4a89ef + _0x504647;
                },
                'vvXYk': _0x57b9e1(0x437),
                'jBTel': function (_0x239397, _0x46abf7) {
                    return _0x239397 > _0x46abf7;
                },
                'Zzknk': _0x57b9e1(0x5ae),
                'PHIsS': _0x57b9e1(0x38d),
                'Ejsnr': function (_0x45150a, _0x533f3d) {
                    return _0x45150a(_0x533f3d);
                },
                'vKvDw': function (_0x3150e7) {
                    return _0x3150e7();
                }
            };
        let _0x3f5cee = ![], _0x53b55c = [
                _0x8c2940['hHcYA'],
                _0x57b9e1(0x581),
                _0x8c2940['sfgnz'],
                _0x8c2940['zJrVM']
            ];
        for (var _0x4ca0b0 = 0x0, _0x363986 = _0x53b55c[_0x57b9e1(0x1d9)]; _0x8c2940['MCjsb'](_0x4ca0b0, _0x363986); _0x4ca0b0++) {
            let _0xbd2c6a = Math[_0x57b9e1(0x338)](0x0, parseInt(_0x5e1f1f['getPropertyValue'](_0x8c2940[_0x57b9e1(0x2a2)](_0x8c2940['HuXdo'](_0x57b9e1(0x5ae), _0x53b55c[_0x4ca0b0]), _0x8c2940['vvXYk']))));
            if (_0x8c2940[_0x57b9e1(0x3ed)](_0xbd2c6a, 0x0)) {
                let _0xfff25 = _0x5e1f1f[_0x57b9e1(0x281)](_0x8c2940[_0x57b9e1(0x558)](_0x8c2940['HuXdo'](_0x8c2940[_0x57b9e1(0x487)], _0x53b55c[_0x4ca0b0]), _0x8c2940[_0x57b9e1(0x593)]));
                if (_0xfff25) {
                    if (_0x8c2940[_0x57b9e1(0x58d)](NFColorFromRGBString, _0xfff25)[_0x57b9e1(0x34c)]()) {
                        _0x3f5cee = !![];
                        break;
                    }
                }
            }
        }
        if (_0x3f5cee)
            return _0x8c2940[_0x57b9e1(0x687)](getPageSubColor);
        return null;
    }, isElementBlacklisted = _0x4895a6 => {
        var _0x367805 = _0x4a728d, _0x49ddff = {
                'cRPQS': function (_0x3fde37, _0x59c0a7) {
                    return _0x3fde37 != _0x59c0a7;
                }
            };
        for (var _0x3763b9 of ignoredBackgroundSelectors) {
            let _0x342ec8 = _0x49ddff[_0x367805(0x376)](_0x4895a6[_0x367805(0x4e7)](_0x3763b9), null);
            if (_0x4895a6[_0x367805(0x4dc)](_0x3763b9) || _0x342ec8)
                return !![];
        }
        return ![];
    }, applyColorChange = (_0x345854, _0x54087d) => {
        var _0x3c7e39 = _0x4a728d, _0x3e7a46 = {
                'sUOzW': function (_0xdc1a43, _0x318652, _0x232ef2) {
                    return _0xdc1a43(_0x318652, _0x232ef2);
                }
            };
        if (_0x54087d[_0x3c7e39(0x694)])
            _0x3e7a46['sUOzW'](applyTextColor, _0x345854, _0x54087d[_0x3c7e39(0x694)]);
        if (_0x54087d[_0x3c7e39(0x5f5)])
            applyBorderColor(_0x345854, _0x54087d['borderColor']);
        if (_0x54087d[_0x3c7e39(0x1dd)])
            applyBackground(_0x345854, _0x54087d[_0x3c7e39(0x1dd)]);
        if (_0x54087d[_0x3c7e39(0x374)])
            applyBackgroundColor(_0x345854, _0x54087d['backgroundColor']);
    }, applyBorderColor = (_0x40dfee, _0x360ab1) => {
        var _0xf04ab1 = _0x4a728d, _0x3eb01b = {
                'iCnER': _0xf04ab1(0x4f1),
                'gaKWr': _0xf04ab1(0x288)
            };
        _0x40dfee[_0xf04ab1(0x4ce)][_0xf04ab1(0x1cf)](_0xf04ab1(0x1dc), _0x360ab1[_0xf04ab1(0x59d)](), _0x3eb01b[_0xf04ab1(0x49f)]), _0x40dfee[_0xf04ab1(0x371)][_0xf04ab1(0x53d)](_0x3eb01b['gaKWr']);
    }, applyTextColor = (_0x545fbc, _0x5e4fa6) => {
        var _0x2a7092 = _0x4a728d, _0x21d1b7 = {
                'YdnAN': _0x2a7092(0x584),
                'jFcUK': _0x2a7092(0x4f1),
                'TfQPz': _0x2a7092(0x288)
            };
        _0x545fbc[_0x2a7092(0x4ce)][_0x2a7092(0x1cf)](_0x21d1b7[_0x2a7092(0x5b5)], _0x5e4fa6[_0x2a7092(0x59d)](), _0x21d1b7['jFcUK']), _0x545fbc[_0x2a7092(0x371)]['add'](_0x21d1b7[_0x2a7092(0x494)]);
    }, applyBackground = (_0x190a73, _0x309437) => {
        var _0x17bbbf = _0x4a728d, _0x4153b6 = {
                'GfNtK': _0x17bbbf(0x1dd),
                'bKUBi': _0x17bbbf(0x4f1),
                'ZItho': _0x17bbbf(0x288)
            };
        _0x190a73[_0x17bbbf(0x4ce)][_0x17bbbf(0x1cf)](_0x4153b6['GfNtK'], _0x309437, _0x4153b6[_0x17bbbf(0x48c)]), _0x190a73['classList']['add'](_0x4153b6[_0x17bbbf(0x1bb)]);
    }, applyBackgroundColor = (_0x4d32a3, _0xc618e) => {
        var _0x270ce6 = _0x4a728d, _0x2aa5b2 = {
                'DfjuP': _0x270ce6(0x201),
                'mUnNc': _0x270ce6(0x569),
                'hnRlJ': _0x270ce6(0x39d),
                'PfCLe': _0x270ce6(0x4f1),
                'YoIoY': _0x270ce6(0x288)
            };
        _0x4d32a3[_0x270ce6(0x632)](_0x2aa5b2[_0x270ce6(0x333)]) != _0x2aa5b2[_0x270ce6(0x414)] && (_0x4d32a3[_0x270ce6(0x4ce)][_0x270ce6(0x1cf)](_0x2aa5b2['hnRlJ'], _0xc618e[_0x270ce6(0x59d)](), _0x2aa5b2[_0x270ce6(0x659)]), _0x4d32a3[_0x270ce6(0x371)][_0x270ce6(0x53d)](_0x2aa5b2[_0x270ce6(0x528)]));
    }, handleMutations = _0x3f0554 => {
        var _0xc6d942 = _0x4a728d, _0x34b030 = {
                'vWshu': function (_0x886e46) {
                    return _0x886e46();
                },
                'XegrF': function (_0x1b6a1c, _0x1fabeb) {
                    return _0x1b6a1c != _0x1fabeb;
                },
                'ilhBV': function (_0x3ad935, _0x4e912e, _0x31bc05) {
                    return _0x3ad935(_0x4e912e, _0x31bc05);
                },
                'NbpXS': function (_0x232f2f, _0x40e8b9) {
                    return _0x232f2f(_0x40e8b9);
                }
            };
        _0x3f0554[_0xc6d942(0x190)](_0x11fbda => {
            var _0x4d1d52 = _0xc6d942, _0x24303b = {
                    'wObdA': function (_0x41fb75) {
                        var _0x5df6b5 = _0x4c3d;
                        return _0x34b030[_0x5df6b5(0x56a)](_0x41fb75);
                    },
                    'IMwqk': function (_0x26ef13, _0x808743) {
                        var _0x5908f9 = _0x4c3d;
                        return _0x34b030[_0x5908f9(0x24e)](_0x26ef13, _0x808743);
                    },
                    'RyJBt': function (_0x51dc0f, _0x243481, _0x9eaf8c) {
                        var _0x17d164 = _0x4c3d;
                        return _0x34b030[_0x17d164(0x391)](_0x51dc0f, _0x243481, _0x9eaf8c);
                    },
                    'HPEGA': function (_0x3ad84d, _0x4379dd) {
                        var _0x381afa = _0x4c3d;
                        return _0x34b030[_0x381afa(0x2d3)](_0x3ad84d, _0x4379dd);
                    }
                };
            _0x11fbda['addedNodes'][_0x4d1d52(0x190)](_0x54e376 => {
                var _0x343a77 = _0x4d1d52, _0x4eef3d = {
                        'IQzwo': function (_0x323089) {
                            var _0x2c7fdf = _0x4c3d;
                            return _0x24303b[_0x2c7fdf(0x18d)](_0x323089);
                        },
                        'pnerN': function (_0xf10c19, _0x287004) {
                            var _0x2729ed = _0x4c3d;
                            return _0x24303b[_0x2729ed(0x57f)](_0xf10c19, _0x287004);
                        },
                        'SSyhM': _0x343a77(0x630),
                        'yKDlC': function (_0x769c4e, _0x5c4c7f, _0x2dfa10) {
                            var _0x26aa89 = _0x343a77;
                            return _0x24303b[_0x26aa89(0x1a5)](_0x769c4e, _0x5c4c7f, _0x2dfa10);
                        },
                        'OzxZE': function (_0x392405, _0x4c7c75) {
                            var _0x197608 = _0x343a77;
                            return _0x24303b[_0x197608(0x33f)](_0x392405, _0x4c7c75);
                        }
                    };
                _0x24303b[_0x343a77(0x33f)](queueMicrotask, () => {
                    var _0x85db3d = _0x343a77;
                    if (_0x4eef3d[_0x85db3d(0x5d5)](isSystemDarkModeOn)) {
                        var _0x481a36 = _0x4eef3d[_0x85db3d(0x631)](document[_0x85db3d(0x189)][_0x85db3d(0x632)](_0x4eef3d[_0x85db3d(0x693)]), null);
                        _0x481a36 && (_0x4eef3d[_0x85db3d(0x613)](processElement, _0x54e376, !![]), _0x4eef3d[_0x85db3d(0x236)](findAndTagSvgs, _0x54e376));
                    }
                });
            });
        });
    }, addCustomDarkCss = () => {
        var _0x11dfe7 = _0x4a728d, _0x136301 = {
                'QwiII': _0x11dfe7(0x630),
                'lmVMi': _0x11dfe7(0x34a),
                'buQTh': _0x11dfe7(0x4ce),
                'GzLpu': function (_0x282d3d, _0x23b529) {
                    return _0x282d3d(_0x23b529);
                },
                'xBYrW': function (_0x5a2678) {
                    return _0x5a2678();
                },
                'ZeRwg': 'theme_color',
                'RcrEF': function (_0x33980a) {
                    return _0x33980a();
                },
                'WahMW': _0x11dfe7(0x499),
                'FSytj': function (_0x2139ec) {
                    return _0x2139ec();
                },
                'ZWlMq': function (_0x519710, _0x319f98) {
                    return _0x519710 == _0x319f98;
                },
                'iQNUP': function (_0x47da33, _0x262e5d, _0x5a38ea) {
                    return _0x47da33(_0x262e5d, _0x5a38ea);
                }
            };
        if (document[_0x11dfe7(0x652)](NITEFALL_CUSTOM_CSS_ID))
            return;
        var _0x32f482 = document[_0x11dfe7(0x534)](_0x136301[_0x11dfe7(0x646)]), _0x13fc38 = _0x136301[_0x11dfe7(0x274)](getCustomCss, _0x136301['xBYrW'](getHost));
        _0x13fc38 = _0x13fc38['replaceAll'](_0x136301[_0x11dfe7(0x5e4)], _0x136301[_0x11dfe7(0x30d)](getPageColor)['rgbString']()), _0x13fc38 = _0x13fc38['replaceAll'](_0x136301[_0x11dfe7(0x3d3)], _0x136301[_0x11dfe7(0x55b)](getPageSubColor)['rgbString']()), _0x32f482[_0x11dfe7(0x2ea)] = _0x13fc38, _0x32f482[_0x11dfe7(0x49a)]('id', NITEFALL_CUSTOM_CSS_ID);
        if (_0x136301[_0x11dfe7(0x5bd)](document[_0x11dfe7(0x2d5)][_0x11dfe7(0x318)], _0x11dfe7(0x421))) {
            let _0x4b48eb = /mobile|phone/i[_0x11dfe7(0x1ea)](navigator[_0x11dfe7(0x348)]);
            _0x4b48eb && (_0x32f482['setAttribute'](_0x11dfe7(0x18e), null), _0x136301[_0x11dfe7(0x5c9)](setTimeout, () => {
                var _0x5dea68 = _0x11dfe7;
                document[_0x5dea68(0x189)]['setAttribute'](_0x136301[_0x5dea68(0x1d3)], _0x136301[_0x5dea68(0x272)]);
            }, 0x514));
        }
        if (document[_0x11dfe7(0x46b)])
            document['head'][_0x11dfe7(0x4a7)](_0x32f482);
        else
            document[_0x11dfe7(0x189)][_0x11dfe7(0x4a7)](_0x32f482);
    }, removeStyleWithId = _0x50a2a4 => {
        var _0x5af235 = _0x4a728d, _0x5632bb = document[_0x5af235(0x652)](_0x50a2a4);
        _0x5632bb && _0x5632bb[_0x5af235(0x688)][_0x5af235(0x541)](_0x5632bb);
    }, removeDarkCss = () => {
        var _0x566e95 = _0x4a728d, _0x4e1bff = {
                'wYhsR': _0x566e95(0x245),
                'vjgGr': _0x566e95(0x630),
                'UFmZY': _0x566e95(0x6a3),
                'ZAehr': function (_0x3b51c9, _0x185647) {
                    return _0x3b51c9(_0x185647);
                },
                'Fmxuf': _0x566e95(0x1b8),
                'jGUdM': function (_0x1aa7ab, _0x4a9746, _0x63567e) {
                    return _0x1aa7ab(_0x4a9746, _0x63567e);
                },
                'VfnZy': function (_0x3ec95e, _0x644bd7) {
                    return _0x3ec95e(_0x644bd7);
                },
                'adFTH': _0x566e95(0x54a),
                'bWsUq': 'disableTemporarily'
            }, _0x7d793b = _0x4e1bff[_0x566e95(0x56d)][_0x566e95(0x5e1)]('|'), _0x53f1b4 = 0x0;
        while (!![]) {
            switch (_0x7d793b[_0x53f1b4++]) {
            case '0':
                document[_0x566e95(0x189)][_0x566e95(0x52f)](_0x4e1bff['vjgGr']);
                continue;
            case '1':
                removeStartWorkAround();
                continue;
            case '2':
                console[_0x566e95(0x65f)](_0x4e1bff[_0x566e95(0x21a)]);
                continue;
            case '3':
                _0x4e1bff[_0x566e95(0x59a)](removeStyleWithId, NITEFALL_CUSTOM_CSS_ID);
                continue;
            case '4':
                _0x4e1bff[_0x566e95(0x59a)](removeStyleWithId, _0x4e1bff[_0x566e95(0x4ea)]);
                continue;
            case '5':
                _0x4e1bff['jGUdM'](processElement, document[_0x566e95(0x50c)], ![]);
                continue;
            case '6':
                _0x4e1bff[_0x566e95(0x217)](removeStyleWithId, _0x4e1bff['adFTH']);
                continue;
            case '7':
                if (window == window[_0x566e95(0x668)]) {
                    var _0x22a407 = document['getElementsByTagName'](_0x566e95(0x390));
                    for (var _0x257043 of _0x22a407) {
                        _0x257043[_0x566e95(0x549)][_0x566e95(0x2c5)](_0x4e1bff['bWsUq'], '*');
                    }
                }
                continue;
            }
            break;
        }
    }, findAndTagSvgs = _0xd24e3d => {
        var _0x4248a9 = _0x4a728d, _0x13d03b = {
                'gzztL': _0x4248a9(0x690),
                'kIBTF': _0x4248a9(0x599),
                'djMYd': 'img[src^=\x22data:image/svg+xml\x22]',
                'GtwSe': _0x4248a9(0x58a)
            }, _0x503df9 = _0x13d03b[_0x4248a9(0x64c)]['split']('|'), _0x4d061a = 0x0;
        while (!![]) {
            switch (_0x503df9[_0x4d061a++]) {
            case '0':
                Array[_0x4248a9(0x612)][_0x4248a9(0x190)][_0x4248a9(0x2e4)](_0xd24e3d['querySelectorAll'](_0x13d03b[_0x4248a9(0x43e)]), detectElementWithBackgroundImages);
                continue;
            case '1':
                if (!_0xd24e3d[_0x4248a9(0x262)])
                    return;
                continue;
            case '2':
                _0xd24e3d[_0x4248a9(0x262)](_0x13d03b[_0x4248a9(0x5fd)])['forEach'](_0x5c3cf9 => classifySVGAsDark(_0x5c3cf9, _0x5c3cf9[_0x4248a9(0x691)]));
                continue;
            case '3':
                _0xd24e3d[_0x4248a9(0x262)](_0x13d03b['GtwSe'])[_0x4248a9(0x190)](_0xffdae1 => classifySVGAsDark(_0xffdae1, _0xffdae1['src']));
                continue;
            case '4':
                _0xd24e3d[_0x4248a9(0x262)](_0x4248a9(0x65d))[_0x4248a9(0x190)](_0x30b0ad => classifySVGAsDark(_0x30b0ad, _0x30b0ad[_0x4248a9(0x5fb)]));
                continue;
            }
            break;
        }
    }, removeAllCss = () => {
        var _0x4e968b = _0x4a728d, _0x10c976 = {
                'ZVKLN': _0x4e968b(0x3e6),
                'kBccF': function (_0x443b22) {
                    return _0x443b22();
                },
                'wESrk': 'nitefall_image_dim_style',
                'PHFMY': function (_0x1a7859) {
                    return _0x1a7859();
                }
            }, _0x4952e8 = _0x10c976[_0x4e968b(0x3bc)][_0x4e968b(0x5e1)]('|'), _0x10ad71 = 0x0;
        while (!![]) {
            switch (_0x4952e8[_0x10ad71++]) {
            case '0':
                _0x10c976[_0x4e968b(0x5c3)](removeInvertedPngStyle);
                continue;
            case '1':
                removeStyleWithId(_0x10c976[_0x4e968b(0x457)]);
                continue;
            case '2':
                if (mutationObserver)
                    mutationObserver['disconnect']();
                continue;
            case '3':
                _0x10c976[_0x4e968b(0x5c3)](removeDarkMapCss);
                continue;
            case '4':
                _0x10c976['kBccF'](removeDarkCss);
                continue;
            case '5':
                _0x10c976[_0x4e968b(0x3b3)](removeStartWorkAround);
                continue;
            }
            break;
        }
    }, isEmailInDarkMode = () => {
        var _0x4c16d1 = _0x4a728d, _0x1663a3 = {
                'rxxbl': function (_0x5d402b) {
                    return _0x5d402b();
                },
                'vjGEH': 'light',
                'GKCen': _0x4c16d1(0x27a),
                'RGHtY': 'dark',
                'GWwGw': _0x4c16d1(0x302),
                'vOWpj': function (_0x39e3f8, _0x99fc26) {
                    return _0x39e3f8 < _0x99fc26;
                },
                'QcZRR': function (_0x53078d, _0x333edd) {
                    return _0x53078d > _0x333edd;
                },
                'EFTiW': function (_0x102e52, _0x58250d) {
                    return _0x102e52 > _0x58250d;
                },
                'wDeRT': _0x4c16d1(0x4d2),
                'LLwDV': function (_0x2fc0ee, _0x282aec) {
                    return _0x2fc0ee !== _0x282aec;
                },
                'NWuTL': _0x4c16d1(0x187),
                'wIZFu': _0x4c16d1(0x699),
                'RGeiU': _0x4c16d1(0x68a)
            }, _0x503559 = ![], _0xb7eaf4 = !![], _0x5d352b = _0x1663a3[_0x4c16d1(0x462)](maillApp_declaredColorSchemes);
        if (_0x5d352b)
            _0xb7eaf4 = ![], (_0x5d352b['includes'](_0x1663a3[_0x4c16d1(0x5bb)]) || _0x5d352b[_0x4c16d1(0x153)](_0x1663a3['GKCen'])) && !_0x5d352b[_0x4c16d1(0x153)](_0x1663a3[_0x4c16d1(0x4cd)]) && (_0x503559 = !![]);
        else {
            var _0x1cfbbe = document[_0x4c16d1(0x50c)]['querySelectorAll'](_0x1663a3['GWwGw']);
            for (i = 0x0; _0x1663a3[_0x4c16d1(0x54e)](i, _0x1cfbbe['length']); i++) {
                var _0x44ba4f = _0x1cfbbe[i];
                if (_0x44ba4f['src'][_0x4c16d1(0x363)](_0x4c16d1(0x1b4)) && (_0x1663a3[_0x4c16d1(0x2a4)](_0x44ba4f[_0x4c16d1(0x539)], 0x1) || _0x1663a3[_0x4c16d1(0x429)](_0x44ba4f['height'], 0x1)) && !_0x44ba4f['className'][_0x4c16d1(0x363)](_0x1663a3['wDeRT'])) {
                    _0x503559 = !![];
                    break;
                }
            }
            var _0x49219a = window['getComputedStyle'](document[_0x4c16d1(0x50c)]);
            _0x1663a3[_0x4c16d1(0x4ef)](_0x49219a[_0x4c16d1(0x5a3)], _0x1663a3[_0x4c16d1(0x1da)]) && (_0x503559 = !![]);
        }
        var _0x4fb89f;
        if (_0x503559)
            _0x4fb89f = _0x1663a3[_0x4c16d1(0x5d3)];
        else
            _0xb7eaf4 && (_0x4fb89f = _0x1663a3[_0x4c16d1(0x623)]);
        return _0x4fb89f == _0x1663a3[_0x4c16d1(0x623)];
    }, maillApp_declaredColorSchemes = () => {
        var _0x1adde8 = _0x4a728d, _0x4ea6d8 = {
                'hrgAy': _0x1adde8(0x16f),
                'nojZa': function (_0x2dd748, _0x24b0b5) {
                    return _0x2dd748 !== _0x24b0b5;
                },
                'BAqhY': _0x1adde8(0x3a1),
                'nxuzn': function (_0x5b6938, _0x155dd1) {
                    return _0x5b6938 - _0x155dd1;
                }
            };
        document[_0x1adde8(0x189)][_0x1adde8(0x371)][_0x1adde8(0x53d)](_0x4ea6d8[_0x1adde8(0x27e)]);
        var _0x1c880a = window[_0x1adde8(0x5b8)](document['documentElement'])['colorScheme'];
        if (_0x1c880a && _0x4ea6d8[_0x1adde8(0x69a)](_0x1c880a, 'auto')) {
            let _0x47474c = _0x1c880a[_0x1adde8(0x5e1)](/\s+/);
            if (_0x47474c && _0x47474c[_0x1adde8(0x1d9)])
                return document[_0x1adde8(0x189)][_0x1adde8(0x371)]['remove'](_0x4ea6d8[_0x1adde8(0x27e)]), _0x47474c;
        }
        document[_0x1adde8(0x189)][_0x1adde8(0x371)]['remove'](_0x4ea6d8['hrgAy']);
        var _0x56f2a4 = document[_0x1adde8(0x262)](_0x4ea6d8[_0x1adde8(0x2b7)]);
        if (!_0x56f2a4)
            _0x56f2a4 = document[_0x1adde8(0x262)]('meta[name=\x27supported-color-schemes\x27]');
        var _0x28b741 = _0x56f2a4 ? _0x56f2a4[_0x4ea6d8['nxuzn'](_0x56f2a4['length'], 0x1)] : null;
        if (_0x28b741 && _0x28b741[_0x1adde8(0x327)]) {
            let _0x2a256f = _0x28b741[_0x1adde8(0x327)]['toLowerCase']()[_0x1adde8(0x5e1)](/\s+/);
            if (_0x2a256f && _0x2a256f[_0x1adde8(0x1d9)])
                return _0x2a256f;
        }
        return null;
    }, onPageLoadedForNitefall = () => {
        var _0xfaa5ce = _0x4a728d, _0x34c9da = {
                'DcXis': 'investor.apple.com',
                'fZfCt': function (_0x541c60) {
                    return _0x541c60();
                },
                'EoxpD': 'com.apple.email.maild',
                'LGjTs': function (_0x304cf7) {
                    return _0x304cf7();
                },
                'wKcoL': function (_0x5f43a5, _0x86592d) {
                    return _0x5f43a5(_0x86592d);
                },
                'BiiMB': _0xfaa5ce(0x54a),
                'cPwfY': _0xfaa5ce(0x2e5),
                'WvKeM': 'nitefall_processed',
                'DINTK': function (_0x5a16f2, _0xafc620) {
                    return _0x5a16f2 > _0xafc620;
                },
                'qnEjG': _0xfaa5ce(0x6a0),
                'ojGnQ': '12px',
                'UyOUy': function (_0x7b5922, _0x45794e) {
                    return _0x7b5922(_0x45794e);
                },
                'ssPjW': function (_0x123267) {
                    return _0x123267();
                },
                'NkuGW': function (_0x4651db, _0x4d1658) {
                    return _0x4651db < _0x4d1658;
                },
                'rsJrd': function (_0x3664b6, _0x311fb6) {
                    return _0x3664b6 != _0x311fb6;
                },
                'BYRVQ': _0xfaa5ce(0x630),
                'yCaBV': function (_0x318f68) {
                    return _0x318f68();
                },
                'QcVrq': function (_0x3221ff) {
                    return _0x3221ff();
                },
                'EiWtB': function (_0x2c9d0e) {
                    return _0x2c9d0e();
                }
            };
        if (!globalSettings)
            return;
        _0x34c9da[_0xfaa5ce(0x69e)](removeStartWorkAround);
        if (!document['body'])
            return;
        if (document[_0xfaa5ce(0x2d5)]['href'][_0xfaa5ce(0x153)](_0x34c9da['EoxpD']) && _0x34c9da[_0xfaa5ce(0x32d)](isEmailInDarkMode))
            return;
        if (_0x34c9da[_0xfaa5ce(0x453)](hasTrialExpired, globalSettings)) {
            let _0x397e73 = _0x34c9da[_0xfaa5ce(0x5a8)];
            if (!document[_0xfaa5ce(0x652)](_0x397e73) && window == window[_0xfaa5ce(0x668)]) {
                var _0x4c1621 = document[_0xfaa5ce(0x534)](_0x34c9da['cPwfY']);
                _0x4c1621['id'] = _0x397e73, _0x4c1621[_0xfaa5ce(0x454)] = _0x34c9da[_0xfaa5ce(0x228)];
                let _0x37c0e3 = _0x34c9da[_0xfaa5ce(0x43c)](screen[_0xfaa5ce(0x539)], 0x1f4) ? _0x34c9da[_0xfaa5ce(0x545)] : _0x34c9da[_0xfaa5ce(0x658)];
                _0x4c1621[_0xfaa5ce(0x4ce)] = '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(218,\x2062,\x2082);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20position:\x20absolute;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20top:\x200px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20z-index:\x201000001;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20width:\x20100%;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-align:\x20center;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-weight:\x20bold;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x202px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-family:\x20Helvetica,Arial,sans-serif;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20line-height:\x2017px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-size:\x20' + _0x37c0e3 + ';\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20', _0x4c1621[_0xfaa5ce(0x15f)] = _0xfaa5ce(0x14a), document[_0xfaa5ce(0x50c)][_0xfaa5ce(0x229)](_0x4c1621, document[_0xfaa5ce(0x50c)]['childNodes'][0x0]);
            }
            return;
        }
        _0x34c9da[_0xfaa5ce(0x675)](findAndTagSvgs, document);
        let _0x366e67 = globalSettings[_0x34c9da[_0xfaa5ce(0x355)](getHost)];
        if (_0x34c9da['NkuGW'](_0x366e67[_0xfaa5ce(0x5a9)], 0x1))
            dimImages(_0x366e67[_0xfaa5ce(0x5a9)]);
        if (_0x366e67[_0xfaa5ce(0x234)])
            _0x34c9da[_0xfaa5ce(0x355)](invertPng);
        if (_0x366e67[_0xfaa5ce(0x30e)]) {
            var _0x55e074 = !![];
            let _0x57fc00 = _0x34c9da[_0xfaa5ce(0x2fa)](window['top'], window);
            if (_0x57fc00) {
                let _0xc6662f = _0x34c9da[_0xfaa5ce(0x2fa)](window[_0xfaa5ce(0x2d5)], window[_0xfaa5ce(0x648)][_0xfaa5ce(0x2d5)]) ? document[_0xfaa5ce(0x248)] : document[_0xfaa5ce(0x2d5)][_0xfaa5ce(0x656)];
                if (_0xc6662f) {
                    let _0x28dee2 = new URL(_0xc6662f)[_0xfaa5ce(0x523)];
                    if (_0x28dee2) {
                        let _0x5cb594 = globalSettings[_0x28dee2];
                        _0x5cb594 && (_0x55e074 = _0x5cb594[_0xfaa5ce(0x30e)]);
                    }
                }
            }
            _0x55e074 && (document[_0xfaa5ce(0x189)][_0xfaa5ce(0x49a)](_0x34c9da[_0xfaa5ce(0x1ad)], 'active'), _0x34c9da[_0xfaa5ce(0x355)](addCustomDarkCss), _0x34c9da[_0xfaa5ce(0x4bf)](setDarkToolbar), queueMicrotask(() => {
                var _0x19914e = _0xfaa5ce;
                processElement(document['body'], !![]), mutationObserver = new MutationObserver(handleMutations), document[_0x19914e(0x2d5)][_0x19914e(0x318)] != _0x34c9da['DcXis'] && mutationObserver[_0x19914e(0x209)](document[_0x19914e(0x50c)], {
                    'childList': !![],
                    'subtree': !![]
                }), iterateElementsWithShadowHost(document['documentElement'], _0x5e7a27 => {
                    var _0xaa5667 = _0x19914e;
                    if (_0x5e7a27 && _0x5e7a27['shadowRoot']) {
                        let _0x4ff0eb = new MutationObserver(handleMutations);
                        _0x4ff0eb[_0xaa5667(0x209)](_0x5e7a27['shadowRoot'], {
                            'childList': !![],
                            'subtree': !![]
                        });
                    }
                });
            }));
        }
        globalSettings[_0xfaa5ce(0x4f2)] && _0x34c9da[_0xfaa5ce(0x215)](invertPdf), globalSettings[_0xfaa5ce(0x1a9)] && _0x34c9da['EiWtB'](addDarkMapsCss);
    }, setDarkToolbar = () => {
        var _0x49a5b6 = _0x4a728d, _0x3df85d = {
                'CyvBo': _0x49a5b6(0x1fc),
                'kDslt': function (_0x293720) {
                    return _0x293720();
                },
                'LcHJN': 'media',
                'bzctY': _0x49a5b6(0x21f),
                'tepmO': _0x49a5b6(0x4dd),
                'ftjqS': _0x49a5b6(0x135),
                'wZVng': _0x49a5b6(0x5ea),
                'chctg': 'content'
            };
        if (window[_0x49a5b6(0x668)] != window)
            return;
        if (!document[_0x49a5b6(0x46b)])
            return;
        let _0x59d97e = document[_0x49a5b6(0x628)](_0x3df85d[_0x49a5b6(0x66c)]), _0xbedebe = _0x3df85d[_0x49a5b6(0x48b)](getPageColor)[_0x49a5b6(0x68c)]();
        if (_0x59d97e) {
            _0x59d97e[_0x49a5b6(0x49a)](_0x3df85d[_0x49a5b6(0x543)], _0x49a5b6(0x5ea)), _0x59d97e[_0x49a5b6(0x49a)](_0x49a5b6(0x327), _0xbedebe);
            return;
        }
        _0x59d97e = document[_0x49a5b6(0x534)](_0x3df85d[_0x49a5b6(0x460)]), _0x59d97e['setAttribute'](_0x3df85d[_0x49a5b6(0x394)], _0x3df85d[_0x49a5b6(0x4da)]), _0x59d97e[_0x49a5b6(0x49a)](_0x3df85d['LcHJN'], _0x3df85d[_0x49a5b6(0x2cf)]), _0x59d97e[_0x49a5b6(0x49a)](_0x3df85d[_0x49a5b6(0x24f)], _0xbedebe), document[_0x49a5b6(0x46b)][_0x49a5b6(0x4a7)](_0x59d97e);
    }, dimImages = _0x12260d => {
        var _0x4bf142 = _0x4a728d, _0x11538b = {
                'kZZEm': _0x4bf142(0x4be),
                'fCEhi': function (_0x326d05, _0x4b673b) {
                    return _0x326d05 == _0x4b673b;
                },
                'oaczO': function (_0x28c465, _0x22378c) {
                    return _0x28c465(_0x22378c);
                },
                'TchWL': 'style'
            };
        let _0x34736d = _0x11538b['kZZEm'];
        var _0x381b0a = document[_0x4bf142(0x652)](_0x34736d);
        if (_0x381b0a && _0x11538b[_0x4bf142(0x55c)](_0x12260d, 0x1))
            return _0x11538b['oaczO'](removeStyleWithId, _0x34736d);
        if (!_0x381b0a)
            _0x381b0a = document['createElement'](_0x11538b[_0x4bf142(0x31e)]);
        _0x381b0a['id'] = _0x34736d, _0x381b0a[_0x4bf142(0x2ea)] = _0x4bf142(0x27f) + _0x12260d + ')\x20!important;\x20}';
        if (document[_0x4bf142(0x46b)])
            document['head'][_0x4bf142(0x4a7)](_0x381b0a);
        else
            document[_0x4bf142(0x189)][_0x4bf142(0x4a7)](_0x381b0a);
    }, addDarkMapsCss = () => {
        var _0x1b2fc1 = _0x4a728d, _0x3cdfb5 = { 'NVUxx': _0x1b2fc1(0x477) };
        let _0x4e0c23 = _0x3cdfb5[_0x1b2fc1(0x4bb)];
        var _0x21aeda = document['getElementById'](_0x4e0c23);
        if (_0x21aeda)
            return;
        _0x21aeda = document[_0x1b2fc1(0x534)]('style'), _0x21aeda['id'] = _0x4e0c23, _0x21aeda['textContent'] = _0x1b2fc1(0x266);
        if (document[_0x1b2fc1(0x46b)])
            document[_0x1b2fc1(0x46b)][_0x1b2fc1(0x4a7)](_0x21aeda);
        else
            document[_0x1b2fc1(0x189)]['appendChild'](_0x21aeda);
    }, removeDarkMapCss = () => {
        var _0x19b538 = _0x4a728d, _0x63b394 = {
                'DQPjb': function (_0x318bb3, _0x4b6a26) {
                    return _0x318bb3(_0x4b6a26);
                },
                'THtxn': _0x19b538(0x477)
            };
        _0x63b394[_0x19b538(0x445)](removeStyleWithId, _0x63b394[_0x19b538(0x570)]);
    }, invertPdf = () => {
        var _0x4e0e05 = _0x4a728d, _0xccffa2 = {
                'qdvUn': _0x4e0e05(0x3dc),
                'unsus': 'style'
            };
        let _0x442f6f = _0xccffa2[_0x4e0e05(0x2c6)];
        var _0x39793f = document[_0x4e0e05(0x652)](_0x442f6f);
        if (_0x39793f)
            return;
        _0x39793f = document['createElement'](_0xccffa2[_0x4e0e05(0x676)]), _0x39793f['id'] = _0x442f6f, _0x39793f[_0x4e0e05(0x2ea)] = _0x4e0e05(0x5e8);
        if (document['head'])
            document[_0x4e0e05(0x46b)]['appendChild'](_0x39793f);
        else
            document[_0x4e0e05(0x189)][_0x4e0e05(0x4a7)](_0x39793f);
    }, removeInvertedPdfStyle = () => {
        var _0x4bef7f = _0x4a728d, _0x8e196f = {
                'ejXRo': function (_0x5ce898, _0x2877d9) {
                    return _0x5ce898(_0x2877d9);
                },
                'DHOBh': _0x4bef7f(0x3dc)
            };
        _0x8e196f[_0x4bef7f(0x2e7)](removeStyleWithId, _0x8e196f[_0x4bef7f(0x4d5)]);
    }, invertPng = () => {
        var _0x1a4e71 = _0x4a728d, _0x414e4a = {
                'UEWud': _0x1a4e71(0x315),
                'BIbkq': _0x1a4e71(0x629),
                'nYgMH': _0x1a4e71(0x4ce)
            };
        console[_0x1a4e71(0x65f)](_0x414e4a[_0x1a4e71(0x5f6)], document[_0x1a4e71(0x2d5)][_0x1a4e71(0x318)]);
        let _0x52f2f9 = _0x414e4a[_0x1a4e71(0x1bc)];
        var _0x424ee8 = document[_0x1a4e71(0x652)](_0x52f2f9);
        if (_0x424ee8)
            return;
        _0x424ee8 = document[_0x1a4e71(0x534)](_0x414e4a[_0x1a4e71(0x664)]), _0x424ee8['id'] = _0x52f2f9, _0x424ee8[_0x1a4e71(0x2ea)] = '\x20*[nitefall_imageType=\x22png\x22],\x20img[src$=\x22.png\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20hue-rotate(180deg)\x20invert(100%)\x20!important;\x0a\x20\x20\x20\x20}';
        if (document[_0x1a4e71(0x46b)])
            document[_0x1a4e71(0x46b)][_0x1a4e71(0x4a7)](_0x424ee8);
        else
            document['documentElement'][_0x1a4e71(0x4a7)](_0x424ee8);
    }, removeInvertedPngStyle = () => {
        var _0x3dded4 = _0x4a728d, _0x2cd2ce = {
                'AqRCW': function (_0x26d4eb, _0x3a3b40) {
                    return _0x26d4eb(_0x3a3b40);
                },
                'nHQzU': 'nitefall_image_invert_png_style'
            };
        _0x2cd2ce[_0x3dded4(0x425)](removeStyleWithId, _0x2cd2ce[_0x3dded4(0x1e4)]);
    }, containsAny = (_0x4c07b, _0x22f2b0) => {
        var _0x5e7d88 = _0x4a728d, _0x583f36 = {
                'jKODm': function (_0x5f1f9e, _0x1b25d4) {
                    return _0x5f1f9e > _0x1b25d4;
                }
            };
        return _0x583f36[_0x5e7d88(0x4b7)](_0x22f2b0[_0x5e7d88(0x15c)](_0x460e6a => _0x4c07b[_0x5e7d88(0x50b)]()[_0x5e7d88(0x153)](_0x460e6a[_0x5e7d88(0x50b)]()))[_0x5e7d88(0x1d9)], 0x0);
    }, extractSVGColors = (_0xc6fe25, _0x5a1a4d, _0x207922) => {
        var _0x4bca1c = _0x4a728d, _0x3fe274 = {
                'jipPy': function (_0x4e6669, _0x148a48) {
                    return _0x4e6669(_0x148a48);
                },
                'WSeLd': function (_0x14bc41, _0x1679a2) {
                    return _0x14bc41 > _0x1679a2;
                },
                'XpTAI': function (_0x24154f, _0x14c744) {
                    return _0x24154f(_0x14c744);
                },
                'UgyjJ': function (_0x3455a4, _0x5641a2) {
                    return _0x3455a4 instanceof _0x5641a2;
                },
                'WOhsR': function (_0x3bfc97, _0x564a1a) {
                    return _0x3bfc97(_0x564a1a);
                },
                'GjLkx': function (_0x3ffb0e, _0x2e3af2) {
                    return _0x3ffb0e(_0x2e3af2);
                },
                'uKoit': _0x4bca1c(0x342),
                'LqTih': function (_0x4647c4, _0xc253c3) {
                    return _0x4647c4(_0xc253c3);
                }
            };
        if (!_0xc6fe25)
            return _0x3fe274[_0x4bca1c(0x243)](_0x207922, []);
        getSVGColors(_0xc6fe25, { 'flat': !![] })['then'](_0x4a3a02 => {
            var _0x2f51af = _0x4bca1c, _0x364693 = {
                    'rTvMB': function (_0x33694e, _0x59ccf1) {
                        var _0x57787b = _0x4c3d;
                        return _0x3fe274[_0x57787b(0x3b2)](_0x33694e, _0x59ccf1);
                    }
                };
            if (_0x3fe274[_0x2f51af(0x4e2)](_0x4a3a02[_0x2f51af(0x1d9)], 0x0)) {
                var _0x3035aa = _0x4a3a02['filter'](_0x455674 => _0x455674 != 'none')[_0x2f51af(0x331)](_0x4e0a64 => {
                    var _0x18b9c1 = _0x2f51af;
                    if (_0x4e0a64[_0x18b9c1(0x6a1)]('#') == 0x0)
                        return convertToHex6Digits(_0x4e0a64)['toUpperCase']();
                    else
                        return _0x4e0a64['includes']('rgb') ? _0x364693[_0x18b9c1(0x40a)](rgbToHex, _0x4e0a64) : namedColorToHex(_0x4e0a64);
                });
                _0x3fe274[_0x2f51af(0x604)](_0x207922, _0x3035aa);
            } else {
                if (_0x3fe274[_0x2f51af(0x3d4)](_0x5a1a4d, SVGElement)) {
                    let _0x1fe560 = _0x3fe274['WOhsR'](getComputedStyle, _0x5a1a4d)[_0x2f51af(0x17b)];
                    if (_0x1fe560) {
                        if (_0x1fe560[_0x2f51af(0x153)](_0x2f51af(0x4eb)))
                            return _0x207922([_0x3fe274[_0x2f51af(0x50a)](rgbToHex, _0x1fe560)['toUpperCase']()]);
                        else
                            return _0x207922([_0x1fe560]);
                    }
                }
                return _0x207922([_0x2f51af(0x3eb)]);
            }
        })[_0x4bca1c(0x45c)](_0x226b2f => {
            var _0x45b0cc = _0x4bca1c;
            console[_0x45b0cc(0x65f)](_0x3fe274[_0x45b0cc(0x304)], _0x226b2f[_0x45b0cc(0x58c)]), _0x3fe274[_0x45b0cc(0x243)](_0x207922, []);
        });
    }, classifySVGAsDark = (_0x195cef, _0x21addb) => {
        var _0x17e489 = _0x4a728d, _0x202f72 = {
                'sjfaX': function (_0x290287, _0x2704ca) {
                    return _0x290287 == _0x2704ca;
                },
                'ofsxQ': function (_0x1bf58c, _0x112ee6) {
                    return _0x1bf58c(_0x112ee6);
                },
                'LkDZy': _0x17e489(0x65d),
                'XPBNR': function (_0x2c062a, _0x414cc9) {
                    return _0x2c062a != _0x414cc9;
                },
                'GaJsp': _0x17e489(0x2b0),
                'JdsVt': _0x17e489(0x13f),
                'QfMFp': function (_0x3a0808, _0x4de80e) {
                    return _0x3a0808 > _0x4de80e;
                },
                'fGpMt': _0x17e489(0x223),
                'PmsEv': function (_0x13f7b3, _0x2b5e34) {
                    return _0x13f7b3 instanceof _0x2b5e34;
                }
            };
        if (_0x202f72[_0x17e489(0x369)](isElementBlacklisted, _0x195cef))
            return;
        if (_0x202f72[_0x17e489(0x166)](typeof _0x21addb, _0x202f72['GaJsp']))
            _0x21addb = null;
        if (_0x21addb) {
            if (_0x21addb[_0x17e489(0x363)](_0x202f72['JdsVt'])) {
                var _0x249fa7 = _0x21addb[_0x17e489(0x6a1)](_0x17e489(0x223));
                if (_0x202f72[_0x17e489(0x5ee)](_0x249fa7, -0x1))
                    _0x21addb = _0x21addb[_0x17e489(0x21d)](_0x249fa7);
            }
            if (_0x21addb['startsWith'](_0x202f72[_0x17e489(0x5e5)])) {
                var _0x249fa7 = _0x21addb[_0x17e489(0x6a1)](_0x202f72[_0x17e489(0x5e5)]);
                if (_0x202f72[_0x17e489(0x5ee)](_0x249fa7, -0x1))
                    _0x21addb = _0x21addb['substr'](_0x249fa7);
                _0x21addb = _0x21addb[_0x17e489(0x58b)](/\((.*?)\)/)[0x1][_0x17e489(0x609)](/('|")/g, '');
            }
        }
        let _0x53d915 = _0x202f72[_0x17e489(0x381)](_0x195cef, SVGElement);
        extractSVGColors(_0x21addb, _0x53d915 ? _0x195cef : null, _0x31cf2e => {
            var _0x1feb81 = _0x17e489;
            if (_0x202f72[_0x1feb81(0x480)](_0x31cf2e[_0x1feb81(0x1d9)], 0x1)) {
                if (!_0x202f72[_0x1feb81(0x369)](NFColorFromHexString, _0x31cf2e[0x0])['isLight']())
                    _0x195cef['setAttribute'](_0x1feb81(0x2ec), _0x202f72[_0x1feb81(0x4af)]);
            }
        });
    }, detectElementWithBackgroundImages = _0x28ef70 => {
        var _0x53412d = _0x4a728d, _0xba4c50 = {
                'zzumF': _0x53412d(0x553),
                'sJTuX': function (_0x5c089a, _0x45a8cf) {
                    return _0x5c089a == _0x45a8cf;
                },
                'sfDVl': _0x53412d(0x290),
                'qrpkI': 'none',
                'jhnsd': function (_0x536d78, _0x2b90a7) {
                    return _0x536d78 != _0x2b90a7;
                },
                'xIFnE': function (_0x1661a1, _0x2c2484, _0x5519cd) {
                    return _0x1661a1(_0x2c2484, _0x5519cd);
                },
                'vJBis': _0x53412d(0x54b),
                'iLaOw': _0x53412d(0x2da),
                'SxkHK': _0x53412d(0x2c4),
                'QdQIy': function (_0x4b3e4d, _0x444652, _0x34aa9f) {
                    return _0x4b3e4d(_0x444652, _0x34aa9f);
                },
                'OROor': _0x53412d(0x4aa),
                'iYUsW': _0x53412d(0x506),
                'uzbPb': _0x53412d(0x62e),
                'veSxE': function (_0x57b4e8, _0x129a13, _0x4e76ee) {
                    return _0x57b4e8(_0x129a13, _0x4e76ee);
                },
                'HKrft': _0x53412d(0x42d),
                'TvJZh': _0x53412d(0x4d3),
                'TPjxy': '.JPEG',
                'AmrUO': _0x53412d(0x2ee),
                'YHZuB': _0x53412d(0x303),
                'GQmVt': _0x53412d(0x45e),
                'vsYjM': _0x53412d(0x409),
                'cOLoA': _0x53412d(0x43b),
                'HPawV': _0x53412d(0x65c),
                'DQqMs': _0x53412d(0x2ec)
            }, _0x589429 = window[_0x53412d(0x5b8)](_0x28ef70)[_0xba4c50[_0x53412d(0x2b2)]];
        let _0x8e5ae9 = ![];
        if (_0xba4c50[_0x53412d(0x161)](_0x589429, 'none')) {
            _0x589429 = window[_0x53412d(0x5b8)](_0x28ef70, _0xba4c50[_0x53412d(0x263)])[_0xba4c50[_0x53412d(0x2b2)]];
            if (_0xba4c50[_0x53412d(0x161)](_0x589429, _0xba4c50['qrpkI']))
                _0x589429 = window[_0x53412d(0x5b8)](_0x28ef70, ':before')[_0xba4c50[_0x53412d(0x2b2)]];
            _0x8e5ae9 = _0xba4c50[_0x53412d(0x1f8)](_0x589429, _0xba4c50['qrpkI']);
        }
        if (_0x589429 == _0xba4c50[_0x53412d(0x3c7)])
            return;
        var _0x5516ec;
        if (_0xba4c50['xIFnE'](containsAny, _0x589429, [
                _0x53412d(0x4de),
                _0xba4c50[_0x53412d(0x5b4)],
                _0xba4c50[_0x53412d(0x4fe)]
            ]))
            _0x5516ec = _0xba4c50['SxkHK'];
        else {
            if (_0xba4c50['QdQIy'](containsAny, _0x589429, [
                    _0xba4c50[_0x53412d(0x373)],
                    _0xba4c50['iYUsW']
                ]))
                _0x5516ec = _0xba4c50[_0x53412d(0x615)];
            else {
                if (_0xba4c50[_0x53412d(0x211)](containsAny, _0x589429, [
                        _0x53412d(0x23f),
                        _0xba4c50[_0x53412d(0x524)],
                        _0x53412d(0x380),
                        _0xba4c50[_0x53412d(0x1f6)],
                        _0xba4c50[_0x53412d(0x578)]
                    ]))
                    _0x5516ec = 'jpg';
                else {
                    if (!_0x8e5ae9 && _0xba4c50[_0x53412d(0x211)](containsAny, _0x589429, [
                            _0xba4c50[_0x53412d(0x59e)],
                            _0xba4c50['YHZuB'],
                            _0xba4c50[_0x53412d(0x415)]
                        ]))
                        classifySVGAsDark(_0x28ef70, _0x589429);
                    else
                        _0xba4c50[_0x53412d(0x211)](containsAny, _0x589429, [
                            _0xba4c50[_0x53412d(0x148)],
                            _0xba4c50[_0x53412d(0x1bf)]
                        ]) && (_0x5516ec = _0xba4c50[_0x53412d(0x1be)]);
                }
            }
        }
        _0x5516ec ? _0x28ef70['setAttribute'](_0xba4c50['DQqMs'], _0x5516ec) : _0x28ef70[_0x53412d(0x52f)]('nitefall_imageType');
    }, DOMContentLoaded = () => {
        var _0x5168ec = _0x4a728d, _0x4a52bb = {
                'XUdXK': function (_0x537b9a) {
                    return _0x537b9a();
                },
                'eeCAf': _0x5168ec(0x43a)
            };
        if (hasProcessedPage)
            return;
        _0x4a52bb[_0x5168ec(0x40f)](onPageLoadedForNitefall), document['removeEventListener'](_0x4a52bb[_0x5168ec(0x4a9)], DOMContentLoaded), hasProcessedPage = !![];
    }, getExtensionSettings = _0x477b44 => {
        var _0x288c58 = _0x4a728d;
        getSettings(getHost())[_0x288c58(0x4b6)](_0x34da9d => {
            _0x477b44(_0x34da9d);
        });
    }, removeStartWorkAround = () => {
        var _0x179f09 = {
            'VicHZ': function (_0x104319, _0x193326) {
                return _0x104319(_0x193326);
            }
        };
        _0x179f09['VicHZ'](removeStyleWithId, NITEFALL_START_WORKAROUND_CSS_ID);
    }, isNitefallActive = () => {
        var _0x20cc38 = _0x4a728d, _0x4ac2f3 = { 'sAKjF': _0x20cc38(0x630) };
        if (!document[_0x20cc38(0x189)])
            return JSON[_0x20cc38(0x29c)]({ 'active': ![] });
        return JSON[_0x20cc38(0x29c)]({ 'active': document['documentElement']['hasAttribute'](_0x4ac2f3['sAKjF']) });
    }, isSystemDarkModeOn = () => {
        var _0x1b4dd7 = _0x4a728d, _0x160f78 = {
                'ntMjQ': _0x1b4dd7(0x3f1),
                'uImXT': _0x1b4dd7(0x5ea)
            };
        if (navigator[_0x1b4dd7(0x348)][_0x1b4dd7(0x153)]('Cydia/') && !navigator[_0x1b4dd7(0x348)]['includes'](_0x160f78[_0x1b4dd7(0x330)]))
            return !![];
        return window[_0x1b4dd7(0x557)](_0x160f78['uImXT'])[_0x1b4dd7(0x4dc)];
    }, getHost = () => {
        var _0x43a01f = _0x4a728d, _0x31e7f2 = {
                'gBdFE': _0x43a01f(0x18f),
                'PoPoA': _0x43a01f(0x4e8),
                'PeWaN': _0x43a01f(0x31d),
                'Ywmkj': _0x43a01f(0x5fa)
            };
        let _0x4a0038 = document['location'][_0x43a01f(0x656)][_0x43a01f(0x153)](_0x31e7f2['gBdFE']);
        if (_0x4a0038)
            return _0x31e7f2[_0x43a01f(0x198)];
        if (document[_0x43a01f(0x2d5)]['href'][_0x43a01f(0x153)](_0x43a01f(0x67f)))
            return _0x31e7f2[_0x43a01f(0x4a1)];
        let _0x35bd06 = !document[_0x43a01f(0x2d5)]['host'][_0x43a01f(0x1d9)] && document[_0x43a01f(0x628)](_0x31e7f2[_0x43a01f(0x5e2)]) != null;
        if (_0x35bd06)
            return _0x31e7f2[_0x43a01f(0x22d)];
        return document['location'][_0x43a01f(0x318)][_0x43a01f(0x5e1)](':')[0x0];
    }, initNitefall = () => {
        var _0x391652 = _0x4a728d, _0x574a79 = {
                'OLPdB': _0x391652(0x5ea),
                'GcBTX': function (_0x192076) {
                    return _0x192076();
                },
                'NMpFO': function (_0x5de5fb, _0x216d70) {
                    return _0x5de5fb == _0x216d70;
                },
                'SICDN': 'disableTemporarily',
                'YpHTw': function (_0x4d5dc8) {
                    return _0x4d5dc8();
                },
                'gcAys': _0x391652(0x39d),
                'dZJIh': function (_0x371e52) {
                    return _0x371e52();
                },
                'VVHVi': _0x391652(0x4f1),
                'mwsyw': function (_0x48d156, _0x40d5f0) {
                    return _0x48d156(_0x40d5f0);
                },
                'BQDmK': function (_0x57dbbf) {
                    return _0x57dbbf();
                },
                'HPbvw': function (_0x5cf76c) {
                    return _0x5cf76c();
                },
                'TWAzj': function (_0x4eaa83, _0x53ba65) {
                    return _0x4eaa83 != _0x53ba65;
                },
                'UsEEo': function (_0x29a457, _0x51d179) {
                    return _0x29a457 !== _0x51d179;
                },
                'xaZTO': 'loading',
                'lXvVN': _0x391652(0x43a),
                'sEHen': function (_0xf7ae27, _0x26c8c6) {
                    return _0xf7ae27(_0x26c8c6);
                }
            };
        try {
            _0x574a79[_0x391652(0x45d)](getExtensionSettings, _0x2b19a2 => {
                var _0x5ee6f7 = _0x391652, _0x18c159 = {
                        'IfINq': function (_0x4b7e13, _0x3249a1) {
                            var _0x2e5e39 = _0x4c3d;
                            return _0x574a79[_0x2e5e39(0x24d)](_0x4b7e13, _0x3249a1);
                        },
                        'TGrQw': _0x574a79[_0x5ee6f7(0x2a0)]
                    };
                globalSettings = _0x2b19a2, currentTheme = _0x2b19a2[_0x5ee6f7(0x5f1)];
                if (!_0x2b19a2['enabled']) {
                    _0x574a79['YpHTw'](removeStartWorkAround);
                    return;
                }
                for (styleSheet of document[_0x5ee6f7(0x2a9)]) {
                    var _0x27e298 = styleSheet['ownerNode']['id'];
                    if (_0x27e298 && _0x574a79[_0x5ee6f7(0x24d)](_0x27e298, NITEFALL_START_WORKAROUND_CSS_ID)) {
                        var _0x2122b7 = styleSheet['rules'][_0x5ee6f7(0x2d7)](0x0);
                        _0x2122b7 && _0x2122b7['style'][_0x5ee6f7(0x1cf)](_0x574a79['gcAys'], _0x574a79[_0x5ee6f7(0x1a2)](getPageColor)[_0x5ee6f7(0x59d)](), _0x574a79[_0x5ee6f7(0x645)]);
                    }
                }
                if (_0x574a79['mwsyw'](isAllowedToUseExtension, _0x2b19a2)) {
                    var _0xd43bae = window[_0x5ee6f7(0x557)]('(prefers-color-scheme:\x20dark)');
                    _0xd43bae[_0x5ee6f7(0x478)](_0x44f381 => {
                        var _0x2cf79f = _0x5ee6f7, _0x3dd100 = {
                                'vBiwf': _0x574a79[_0x2cf79f(0x464)],
                                'FsDEB': function (_0x366cad) {
                                    var _0x18b964 = _0x2cf79f;
                                    return _0x574a79[_0x18b964(0x1c4)](_0x366cad);
                                }
                            };
                        getExtensionSettings(_0x19cecf => {
                            var _0x3ae9af = _0x2cf79f, _0x1852cf = _0x19cecf[getHost()];
                            if (!_0x19cecf['enabled'] || !_0x1852cf['darkMode'])
                                return;
                            var _0x113c88 = window[_0x3ae9af(0x557)](_0x3dd100['vBiwf'])[_0x3ae9af(0x4dc)];
                            _0x113c88 ? _0x3dd100[_0x3ae9af(0x4f9)](onPageLoadedForNitefall) : removeAllCss();
                        });
                    });
                }
                var _0x1c65e2 = _0x574a79[_0x5ee6f7(0x620)](getHost), _0x3c99a5 = _0x2b19a2[_0x1c65e2];
                if (!_0x3c99a5) {
                    _0x574a79['BQDmK'](removeStartWorkAround);
                    return;
                }
                if (!_0x3c99a5[_0x5ee6f7(0x30e)]) {
                    removeStartWorkAround();
                    return;
                }
                if (!_0x574a79[_0x5ee6f7(0x620)](isSystemDarkModeOn)) {
                    _0x574a79['HPbvw'](removeStartWorkAround);
                    return;
                }
                _0x574a79[_0x5ee6f7(0x2aa)](window, window['top']) && window[_0x5ee6f7(0x173)](_0x5ee6f7(0x58c), _0x23430b => {
                    var _0x2b15ab = _0x5ee6f7;
                    if (_0x18c159[_0x2b15ab(0x2b8)](_0x23430b[_0x2b15ab(0x15d)], _0x18c159[_0x2b15ab(0x44e)]) && window[_0x2b15ab(0x630)])
                        window['nitefall'][_0x2b15ab(0x346)]();
                });
                if (window[_0x5ee6f7(0x630)]) {
                    _0x574a79['HPbvw'](removeStartWorkAround);
                    return;
                }
                _0x574a79[_0x5ee6f7(0x4e3)](document[_0x5ee6f7(0x598)], _0x574a79['xaZTO']) ? (onPageLoadedForNitefall(), hasProcessedPage = !![]) : document[_0x5ee6f7(0x173)](_0x574a79[_0x5ee6f7(0x5e0)], DOMContentLoaded), window['nitefall'] = {
                    'disableTemporarily': removeAllCss,
                    'dimImages': dimImages,
                    'invertPng': invertPng,
                    'isNitefallActive': isNitefallActive
                };
            });
        } catch (_0x41d044) {
            console[_0x391652(0x698)](_0x41d044);
        }
    };
let isMailComposePage = document[_0x4a728d(0x2d5)][_0x4a728d(0x656)][_0x4a728d(0x153)](_0x4a728d(0x3d9));
if (!isMailComposePage) {
    var isSystemInDarkMode = isSystemDarkModeOn();
    if (getHost() == _0x4a728d(0x3be) && document[_0x4a728d(0x189)]) {
        if (isSystemInDarkMode)
            document[_0x4a728d(0x189)][_0x4a728d(0x4ce)]['backgroundColor'] = getPageColor()['rgbString']();
    } else {
        if (document[_0x4a728d(0x46b)] || document[_0x4a728d(0x189)]) {
            var eYRaJj = _0x4a728d(0x2c9)[_0x4a728d(0x5e1)]('|'), YkzdBu = 0x0;
            while (!![]) {
                switch (eYRaJj[YkzdBu++]) {
                case '0':
                    var styleTag = document[_0x4a728d(0x534)](_0x4a728d(0x4ce));
                    continue;
                case '1':
                    styleTag[_0x4a728d(0x2ea)] = _0x4a728d(0x3da) + bgColor + '\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*when\x20pdf\x20is\x20loading\x20in\x20safari*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#annotationContainer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20' + bgColor + ';\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20white\x20left\x20gradient\x20when\x20page\x20is\x20loading\x20on\x20google.\x20apply\x20it\x20in\x20custom\x20css\x20is\x20too\x20late,\x20so\x20we\x20apply\x20it\x20here*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.cG5GOd,\x20.P1Ycoe{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#sDeBje\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*github\x20raw\x20content\x20is\x20not\x20triggering\x20on\x20DOM\x20content\x20loaded,\x20so\x20we\x20use\x20this\x20as\x20workaround\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body\x20>\x20pre\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20';
                    continue;
                case '2':
                    var bgColor = isSystemInDarkMode ? getPageColor()[_0x4a728d(0x59d)]() : _0x4a728d(0x6a2);
                    continue;
                case '3':
                    styleTag['id'] = NITEFALL_START_WORKAROUND_CSS_ID;
                    continue;
                case '4':
                    if (document[_0x4a728d(0x46b)])
                        document[_0x4a728d(0x46b)][_0x4a728d(0x4a7)](styleTag);
                    else
                        document[_0x4a728d(0x189)]['appendChild'](styleTag);
                    continue;
                }
                break;
            }
        }
    }
    initNitefall();
}