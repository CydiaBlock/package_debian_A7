//
//  GSWeather.h
//  GSWeather
//
//  Created by Noah Little on 25/4/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for GSWeather.
FOUNDATION_EXPORT double GSWeatherVersionNumber;

//! Project version string for GSWeather.
FOUNDATION_EXPORT const unsigned char GSWeatherVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GSWeather/PublicHeader.h>


